<?php
declare(strict_types=1);
/** ShahkotPK v11.0.0 — global Navigation Registry Pro renderer. */
if(!defined('SHAHKOTPK_ADMIN_SIDEBAR_V1022_HOOK')){
 define('SHAHKOTPK_ADMIN_SIDEBAR_V1022_HOOK',true);$uri=(string)($_SERVER['REQUEST_URI']??'');
 if(PHP_SAPI!=='cli'&&preg_match('~^/admin(?:/|\\?|$)~i',$uri)){
  if(is_file(__DIR__.'/core_sync_v1301.php'))require_once __DIR__.'/core_sync_v1301.php';if(is_file(__DIR__.'/admin_sidebar_registry_v1022.php'))require_once __DIR__.'/admin_sidebar_registry_v1022.php';$items=[];$native=[];$groups=[];try{if(function_exists('sk1022_nav_sidebar_items')){$items=sk1022_nav_sidebar_items(false);$native=sk1022_nav_native_rules();$groups=sk1022_nav_groups();}}catch(Throwable $e){}
  $identity=function_exists('sk1301_identity')?sk1301_identity():[];$theme=function_exists('sk1301_theme')?sk1301_theme():[];$enc=static fn($v)=>json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?:'[]';$itemsJson=$enc($items);$nativeJson=$enc($native);$groupsJson=$enc($groups);$identityJson=$enc($identity);$themeJson=$enc($theme);$csrfJson=$enc(function_exists('csrf_token')?csrf_token():'');$routesJson=$enc(function_exists('sk1302_dashboard_routes')?sk1302_dashboard_routes():[]);
  ob_start(static function(string $html)use($itemsJson,$nativeJson,$groupsJson,$identityJson,$themeJson,$csrfJson,$routesJson):string{
   if($html===''||stripos($html,'<html')===false)return $html;
   $html=preg_replace('~<script[^>]+src=["\'][^"\']*(?:admin-sidebar-tools-v97[234]|admin-homepage-sidebar-v1010|admin-growth-sidebar-v1020|admin-sidebar-registry-v1021)\\.js[^"\']*["\'][^>]*>\\s*</script>~i','',$html)??$html;
   $html=preg_replace('~<link[^>]+href=["\'][^"\']*(?:admin-sidebar-tools-v97[234]|admin-sidebar-registry-v1021)\\.css[^"\']*["\'][^>]*>~i','',$html)??$html;
   if(strpos($html,'admin-sidebar-registry-v1022.js')!==false)return $html;
   $assets="\n<link rel=\"stylesheet\" href=\"/assets/admin-sidebar-registry-v1022.css?v=1302\">\n".
    "<script>window.ShahkotPKSidebarRegistryV1022={items:{$itemsJson},groups:{$groupsJson},identity:{$identityJson},theme:{$themeJson}};window.ShahkotPKCoreSyncV1301={identity:{$identityJson},theme:{$themeJson}};window.ShahkotPKSidebarNativeRulesV1022={$nativeJson};</script>\n".
    "<script defer src=\"/assets/admin-sidebar-registry-v1022.js?v=1302\"></script>\n".
    "<link rel=\"stylesheet\" href=\"/assets/admin-dashboard-sync-v1302.css?v=13021\"><script>window.ShahkotPKAdminSyncV1302={routes:{$routesJson}};</script><script defer src=\"/assets/admin-dashboard-sync-v1302.js?v=13021\"></script>\n".
    "<link rel=\"stylesheet\" href=\"/assets/core-sync-v1301.css?v=1302\"><script defer src=\"/assets/core-sync-v1301.js?v=1302\"></script>\n".
    "<link rel=\"stylesheet\" href=\"/assets/ai-copilot-admin-float-v1100.css?v=1100\"><script>window.SKAI1100Admin={csrf:{$csrfJson}};</script><script defer src=\"/assets/ai-copilot-admin-float-v1100.js?v=1100\"></script>\n";
   $p=stripos($html,'</head>');if($p!==false)return substr($html,0,$p).$assets.substr($html,$p);$p=stripos($html,'</body>');if($p!==false)return substr($html,0,$p).$assets.substr($html,$p);return $html;
  });
 }
}
