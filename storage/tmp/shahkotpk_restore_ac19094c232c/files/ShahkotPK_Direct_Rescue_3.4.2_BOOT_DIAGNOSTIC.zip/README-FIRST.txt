SHAHKOTPK v3.4.2 DIRECT BOOT RESCUE

Use this only because the site still returns HTTP 500 after v3.4.1.

1) cPanel File Manager -> website document root (normally public_html).
2) Take a backup of current .htaccess and index.php.
3) Extract this ZIP into the SAME root and overwrite files.
4) Open https://your-domain/server-check.php
5) Open https://your-domain/boot-check.php
6) Take screenshots of both pages if anything is red/FAILED.

The replacement index.php is a safe wrapper. If the ShahkotPK application throws a fatal,
it should show a Recovery Mode page instead of a blank browser HTTP 500.

No config, uploads, storage or database data is deleted.
