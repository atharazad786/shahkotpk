<?php
// ShahkotPK v3.4.2 safe public boot wrapper.
// This file intentionally avoids application dependencies so an app fatal does not become a blank HTTP 500.
@ini_set('display_errors', '0');

function shp342_log($message) {
    $dir = __DIR__ . '/storage/logs';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    @file_put_contents($dir . '/bootstrap-fatal.log', '[' . date('c') . '] ' . $message . PHP_EOL, FILE_APPEND | LOCK_EX);
}

function shp342_recovery_page($message) {
    http_response_code(200);
    $safe = htmlspecialchars((string)$message, ENT_QUOTES, 'UTF-8');
    echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ShahkotPK Recovery</title><style>';
    echo 'body{margin:0;font-family:Arial,Helvetica,sans-serif;background:#f4f8f6;color:#10251b}.wrap{max-width:920px;margin:8vh auto;padding:22px}.card{background:#fff;border:1px solid #dce8e1;border-radius:24px;padding:30px;box-shadow:0 18px 50px rgba(16,37,27,.08)}.brand{font-weight:800;color:#176b46;letter-spacing:.08em}.badge{display:inline-block;padding:7px 11px;border-radius:999px;background:#fff2d8;color:#8b5b00;font-weight:700;margin:12px 0}h1{font-size:clamp(30px,5vw,54px);line-height:1.05;margin:10px 0 16px}p{font-size:17px;line-height:1.6;color:#52615a}.err{background:#fff7f7;border:1px solid #f1caca;border-radius:14px;padding:14px;color:#8a2020;word-break:break-word}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:20px}.actions a{display:inline-block;padding:12px 16px;border-radius:12px;background:#176b46;color:#fff;text-decoration:none;font-weight:700}.actions a.alt{background:#eef5f1;color:#176b46}</style></head><body><div class="wrap"><div class="card"><div class="brand">SHAHKOTPK</div><div class="badge">RECOVERY MODE</div><h1>The public portal was protected from an application crash.</h1><p>The PHP request reached ShahkotPK, but the application bootstrap failed. The exact error has been written to <b>storage/logs/bootstrap-fatal.log</b>.</p><div class="err">'.$safe.'</div><div class="actions"><a href="/server-check.php">Run Server Check</a><a class="alt" href="/boot-check.php">Run App Boot Check</a><a class="alt" href="/admin/">Try Admin</a></div></div></div></body></html>';
    exit;
}

register_shutdown_function(function () {
    $e = error_get_last();
    if (!$e) return;
    $fatal = array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR);
    if (!in_array((int)$e['type'], $fatal, true)) return;
    $msg = 'FATAL: ' . (isset($e['message']) ? $e['message'] : 'Unknown') . ' @ ' . (isset($e['file']) ? $e['file'] : 'unknown') . ':' . (isset($e['line']) ? $e['line'] : '0');
    shp342_log($msg);
});

try {
    $runtime = __DIR__ . '/.index-runtime.php';
    if (!is_file($runtime)) throw new Exception('Missing .index-runtime.php after rescue deployment.');
    require $runtime;
} catch (Throwable $e) {
    $msg = get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine();
    shp342_log($msg);
    shp342_recovery_page($msg);
} catch (Exception $e) {
    // PHP 5-style fallback; ShahkotPK itself requires modern PHP, but this keeps diagnostics readable on old handlers.
    $msg = get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine();
    shp342_log($msg);
    shp342_recovery_page($msg);
}
