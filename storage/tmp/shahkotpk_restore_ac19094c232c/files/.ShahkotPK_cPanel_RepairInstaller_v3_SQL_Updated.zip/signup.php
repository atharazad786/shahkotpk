<?php
require __DIR__.'/app/bootstrap.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  csrf_check();
  $n=trim($_POST['name']??'');$em=trim($_POST['email']??'');$ph=trim($_POST['phone']??'');$pw=$_POST['password']??'';
  if(!$n||(!$em&&!$ph)||strlen($pw)<8)throw new Exception();
  $q=db()->prepare("INSERT INTO users(name,email,phone,password_hash,role,status)VALUES(?,?,?,?,?,?)");
  $q->execute([$n,$em?:null,$ph?:null,password_hash($pw,PASSWORD_DEFAULT),'customer','active']);
  header('Location: /login.php');exit;
 }catch(Throwable $e){$error='Could not create account. Email/phone may already exist.';}
}
require __DIR__.'/app/layout.php';page_start('Signup');?>
<div class="card"><h1>Create Account</h1><?php if(isset($error)):?><div class="error"><?=e($error)?></div><?php endif;?>
<form method="post"><input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
<label>Name</label><input class="input" name="name" required>
<label>Email</label><input class="input" name="email">
<label>Phone</label><input class="input" name="phone">
<label>Password</label><input class="input" type="password" name="password" minlength="8" required>
<button class="btn">Signup</button></form></div>
<?php require __DIR__.'/app/end.php';?>
