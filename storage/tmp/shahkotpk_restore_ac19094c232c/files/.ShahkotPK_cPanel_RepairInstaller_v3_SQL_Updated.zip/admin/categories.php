<?php
require __DIR__.'/../app/bootstrap.php';require_admin();require __DIR__.'/../app/layout.php';page_start('Categories',true);
$rows=db()->query('SELECT id,name,slug,status FROM categories ORDER BY id DESC LIMIT 100')->fetchAll();?>
<div class="card"><h1>Categories</h1><table><tr><th>id</th><th>name</th><th>slug</th><th>status</th></tr><?php foreach($rows as $r):?><tr><td><?=e($r['id'])?></td><td><?=e($r['name'])?></td><td><?=e($r['slug'])?></td><td><?=e($r['status'])?></td></tr><?php endforeach;?></table></div>
<?php require __DIR__.'/../app/end.php';?>