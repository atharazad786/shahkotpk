<?php
require __DIR__.'/../app/bootstrap.php';require_admin();require __DIR__.'/../app/layout.php';page_start('Businesses',true);
$rows=db()->query('SELECT id,name,verification_status,status FROM businesses ORDER BY id DESC LIMIT 100')->fetchAll();?>
<div class="card"><h1>Businesses</h1><table><tr><th>id</th><th>name</th><th>verification_status</th><th>status</th></tr><?php foreach($rows as $r):?><tr><td><?=e($r['id'])?></td><td><?=e($r['name'])?></td><td><?=e($r['verification_status'])?></td><td><?=e($r['status'])?></td></tr><?php endforeach;?></table></div>
<?php require __DIR__.'/../app/end.php';?>