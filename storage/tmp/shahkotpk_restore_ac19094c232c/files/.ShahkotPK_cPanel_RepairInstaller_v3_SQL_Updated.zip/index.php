<?php
require __DIR__.'/app/bootstrap.php';
require __DIR__.'/app/layout.php';
page_start('Home');
$businesses=db()->query("SELECT b.*,c.name city_name,cat.name category_name FROM businesses b JOIN cities c ON c.id=b.city_id JOIN categories cat ON cat.id=b.category_id WHERE b.status=1 AND b.verification_status='verified' ORDER BY b.is_featured DESC,b.id DESC LIMIT 12")->fetchAll();
?>
<div class="card">
<h1>ShahkotPK</h1>
<p>Your city business & information showcase.</p>
<a class="btn" href="/login.php">Login</a>
<a class="btn" href="/signup.php">Create Account</a>
</div>
<div class="grid">
<?php foreach($businesses as $b):?>
<div class="card"><h3><?=e($b['name'])?></h3><p><?=e($b['category_name'])?> · <?=e($b['city_name'])?></p></div>
<?php endforeach;?>
</div>
<?php require __DIR__.'/app/end.php';?>
