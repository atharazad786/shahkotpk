<?php
function page_start(string $title, bool $admin = false): void {
    global $config;
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($title)?> - <?=e($config['app_name'] ?? 'CityHub')?></title>
<link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<?php if ($admin): ?>
<aside class="sidebar">
<h2>CityHub</h2>
<a href="/admin/index.php">Dashboard</a>
<a href="/admin/users.php">Users</a>
<a href="/admin/businesses.php">Businesses</a>
<a href="/admin/cities.php">Cities</a>
<a href="/admin/categories.php">Categories</a>
<a href="/admin/plans.php">Plans</a>
<a href="/admin/ads.php">Advertisements</a>
<a href="/admin/settings.php">Settings</a>
<a href="/admin/updates.php">System Updates</a>
<a href="/logout.php">Logout</a>
</aside>
<main class="main">
<?php endif; ?>
<div class="container">
<?php
}
