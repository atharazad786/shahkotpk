<?php
function safe_update_path(string $p): bool {
    $p=str_replace('\\','/',$p);
    return $p!=='' && !str_starts_with($p,'/') && !str_contains($p,'../') && !preg_match('/^[A-Za-z]:\//',$p);
}
function install_update(string $zip): string {
    global $config;
    if(!class_exists('ZipArchive')) throw new RuntimeException('PHP ZIP extension is required.');

    $root=realpath(__DIR__.'/..');
    $z=new ZipArchive();
    if($z->open($zip)!==true) throw new RuntimeException('Invalid ZIP.');
    $idx=$z->locateName('update.json');
    if($idx===false) throw new RuntimeException('update.json is missing.');

    $m=json_decode($z->getFromIndex($idx),true);
    if(!is_array($m)||empty($m['version'])) throw new RuntimeException('Invalid update manifest.');
    if(version_compare($m['version'],$config['version'],'<=')) throw new RuntimeException('Update version must be higher.');

    $tmp=sys_get_temp_dir().'/cityhub_'.bin2hex(random_bytes(5));
    mkdir($tmp,0700,true);

    try{
        for($i=0;$i<$z->numFiles;$i++){
            $name=$z->getNameIndex($i);
            if($name==='update.json') continue;
            if(!safe_update_path($name)) throw new RuntimeException('Unsafe path in ZIP.');
            $dest=$tmp.'/'.$name;
            if(str_ends_with($name,'/')) { @mkdir($dest,0755,true); continue; }
            if(!is_dir(dirname($dest))) mkdir(dirname($dest),0755,true);
            copy('zip://'.$zip.'#'.$name,$dest);
        }
        $z->close();

        $backup=$root.'/storage/backups/'.date('Ymd_His').'_v'.$config['version'].'.zip';
        $bz=new ZipArchive();
        $bz->open($backup,ZipArchive::CREATE|ZipArchive::OVERWRITE);
        $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));
        foreach($it as $f){
            $rel=str_replace('\\','/',substr($f->getPathname(),strlen($root)+1));
            if(is_file($f) && !str_starts_with($rel,'storage/') && !str_starts_with($rel,'config/')) {
                $bz->addFile($f->getPathname(),$rel);
            }
        }
        $bz->close();

        $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($tmp,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::SELF_FIRST);
        foreach($it as $f){
            $rel=str_replace('\\','/',substr($f->getPathname(),strlen($tmp)+1));
            $dest=$root.'/'.$rel;
            if($f->isDir()){
                if(!is_dir($dest)) mkdir($dest,0755,true);
            } else {
                if(!is_dir(dirname($dest))) mkdir(dirname($dest),0755,true);
                copy($f->getPathname(),$dest);
            }
        }

        db()->prepare("INSERT INTO system_updates(version,file_name,status,backup_path,notes)VALUES(?,?,?,?,?)")
            ->execute([$m['version'],basename($zip),'success',$backup,'Installed']);
        return $m['version'];
    } finally {
        if(is_dir($tmp)){
            $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($tmp,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);
            foreach($it as $f){$f->isDir()?@rmdir($f):@unlink($f);}
            @rmdir($tmp);
        }
    }
}
