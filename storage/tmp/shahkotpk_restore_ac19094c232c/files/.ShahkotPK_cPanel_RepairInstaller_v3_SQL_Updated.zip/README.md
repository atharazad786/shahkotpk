# ShahkotPK / CityHub cPanel Repair Installer v3

This package specifically fixes repeated installer-lock / installer-loop problems.

## What changed
- If `storage/.installed` exists but config/database is invalid, installer removes the stale lock automatically.
- If config/database is already valid, installer recreates any missing lock, deletes itself and redirects to `/`.
- Successful install verifies the saved DB config before creating the lock.
- Successful install deletes `install.php` automatically.
- Admin credentials are repaired/reset to:
  - admin@cityhub.local
  - Arman@123

## Install
1. Upload/extract this ZIP directly inside `public_html`.
2. Overwrite existing application files when cPanel asks.
3. Do not delete your MySQL database.
4. Open `/install.php`.
5. Enter your existing cPanel DB name/user/password.
6. Installer repairs stale state or completes installation.
7. After success, `install.php` deletes itself and you are redirected to `/`.

## Manual SQL fallback
`database/schema.sql` now matches the current installer schema and seed data.
