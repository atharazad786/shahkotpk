SHAHKOTPK v3.4.1 DIRECT HTTP 500 REPAIR

Use ONLY if /admin/updates.php cannot open because the whole site is HTTP 500.
1) cPanel > File Manager > website document root (normally public_html).
2) Take a backup first.
3) Upload this ZIP to the document root and Extract, allowing overwrite of the included files.
4) Do NOT delete config/, storage/ or uploads/.
5) Reload the homepage and then open /admin/runtime-health.php.
6) After admin access returns, install the normal ShahkotPK v3.4.1 updater so version/migration state is recorded.

This direct repair contains no database credentials and does not delete user data.
