<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'){http_response_code(403);exit("CLI only\n");}
$_SERVER['REMOTE_ADDR']='127.0.0.1';
require __DIR__.'/../app/bootstrap.php';
require_once __DIR__.'/../app/enterprise_v800.php';

// v9.0.1 regression fix: the legacy v8 cron must remain v8-only.
// v9.0.0 automatically chained the new v9 worker into this entry point, which
// could suddenly add heavy queue/sweep work to an already scheduled cron.
$lockDir=dirname(__DIR__).'/storage/runtime';
if(!is_dir($lockDir))@mkdir($lockDir,0775,true);
$lockFile=is_dir($lockDir)&&is_writable($lockDir)?$lockDir.'/v800-worker.lock':sys_get_temp_dir().'/shahkotpk-v800-worker.lock';
$fh=@fopen($lockFile,'c');
if($fh&&!@flock($fh,LOCK_EX|LOCK_NB)){echo '['.date('c')."] v8 worker already running; skipped.\n";exit(0);}
@set_time_limit(45);
$limit=20;foreach($argv as $a)if(str_starts_with($a,'--limit='))$limit=max(1,min(50,(int)substr($a,8)));
try{$r=v800_worker_run($limit);echo '['.date('c').'] processed='.(int)($r['processed']??0).' failed='.(int)($r['failed']??0).PHP_EOL;}
catch(Throwable $e){fwrite(STDERR,'['.date('c').'] v8 worker error: '.$e->getMessage().PHP_EOL);exit(1);}finally{if($fh){@flock($fh,LOCK_UN);@fclose($fh);}}
