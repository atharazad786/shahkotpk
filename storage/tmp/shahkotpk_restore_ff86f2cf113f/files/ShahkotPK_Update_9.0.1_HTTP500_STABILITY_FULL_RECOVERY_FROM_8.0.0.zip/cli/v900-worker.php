<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'){http_response_code(403);exit("CLI only\n");}
$_SERVER['REMOTE_ADDR']='127.0.0.1';
require __DIR__.'/../app/bootstrap.php';
require_once __DIR__.'/../app/enterprise_v900.php';

// v9.0.1: dedicated, non-overlapping worker. This is intentionally separate
// from cli/v800-worker.php so existing v8 cron jobs do not auto-run v9 work.
$lockDir=dirname(__DIR__).'/storage/runtime';
if(!is_dir($lockDir))@mkdir($lockDir,0775,true);
$lockFile=is_dir($lockDir)&&is_writable($lockDir)?$lockDir.'/v900-worker.lock':sys_get_temp_dir().'/shahkotpk-v900-worker.lock';
$fh=@fopen($lockFile,'c');
if($fh&&!@flock($fh,LOCK_EX|LOCK_NB)){echo '['.date('c')."] v9 worker already running; skipped.\n";exit(0);}
@set_time_limit(45);
$limit=20;foreach($argv as $a)if(str_starts_with($a,'--limit='))$limit=max(1,min(50,(int)substr($a,8)));
try{$r=v900_worker_run($limit);echo '['.date('c').'] v9='.json_encode($r,JSON_UNESCAPED_SLASHES).PHP_EOL;}
catch(Throwable $e){fwrite(STDERR,'['.date('c').'] v9 worker error: '.$e->getMessage().PHP_EOL);exit(1);}finally{if($fh){@flock($fh,LOCK_UN);@fclose($fh);}}
