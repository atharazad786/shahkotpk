# ShahkotPK v9.0.1 Release Audit

- App: ShahkotPK
- Minimum version: 8.0.0
- Target version: 9.0.1
- Package type: full recovery update
- Existing v9 schema: additive/re-runnable

## Static validation
- All packaged PHP files linted with `php -l`.
- JavaScript files parsed with `node --check`.
- `update.json` parsed successfully.
- Migration destructive-statement scan checks for DROP/TRUNCATE/DELETE and destructive ALTER patterns.
- ZIP path traversal scan performed.

## Stability changes
- Legacy v8 worker no longer auto-runs v9 queues.
- Dedicated v8/v9 workers use non-blocking locks.
- Worker batch size and runtime are bounded.
- Periodic SLA/KYC/KPI sweeps are throttled.
- Complete v9 application delta included to repair partially overwritten v9.0.0 files.

The browser's HTTP 500 screenshot does not include a PHP stack trace; therefore the exact hosting fatal should still be confirmed from the PHP/Apache error log if the problem persists after recovery.
