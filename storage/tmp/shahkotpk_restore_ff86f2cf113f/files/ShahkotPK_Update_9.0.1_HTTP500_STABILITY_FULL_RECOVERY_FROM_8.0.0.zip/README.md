# ShahkotPK v9.0.1 — HTTP 500 Stability & Worker Isolation Recovery

Full recovery updater for **ShahkotPK 8.0.0 or newer**, targeting **9.0.1**. It includes the complete v9.0 Enterprise Operations Super Suite application delta so a partially applied v9.0.0 deployment can be repaired in one pass.

## Regression addressed

v9.0.0 replaced the existing `cli/v800-worker.php` entry point so an already-configured v8 cron also invoked all new v9 background queues and periodic sweeps. On installations that already had a per-minute v8 cron, this could introduce unexpected database/network workload shortly after the update. The browser screenshot alone cannot prove the server's exact PHP fatal without the hosting error log, but this automatic worker chaining is a concrete v9.0.0 regression and matches a delayed post-update failure pattern.

v9.0.1 changes:

- Restores `cli/v800-worker.php` to **v8-only** processing.
- Keeps v9 background work in the dedicated `cli/v900-worker.php` entry point.
- Adds non-blocking `flock()` protection so the same worker cannot overlap itself.
- Caps automatic worker batches at 50; default CLI batch is 20.
- Caps worker execution time to 45 seconds where hosting permits it.
- Throttles SLA sweeps to every 15 minutes.
- Runs KYC expiry reminder sweep once in the morning window rather than every minute.
- Runs franchise KPI snapshots once in the overnight window instead of the first five minutes of every hour.
- Reinstalls the complete v9 application delta and additive schema for recovery from a partial v9.0.0 deployment.

## Cron after recovery

Existing v8 cron can remain:

```bash
php /path/to/shahkotpk/cli/v800-worker.php --limit=20
```

When you want v9 queues/automation enabled, configure a separate cron:

```bash
php /path/to/shahkotpk/cli/v900-worker.php --limit=20
```

Do not run multiple copies of the same worker. v9.0.1 also prevents overlaps automatically.

## Data safety

The included 9.0.0 migration uses additive `CREATE TABLE IF NOT EXISTS`. The package does not delete tenant/application data and preserves `config/config.php`, `storage/` and `uploads/`.

If the admin panel is also returning HTTP 500 and the normal updater cannot be opened, this recovery ZIP can be extracted over the application root using the hosting File Manager/SSH, preserving the listed data directories.
