<?php
require_once __DIR__.'/global_brand_v704.php';
function page_start(string $title,bool $admin=false):void{
    global $config;
    // v5.4.3: finish the one-time registry-safe demo replacement on the first admin page
    // after the updater has completed. This runs only when the migration sets the pending flag.
    if($admin && function_exists('setting') && (string)setting('dummy_data_v543_replace_pending','0')==='1'){
        try{
            require_once __DIR__.'/dummy_data_v52.php';
            if(function_exists('dummy_v52_maybe_autoload'))dummy_v52_maybe_autoload();
        }catch(Throwable $e){
            if(function_exists('runtime_log'))runtime_log('v5.4.3 pending dummy-data replacement failed',$e);
        }
    }
    $currentPath=$_SERVER['PHP_SELF']??'';
    $currentUser=function_exists('current_user')?current_user():null;
    $adminTheme=$admin&&function_exists('active_admin_theme')?active_admin_theme():'aurora-command';
    $adminThemeDef=$admin&&function_exists('theme_definition')?theme_definition('admin',$adminTheme):[];
    $adminAvatar=$admin&&$currentUser&&function_exists('admin_avatar_url')?admin_avatar_url((int)$currentUser['id']):'';
    $currentProfile=$admin&&$currentUser&&function_exists('get_user_profile')?get_user_profile((int)$currentUser['id']):[];
    $globalLogo=function_exists('gb704_any_logo_url')?gb704_any_logo_url():(function_exists('gb704_logo_url')?gb704_logo_url():'');
    $globalMobileLogo=function_exists('gb704_mobile_logo_url')?gb704_mobile_logo_url():$globalLogo;
    $globalBrandName=function_exists('gb704_brand_name')?gb704_brand_name('ShahkotPK'):(function_exists('tenant_brand')?tenant_brand('site_name','ShahkotPK'):'ShahkotPK');
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($title)?> - <?=e($config['app_name']??'ShahkotPK')?></title>
<?php if($admin):?>
<script>
(function(){
    try{
        var saved=localStorage.getItem('shahkotpk_admin_theme')||'light';
        document.documentElement.setAttribute('data-admin-theme',saved);
    }catch(e){}
})();
</script>

<link rel="stylesheet" href="/assets/admin-pro-1.5.0.css?v=150">
<style>
html,body{margin:0;background:#f3f6fb;color:#172033;font-family:Arial,sans-serif}.sidebar{position:fixed;left:0;top:0;bottom:0;width:264px;background:#111827;color:#fff;padding:18px;overflow:auto}.main{margin-left:264px;min-height:100vh}.container{max-width:1660px;margin:auto;padding:24px}.card{background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:20px;margin-bottom:18px}.btn{display:inline-block;background:#2563eb;color:#fff!important;border:0;border-radius:10px;padding:9px 13px;text-decoration:none}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:15px}.input,select,textarea,input{box-sizing:border-box;max-width:100%;padding:10px;border:1px solid #cad5e2;border-radius:10px}table{width:100%;border-collapse:collapse}th,td{padding:10px;border-bottom:1px solid #edf1f6;text-align:left}@media(max-width:920px){.sidebar{position:static;width:auto}.main{margin-left:0}}
</style>
<link rel="stylesheet" href="/assets/themes/admin/base.css?v=230">
<link rel="stylesheet" href="/assets/themes/admin/<?=e($adminTheme)?>.css?v=230">
<link rel="stylesheet" href="/assets/admin-ui-2.3.2.css?v=232">
<?php if(setting_bool('admin_readable_typography_enabled',true)):?><link rel="stylesheet" href="/assets/admin-readable-2.8.1.css?v=281"><?php endif;?>
<link rel="stylesheet" href="/assets/admin-sidebar-5.4.3.css?v=543">
<?=function_exists('gb704_asset_tag')?gb704_asset_tag():''?>
<script defer src="/assets/admin-sidebar-5.8.0.js?v=800"></script>
<?php else:?>
<link rel="stylesheet" href="/assets/shahkotpk-1.6.0.css?v=160">
<?=function_exists('gb704_asset_tag')?gb704_asset_tag():''?>
<?php endif;?>
</head>
<body class="<?=$admin?'admin-body admin-theme-'.e($adminTheme):'public-body'?>" data-admin-template="<?=e($adminTheme)?>" data-theme-animations="<?=theme_animation_enabled('admin')?'1':'0'?>" <?=$admin?'data-admin-font-scale="'.e(setting('admin_font_scale','comfortable')).'"':''?>>
<?php if($admin):?>
<aside class="sidebar"><div class="sidebar-glow sidebar-glow-one"></div><div class="sidebar-glow sidebar-glow-two"></div>
<?php if($globalLogo):?><div class="brand-block gb704-admin-brand"><a href="/admin/index.php" aria-label="<?=e($globalBrandName)?> Admin"><?=gb704_picture('admin-sidebar',$globalBrandName)?></a></div><?php else:?><div class="brand-block"><div class="brand-icon"><?=e(mb_strtoupper(mb_substr((string)$globalBrandName,0,1)))?></div><div><h2><?=e($globalBrandName)?></h2><small><?=e(function_exists('tenant_brand')?tenant_brand('city_name','City'):'City')?> Portal Admin</small></div></div><?php endif;?>
<div class="nav-section">Dashboard</div>
<?php if(has_permission('dashboard.view')):?><a class="<?=str_contains($currentPath,'/admin/index.php')?'active':''?>" href="/admin/index.php">▣ Overview</a><?php endif;?>
<?php if(has_permission('widgets.manage')):?><a class="<?=str_contains($currentPath,'/admin/widgets.php')?'active':''?>" href="/admin/widgets.php">◫ Dashboard Widgets</a><?php endif;?>
<?php if(has_permission('themes.manage')):?><a class="<?=str_contains($currentPath,'/admin/themes.php')?'active':''?>" href="/admin/themes.php">✦ Theme Studio</a><?php endif;?>
<?php if(has_permission('homepage.manage')):?><a class="<?=str_contains($currentPath,'/admin/homepage.php')?'active':''?>" href="/admin/homepage.php">◈ Homepage Builder 2.0</a><?php endif;?>
<?php if(has_permission('homepage.manage')):?><a class="<?=str_contains($currentPath,'/admin/banner-pack.php')?'active':''?>" href="/admin/banner-pack.php">▰ Landing Banner Pack</a><?php endif;?>
<?php if(has_permission('banners.manage')):?><a class="<?=str_contains($currentPath,'/admin/banners.php')?'active':''?>" href="/admin/banners.php">▧ Banner Manager</a><?php endif;?>
<?php if(has_permission('ticker.manage')):?><a class="<?=str_contains($currentPath,'/admin/ticker.php')?'active':''?>" href="/admin/ticker.php">≋ Information Ticker</a><?php endif;?>
<?php if(has_permission('homepage.manage')||has_permission('settings.manage')):?><a class="<?=str_contains($currentPath,'/admin/header-menu.php')?'active':''?>" href="/admin/header-menu.php">☰ Header & Menu Manager</a><?php endif;?>

<div class="nav-section">Directory</div>
<?php if(has_permission('businesses.manage')):?><a class="<?=str_contains($currentPath,'/admin/businesses.php')?'active':''?>" href="/admin/businesses.php">▤ Businesses</a><?php endif;?>
<?php if(has_permission('categories.manage')):?><a class="<?=str_contains($currentPath,'/admin/categories.php')?'active':''?>" href="/admin/categories.php">▦ Categories</a><?php endif;?>
<?php if(has_permission('cities.manage')):?><a class="<?=str_contains($currentPath,'/admin/cities.php')?'active':''?>" href="/admin/cities.php">⌖ Cities</a><?php endif;?>
<?php if(has_permission('maps.manage')):?><a class="<?=str_contains($currentPath,'/admin/maps.php')?'active':''?>" href="/admin/maps.php">◎ Map Control</a><?php endif;?>
<?php if(has_permission('maps.manage')):?><a class="<?=str_contains($currentPath,'/admin/location-discovery.php')?'active':''?>" href="/admin/location-discovery.php">⌖ Location Discovery v5.4</a><?php endif;?>
<?php if(has_permission('city_content.manage')||has_permission('city_guide.manage')||has_permission('deals.manage')||has_permission('events.manage')||has_permission('jobs.manage')||has_permission('property.manage')):?><div class="nav-section">City Content</div><?php if(has_permission('city_guide.manage')):?><a class="<?=str_contains($currentPath,'/admin/city-guide.php')?'active':''?>" href="/admin/city-guide.php">⌖ City Guide</a><?php endif;?><?php if(has_permission('deals.manage')):?><a class="<?=str_contains($currentPath,'/admin/deals.php')?'active':''?>" href="/admin/deals.php">% Deals & Offers</a><?php endif;?><?php if(has_permission('events.manage')):?><a class="<?=str_contains($currentPath,'/admin/events.php')?'active':''?>" href="/admin/events.php">◆ Events</a><?php endif;?><?php if(has_permission('jobs.manage')):?><a class="<?=str_contains($currentPath,'/admin/jobs.php')?'active':''?>" href="/admin/jobs.php">▣ Jobs</a><?php endif;?><?php if(has_permission('property.manage')):?><a class="<?=str_contains($currentPath,'/admin/property.php')?'active':''?>" href="/admin/property.php">⌂ Property</a><?php endif;?><?php endif;?>
<?php if(has_permission('bloodbank.dashboard')):?><div class="nav-section">Health & Blood Bank</div><a class="<?=str_contains($currentPath,'/admin/blood-bank.php')?'active':''?>" href="/admin/blood-bank.php">♥ Blood Bank & Donation</a><?php endif;?>
<?php if(has_permission('health.dashboard')):?><div class="nav-section">Digital Healthcare</div><a class="<?=str_contains($currentPath,'/admin/doctor-online.php')?'active':''?>" href="/admin/doctor-online.php">✚ Doctor Online</a><?php endif;?>
<?php if(has_permission('healthnet.dashboard')):?><div class="nav-section">Healthcare Network</div><a class="<?=str_contains($currentPath,'/admin/health-network.php')?'active':''?>" href="/admin/health-network.php">✦ Pharmacy · Labs · Ambulance</a><?php endif;?>
<?php if(has_permission('smartcity.dashboard')):?><div class="nav-section">Smart City v6</div><a class="<?=str_contains($currentPath,'/admin/smart-city.php')?'active':''?>" href="/admin/smart-city.php">◈ Citizen Super App</a><?php endif;?>
<?php if(has_permission('ai.dashboard')||has_permission('ai.providers.manage')||has_permission('ai.integrations.manage')||has_permission('ai.knowledge.manage')||has_permission('ai.training.manage')||has_permission('ai.agents.manage')||has_permission('ai.actions.approve')||has_permission('ai.analytics')||has_permission('ai.settings')||has_permission('ai.manage')):?><div class="nav-section">AI Command Center v7.1</div><a class="<?=str_contains($currentPath,'/admin/ai.php')?'active':''?>" href="/admin/ai.php">✦ AI Control Center</a><?php endif;?>
<?php if(has_permission('enterprise.dashboard')||has_permission('voice.manage')||has_permission('bi.manage')||has_permission('ops.manage')||has_permission('security.ops.manage')||has_permission('enterprise.whitelabel.manage')||has_permission('enterprise.api.manage')||has_permission('enterprise.analytics')):?><div class="nav-section">Enterprise Platform v8</div><a class="<?=str_contains($currentPath,'/admin/enterprise.php')?'active':''?>" href="/admin/enterprise.php">◈ Enterprise Command Center</a><?php endif;?>
<?php if(has_permission('superapp.dashboard')||has_permission('education.institutions.manage')||has_permission('transport.operators.manage')||has_permission('tourism.places.manage')):?><div class="nav-section">Super App v7</div><a class="<?=str_contains($currentPath,'/admin/super-app.php')?'active':''?>" href="/admin/super-app.php">◉ v7 Command Center</a><?php if(has_permission('education.institutions.manage')):?><a href="/admin/super-app.php?tab=education">▤ Education Platform</a><?php endif;?><?php if(has_permission('transport.operators.manage')||has_permission('transport.dispatch.manage')):?><a href="/admin/super-app.php?tab=transport">↔ Transport & Delivery</a><?php endif;?><?php if(has_permission('tourism.places.manage')||has_permission('tourism.bookings.manage')):?><a href="/admin/super-app.php?tab=tourism">✦ Tourism & Booking</a><?php endif;?><?php endif;?>
<?php if(has_permission('news.manage')):?><div class="nav-section">Newsroom</div><a class="<?=str_contains($currentPath,'/admin/news.php')?'active':''?>" href="/admin/news.php">▰ News Portal</a><?php endif;?>
<?php if(has_permission('live.manage')||has_permission('engagement.manage')):?><div class="nav-section">Live & Engagement</div><?php if(has_permission('live.manage')):?><a class="<?=str_contains($currentPath,'/admin/live.php')?'active':''?>" href="/admin/live.php">◉ Live Broadcast Center</a><?php endif;?><?php if(has_permission('engagement.manage')):?><a class="<?=str_contains($currentPath,'/admin/engagement.php')?'active':''?>" href="/admin/engagement.php">🔔 Popups & Notifications</a><?php endif;?><?php endif;?>
<?php if(has_permission('blog.dashboard')):?><div class="nav-section">Publishing</div><a class="<?=str_contains($currentPath,'/admin/blog.php')?'active':''?>" href="/admin/blog.php">✎ Blogging Studio</a><?php endif;?>
<?php if(has_permission('users.manage')):?><a class="<?=str_contains($currentPath,'/admin/users.php')?'active':''?>" href="/admin/users.php">◉ Users</a><?php endif;?>
<?php if(has_permission('roles.manage')):?><a class="<?=str_contains($currentPath,'/admin/roles.php')?'active':''?>" href="/admin/roles.php">◆ Roles & Permissions</a><?php endif;?>

<?php if(has_permission('shop.manage')||has_permission('shop.orders.manage')||has_permission('shop.auctions.manage')):?><div class="nav-section">Commerce</div><a class="<?=str_contains($currentPath,'/admin/shop.php')?'active':''?>" href="/admin/shop.php">🛍 E-commerce & Marketplace</a><?php endif;?>

<?php if(has_permission('reviews.manage')||has_permission('verification.manage')||has_permission('bookings.manage')||has_permission('leads.manage')||has_permission('analytics.manage')||has_permission('moderation.manage')):?><div class="nav-section">Growth & Trust</div>
<?php if(has_permission('reviews.manage')):?><a class="<?=str_contains($currentPath,'/admin/reviews.php')?'active':''?>" href="/admin/reviews.php">★ Ratings & Reviews</a><?php endif;?>
<?php if(has_permission('verification.manage')):?><a class="<?=str_contains($currentPath,'/admin/verification.php')?'active':''?>" href="/admin/verification.php">✓ Business Verification</a><?php endif;?>
<?php if(has_permission('bookings.manage')):?><a class="<?=str_contains($currentPath,'/admin/bookings.php')?'active':''?>" href="/admin/bookings.php">◷ Bookings</a><?php endif;?>
<?php if(has_permission('leads.manage')):?><a class="<?=str_contains($currentPath,'/admin/leads.php')?'active':''?>" href="/admin/leads.php">↗ Lead CRM</a><?php endif;?>
<?php if(has_permission('analytics.manage')):?><a class="<?=str_contains($currentPath,'/admin/analytics.php')?'active':''?>" href="/admin/analytics.php">▥ Advanced Analytics</a><?php endif;?>
<?php if(has_permission('moderation.manage')):?><a class="<?=str_contains($currentPath,'/admin/moderation.php')?'active':''?>" href="/admin/moderation.php">⚑ Moderation Center</a><?php endif;?><?php endif;?>

<?php if(has_permission('loyalty.manage')||has_permission('referrals.manage')||has_permission('whatsapp.manage')||has_permission('push.manage')):?><div class="nav-section">Retention</div>
<?php if(has_permission('loyalty.manage')):?><a href="/admin/loyalty.php">◆ Loyalty & Wallet</a><?php endif;?>
<?php if(has_permission('referrals.manage')):?><a href="/admin/referrals.php">∞ Referrals</a><?php endif;?>
<?php if(has_permission('whatsapp.manage')):?><a href="/admin/whatsapp.php">WA WhatsApp Automation</a><?php endif;?>
<?php if(has_permission('push.manage')):?><a href="/admin/push.php">🔔 PWA & Push</a><?php endif;?><?php endif;?>

<?php if(has_permission('emergency.manage')||has_permission('restaurants.manage')||has_permission('services.manage')||has_permission('classifieds.manage')||has_permission('seller_staff.manage')):?><div class="nav-section">Local Services</div>
<?php if(has_permission('emergency.manage')):?><a href="/admin/emergency.php">+ Emergency Services</a><?php endif;?>
<?php if(has_permission('restaurants.manage')):?><a href="/admin/restaurants.php">☰ Restaurant Menus</a><?php endif;?>
<?php if(has_permission('services.manage')):?><a href="/admin/services.php">⚒ Service Marketplace</a><?php endif;?>
<?php if(has_permission('classifieds.manage')):?><a href="/admin/classifieds.php">🏷 Classified Ads</a><?php endif;?>
<?php if(has_permission('seller_staff.manage')):?><a href="/admin/seller-staff.php">👥 Seller Staff</a><?php endif;?><?php endif;?>

<?php if(has_permission('entitlements.manage')||has_permission('seo.manage')||has_permission('multi_city.manage')||has_permission('reports.manage')):?><div class="nav-section">Commercial Platform</div>
<?php if(has_permission('entitlements.manage')):?><a href="/admin/entitlements.php">🔐 Plan Entitlements</a><?php endif;?>
<?php if(has_permission('seo.manage')):?><a href="/admin/seo.php">SEO Automation</a><?php endif;?>
<?php if(has_permission('multi_city.manage')):?><a href="/admin/multi-city.php">⌖ Multi-City Control</a><?php endif;?>
<?php if(has_permission('reports.manage')):?><a href="/admin/reports.php">₨ Commercial Reports</a><?php endif;?><?php endif;?>

<?php if(has_permission('operations.dashboard')||has_permission('payouts.manage')||has_permission('commerce_invoices.manage')||has_permission('support.manage')||has_permission('disputes.manage')||has_permission('delivery.manage')||has_permission('inventory.manage')||has_permission('purchasing.manage')||has_permission('audit.manage')||has_permission('backups.manage')||has_permission('queues.manage')):?><div class="nav-section">Commercial Operations</div>
<?php if(has_permission('operations.dashboard')):?><a href="/admin/operations.php">◈ Operations Command Center</a><?php endif;?>
<?php if(has_permission('payouts.manage')):?><a href="/admin/payouts.php">₨ Seller Payouts</a><?php endif;?>
<?php if(has_permission('commerce_invoices.manage')):?><a href="/admin/invoices-commerce.php">▤ Commerce Invoices</a><?php endif;?>
<?php if(has_permission('support.manage')):?><a href="/admin/support.php">☏ Support Tickets</a><?php endif;?>
<?php if(has_permission('disputes.manage')):?><a href="/admin/disputes.php">⚖ Disputes & Refunds</a><?php endif;?>
<?php if(has_permission('delivery.manage')):?><a href="/admin/delivery.php">🚚 Delivery</a><?php endif;?>
<?php if(has_permission('inventory.manage')):?><a href="/admin/inventory.php">▦ Inventory</a><?php endif;?>
<?php if(has_permission('purchasing.manage')):?><a href="/admin/purchasing.php">▣ Vendor Purchasing</a><?php endif;?>
<?php if(has_permission('audit.manage')):?><a href="/admin/audit.php">☷ Audit Logs</a><?php endif;?>
<?php if(has_permission('backups.manage')):?><a href="/admin/backups.php">⛁ Backup Manager</a><?php endif;?>
<?php if(has_permission('queues.manage')):?><a href="/admin/queues.php">⚙ Queue & Health</a><?php endif;?><?php endif;?>

<?php if(has_permission('security.manage')||has_permission('health.manage')||has_permission('logs.manage')||has_permission('franchise.manage')||has_permission('mobile_api.manage')||has_permission('pos.manage')):?><div class="nav-section">Unified Platform v4</div>
<?php if(has_permission('security.manage')):?><a href="/admin/security.php">🛡 Security Center</a><?php endif;?>
<?php if(has_permission('health.manage')):?><a href="/admin/system-health.php">♥ System Health</a><?php endif;?>
<?php if(has_permission('logs.manage')):?><a href="/admin/activity-logs.php">⌖ Logs & Location</a><?php endif;?>
<?php if(has_permission('franchise.manage')):?><a href="/admin/franchise.php">⌖ Franchise Control</a><?php endif;?>
<?php if(has_permission('mobile_api.manage')):?><a href="/admin/mobile-api.php">▣ Mobile & Seller Apps</a><?php endif;?>
<?php if(has_permission('pos.manage')):?><a href="/admin/pos.php">POS Seller POS</a><?php endif;?><?php endif;?>
<?php if(has_permission('tenants.manage')):?><div class="nav-section">Multi-Tenant v5</div><a class="<?=str_contains($currentPath,'/admin/tenants.php')?'active':''?>" href="/admin/tenants.php">◫ Tenant & Franchise Center</a><?php endif;?>

<?php if(has_permission('monetization.manage')||has_permission('ad_marketplace.manage')||has_permission('boosts.manage')||has_permission('renewals.manage')||has_permission('commissions.manage')||has_permission('qr.manage')||has_permission('bulk.manage')||has_permission('media.manage')||has_permission('redirects.manage')||has_permission('campaigns.manage')||has_permission('inbox.manage')||has_permission('regression.manage')):?><div class="nav-section">Growth & Monetization v4.1</div>
<?php if(has_permission('monetization.manage')):?><a href="/admin/monetization.php">◆ Growth Command Center</a><?php endif;?>
<?php if(has_permission('ad_marketplace.manage')):?><a href="/admin/ad-marketplace.php">◫ Self-Service Ads</a><?php endif;?>
<?php if(has_permission('boosts.manage')):?><a href="/admin/boosts.php">↑ Listing Boosts</a><?php endif;?>
<?php if(has_permission('renewals.manage')):?><a href="/admin/renewals.php">↻ Renewal Center</a><?php endif;?>
<?php if(has_permission('commissions.manage')):?><a href="/admin/commission-engine.php">% Commission Engine</a><?php endif;?>
<?php if(has_permission('qr.manage')):?><a href="/admin/qr-center.php">▦ QR Center</a><?php endif;?>
<?php if(has_permission('franchise.manage')):?><a href="/admin/franchise-settlements.php">₨ Franchise Settlements</a><?php endif;?>
<?php if(has_permission('bulk.manage')):?><a href="/admin/bulk-tools.php">⇄ Bulk Import / Export</a><?php endif;?>
<?php if(has_permission('media.manage')):?><a href="/admin/media-library.php">▧ Media Library</a><?php endif;?>
<?php if(has_permission('redirects.manage')):?><a href="/admin/seo-console.php">↗ SEO & Redirect Console</a><?php endif;?>
<?php if(has_permission('campaigns.manage')):?><a href="/admin/campaigns.php">✉ Campaign Center</a><?php endif;?>
<?php if(has_permission('inbox.manage')):?><a href="/admin/inbox.php">☏ Unified Inbox</a><?php endif;?>
<?php if(has_permission('regression.manage')):?><a href="/admin/regression-tests.php">✓ Regression Tests</a><?php endif;?><?php endif;?>

<div class="nav-section">Revenue</div>
<?php if(has_permission('subscriptions.manage')):?><a class="<?=str_contains($currentPath,'/admin/plans.php')?'active':''?>" href="/admin/plans.php">▱ Plans & Subscriptions</a><?php endif;?>
<?php if(has_permission('ads.manage')):?><a class="<?=str_contains($currentPath,'/admin/ads.php')?'active':''?>" href="/admin/ads.php">◫ Advertisements</a><?php endif;?>
<?php if(has_permission('payments.manage')):?><a class="<?=str_contains($currentPath,'/admin/payments.php')?'active':''?>" href="/admin/payments.php">₨ Payments & Earnings</a><?php endif;?>
<?php if(has_permission('accounts.manage')):?><a class="<?=str_contains($currentPath,'/admin/accounts.php')?'active':''?>" href="/admin/accounts.php">▦ Accounts & Ledger</a><?php endif;?>

<div class="nav-section">System</div>
<?php if(has_permission('settings.manage')||has_permission('updates.manage')||has_permission('tenants.manage')):?><a class="<?=str_contains($currentPath,'/admin/dummy-data.php')?'active':''?>" href="/admin/dummy-data.php">◈ Dummy Data Manager</a><?php endif;?>
<?php if(has_permission('updates.manage')):?><a class="<?=str_contains($currentPath,'/admin/updates.php')?'active':''?>" href="/admin/updates.php">⇧ Updates & Recovery</a><?php endif;?>
<?php if(has_permission('settings.manage')):?><a class="<?=str_contains($currentPath,'/admin/settings.php')?'active':''?>" href="/admin/settings.php">⚙ Settings</a><?php endif;?>
<a class="<?=str_contains($currentPath,'/admin/profile.php')?'active':''?>" href="/admin/profile.php">👤 Staff Profile</a>
<a href="/logout.php">↩ Logout</a>
</aside>
<main class="main">
<div class="admin-topbar">
<div class="admin-title-row"><?php if($globalMobileLogo):?><?=gb704_picture('admin-topbar',$globalBrandName)?><?php endif;?><div><h1 class="page-title"><?=e($title)?></h1><div class="page-subtitle"><?=e($globalBrandName)?> administration · <?=e(function_exists('tenant_brand')?tenant_brand('city_name','City'):'City')?> tenant context</div></div></div>
<div class="admin-tools">
<span class="chip theme-name-chip">✦ <?=e($adminThemeDef['name']??'Theme')?></span>
<button class="theme-toggle" type="button" id="adminThemeToggle" aria-label="Toggle admin dark mode"><span id="adminThemeIcon">☾</span><span class="theme-toggle-label">Dark</span></button>
<span class="chip">Today <?=date('d M Y')?></span>
<span class="chip">PKT <?=date('h:i A')?></span>
<div class="admin-user-menu" id="adminUserMenu">
<button class="admin-user-trigger" type="button" id="adminUserTrigger" aria-haspopup="true" aria-expanded="false">
    <span class="admin-user-avatar">
        <?php if($adminAvatar):?><img src="<?=e($adminAvatar)?>" alt="Admin"><?php else:?><span><?=e(strtoupper(substr($currentUser['name']??'A',0,1)))?></span><?php endif;?>
    </span>
    <span class="admin-user-meta"><b><?=e($currentUser['name']??'Staff')?></b><small><?=e(core_role_registry()[$currentUser['role']??'admin']['label']??ucfirst((string)($currentUser['role']??'Staff')))?><?=!empty($currentProfile['custom_role_name'])?' · '.e($currentProfile['custom_role_name']):''?></small></span>
    <span class="admin-user-chevron">⌄</span>
</button>
<div class="admin-user-dropdown" id="adminUserDropdown" role="menu">
    <div class="admin-user-dropdown-head">
        <span class="admin-user-avatar large">
            <?php if($adminAvatar):?><img src="<?=e($adminAvatar)?>" alt="Admin"><?php else:?><span><?=e(strtoupper(substr($currentUser['name']??'A',0,1)))?></span><?php endif;?>
        </span>
        <div><strong><?=e($currentUser['name']??'Admin')?></strong><small><?=e($currentUser['email']?:($currentUser['phone']??'Administrator'))?></small></div>
    </div>
    <a href="/admin/profile.php">👤 Edit Profile</a>
    <?php if(has_permission('settings.manage')):?><a href="/admin/settings.php">⚙ Settings</a><?php endif;?>
    <?php if(has_permission('themes.manage')):?><a href="/admin/themes.php">✦ Theme Studio</a><?php endif;?>
    <a href="/" target="_blank">↗ View Website</a>
    <div class="admin-user-dropdown-sep"></div>
    <a class="logout-link" href="/logout.php">↩ Logout</a>
</div>
</div>
</div>
</div>

<script>
(function(){
    const root=document.documentElement;
    const btn=document.getElementById('adminThemeToggle');
    const icon=document.getElementById('adminThemeIcon');
    const label=btn?btn.querySelector('.theme-toggle-label'):null;

    function sync(){
        const dark=root.getAttribute('data-admin-theme')==='dark';
        if(icon)icon.textContent=dark?'☀':'☾';
        if(label)label.textContent=dark?'Light':'Dark';
    }
    sync();

    if(btn){
        btn.addEventListener('click',function(){
            const next=root.getAttribute('data-admin-theme')==='dark'?'light':'dark';
            root.setAttribute('data-admin-theme',next);
            try{localStorage.setItem('shahkotpk_admin_theme',next);}catch(e){}
            sync();
        });
    }
})();
</script>

<script>
(function(){
    const menu=document.getElementById('adminUserMenu');
    const trigger=document.getElementById('adminUserTrigger');
    const dropdown=document.getElementById('adminUserDropdown');
    if(!menu||!trigger||!dropdown)return;

    function closeMenu(){
        dropdown.classList.remove('is-open');
        trigger.setAttribute('aria-expanded','false');
    }

    trigger.addEventListener('click',function(e){
        e.stopPropagation();
        const open=dropdown.classList.toggle('is-open');
        trigger.setAttribute('aria-expanded',open?'true':'false');
    });

    document.addEventListener('click',function(e){
        if(!menu.contains(e.target)) closeMenu();
    });

    document.addEventListener('keydown',function(e){
        if(e.key==='Escape') closeMenu();
    });
})();
</script>

<?php endif;?>
<div class="container">
<?php } ?>

