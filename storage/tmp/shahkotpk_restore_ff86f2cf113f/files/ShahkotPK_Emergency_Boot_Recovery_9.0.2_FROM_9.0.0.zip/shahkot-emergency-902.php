<?php
// ShahkotPK standalone emergency diagnostic. Delete after recovery.
$expected = 'e08e5d5a08b1d6d2f22a851a';
$key = isset($_GET['key']) ? (string)$_GET['key'] : '';
if (!hash_equals($expected, $key)) { http_response_code(404); exit('Not found'); }
header('Content-Type: text/html; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
if (isset($_GET['reset']) && $_GET['reset'] === '1') {
    clearstatcache(true);
    if (function_exists('opcache_reset')) { @opcache_reset(); }
    header('Location: shahkot-emergency-902.php?key=' . rawurlencode($expected) . '&reset_done=1'); exit;
}
function h902($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function yes902($v){ return $v ? '<b style="color:#15803d">YES</b>' : '<b style="color:#b91c1c">NO</b>'; }
function redact902($s){
    $s = preg_replace('/((?:password|passwd|pass|api[_-]?key|secret|token)\s*[=:>]\s*)[^\s,;]+/i', '\1[REDACTED]', (string)$s);
    return $s;
}
function tail902($path, $bytes){
    if (!$path || !is_file($path) || !is_readable($path)) return '';
    $size = @filesize($path); if ($size === false) return '';
    $start = max(0, $size - $bytes); $fh = @fopen($path,'rb'); if(!$fh)return '';
    @fseek($fh,$start); $data = stream_get_contents($fh); fclose($fh);
    return redact902($data);
}
$root = __DIR__;
$checks = array(
  'index.php' => $root.'/index.php',
  'app/layout.php' => $root.'/app/layout.php',
  'app/permissions.php' => $root.'/app/permissions.php',
  'config/config.php' => $root.'/config/config.php',
  'storage/' => $root.'/storage',
  'uploads/' => $root.'/uploads',
  'admin/index.php' => $root.'/admin/index.php',
  'admin/login.php' => $root.'/admin/login.php'
);
$logs = array($root.'/error_log', $root.'/admin/error_log');
$iniLog = ini_get('error_log');
if ($iniLog && strpos($iniLog,'syslog') === false) { $logs[] = $iniLog; }
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ShahkotPK Emergency 9.0.2</title>
<style>body{font-family:Arial,sans-serif;background:#f5f7fb;color:#172033;margin:0}.wrap{max-width:980px;margin:30px auto;padding:0 18px}.card{background:#fff;border:1px solid #dbe3ef;border-radius:14px;padding:18px;margin:14px 0;box-shadow:0 4px 18px #17203310}table{width:100%;border-collapse:collapse}td,th{padding:9px;border-bottom:1px solid #edf2f7;text-align:left;vertical-align:top}code,pre{font-family:ui-monospace,monospace}.btn{display:inline-block;padding:10px 14px;background:#1d4ed8;color:#fff;text-decoration:none;border-radius:9px}pre{white-space:pre-wrap;word-break:break-word;background:#0f172a;color:#e2e8f0;padding:14px;border-radius:10px;max-height:420px;overflow:auto}.warn{background:#fff7ed;border-color:#fed7aa}</style></head><body><div class="wrap">
<h1>ShahkotPK Emergency Diagnostic 9.0.2</h1>
<p>This page is standalone and does not load ShahkotPK bootstrap/database code.</p>
<?php if(isset($_GET['reset_done'])):?><div class="card"><b>OPcache/stat cache reset attempted.</b> Refresh the main website now.</div><?php endif;?>
<div class="card"><h2>Server runtime</h2><table>
<tr><th>PHP version</th><td><?=h902(PHP_VERSION)?></td></tr>
<tr><th>PHP SAPI</th><td><?=h902(PHP_SAPI)?></td></tr>
<tr><th>memory_limit</th><td><?=h902(ini_get('memory_limit'))?></td></tr>
<tr><th>max_execution_time</th><td><?=h902(ini_get('max_execution_time'))?></td></tr>
<tr><th>PDO MySQL</th><td><?=yes902(extension_loaded('pdo_mysql'))?></td></tr>
<tr><th>mbstring</th><td><?=yes902(extension_loaded('mbstring'))?></td></tr>
<tr><th>OpenSSL</th><td><?=yes902(extension_loaded('openssl'))?></td></tr>
<tr><th>cURL</th><td><?=yes902(extension_loaded('curl'))?></td></tr>
<tr><th>OPcache</th><td><?=yes902(function_exists('opcache_get_status'))?></td></tr>
</table><p><a class="btn" href="?key=<?=h902($expected)?>&reset=1">Reset PHP OPcache</a></p></div>
<div class="card"><h2>Core files</h2><table><tr><th>Path</th><th>Exists</th><th>Writable</th></tr>
<?php foreach($checks as $label=>$path):?><tr><td><?=h902($label)?></td><td><?=yes902(file_exists($path))?></td><td><?=yes902(is_writable($path))?></td></tr><?php endforeach;?>
</table></div>
<div class="card warn"><h2>Recent PHP/server errors</h2><p>Refresh shahkotpk.com once, then refresh this diagnostic page. Send the last fatal/error lines shown below.</p>
<?php $found=false; foreach(array_unique($logs) as $lp){ $txt=tail902($lp,80000); if($txt!==''){$found=true; echo '<h3>'.h902($lp).'</h3><pre>'.h902($txt).'</pre>';}} if(!$found) echo '<p>No readable error_log found from PHP. Use cPanel → Metrics → Errors and send the newest lines.</p>'; ?>
</div>
<div class="card"><b>Security:</b> delete <code>shahkot-emergency-902.php</code> after diagnosis.</div>
</div></body></html>
