<?php
function page_start(string $title,bool $admin=false):void{
    global $config;
    $currentPath=$_SERVER['PHP_SELF']??'';
    $currentUser=function_exists('current_user')?current_user():null;
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($title)?> - <?=e($config['app_name']??'ShahkotPK')?></title>
<?php if($admin):?>
<link rel="stylesheet" href="/assets/admin-pro-1.3.0.css?v=130">
<style>
html,body{margin:0;background:#f3f6fb;color:#172033;font-family:Arial,sans-serif}.sidebar{position:fixed;left:0;top:0;bottom:0;width:264px;background:#111827;color:#fff;padding:18px;overflow:auto}.main{margin-left:264px;min-height:100vh}.container{max-width:1660px;margin:auto;padding:24px}.card{background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:20px;margin-bottom:18px}.btn{display:inline-block;background:#2563eb;color:#fff!important;border:0;border-radius:10px;padding:9px 13px;text-decoration:none}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:15px}.input,select,textarea,input{box-sizing:border-box;max-width:100%;padding:10px;border:1px solid #cad5e2;border-radius:10px}table{width:100%;border-collapse:collapse}th,td{padding:10px;border-bottom:1px solid #edf1f6;text-align:left}@media(max-width:920px){.sidebar{position:static;width:auto}.main{margin-left:0}}
</style>
<?php else:?>
<link rel="stylesheet" href="/assets/shahkotpk-1.1.2.css?v=112">
<?php endif;?>
</head>
<body class="<?=$admin?'admin-body':'public-body'?>">
<?php if($admin):?>
<aside class="sidebar">
<div class="brand-block"><div class="brand-icon">S</div><div><h2>ShahkotPK</h2><small>City Portal Admin</small></div></div>
<div class="nav-section">Dashboard</div>
<a class="<?=str_contains($currentPath,'/admin/index.php')?'active':''?>" href="/admin/index.php">▣ Overview</a>
<a class="<?=str_contains($currentPath,'/admin/homepage.php')?'active':''?>" href="/admin/homepage.php">◈ Homepage Builder</a>

<div class="nav-section">Directory</div>
<a class="<?=str_contains($currentPath,'/admin/businesses.php')?'active':''?>" href="/admin/businesses.php">▤ Businesses</a>
<a class="<?=str_contains($currentPath,'/admin/categories.php')?'active':''?>" href="/admin/categories.php">▦ Categories</a>
<a class="<?=str_contains($currentPath,'/admin/cities.php')?'active':''?>" href="/admin/cities.php">⌖ Cities</a>
<a class="<?=str_contains($currentPath,'/admin/users.php')?'active':''?>" href="/admin/users.php">◉ Users</a>

<div class="nav-section">Revenue</div>
<a class="<?=str_contains($currentPath,'/admin/plans.php')?'active':''?>" href="/admin/plans.php">▱ Subscription Plans</a>
<a class="<?=str_contains($currentPath,'/admin/ads.php')?'active':''?>" href="/admin/ads.php">◫ Advertisements</a>

<div class="nav-section">System</div>
<a class="<?=str_contains($currentPath,'/admin/updates.php')?'active':''?>" href="/admin/updates.php">⇧ System Updates</a>
<a class="<?=str_contains($currentPath,'/admin/settings.php')?'active':''?>" href="/admin/settings.php">⚙ Settings</a>
<a href="/logout.php">↩ Logout</a>
</aside>
<main class="main">
<div class="admin-topbar">
<div><h1 class="page-title"><?=e($title)?></h1><div class="page-subtitle">ShahkotPK administration & city business analytics</div></div>
<div class="admin-tools"><span class="chip">Today <?=date('d M Y')?></span><span class="chip">PKT <?=date('h:i A')?></span><span class="chip"><span class="avatar"><?=e(strtoupper(substr($currentUser['name']??'A',0,1)))?></span><?=e($currentUser['name']??'Admin')?></span></div>
</div>
<?php endif;?>
<div class="container">
<?php } ?>
