<?php
require __DIR__.'/../app/bootstrap.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_check();
    $l=trim($_POST['login']??'');
    $p=$_POST['password']??'';
    $q=db()->prepare("SELECT * FROM users WHERE email=? AND role='admin' LIMIT 1");
    $q->execute([$l]);
    $u=$q->fetch();
    if($u && $u['status']==='active' && password_verify($p,$u['password_hash'])){
        session_regenerate_id(true);
        $_SESSION['user_id']=$u['id'];
        header('Location: /admin/index.php');
        exit;
    }
    $error='Invalid admin credentials.';
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Login - ShahkotPK</title>
<link rel="stylesheet" href="/assets/admin-pro-1.3.0.css?v=130">
</head>
<body>
<div class="login-shell">
    <div class="login-wrap">
        <div class="login-showcase">
            <div class="login-logo">
                <div class="brand-icon">S</div>
                <div>
                    <strong style="font-size:24px">ShahkotPK</strong>
                    <div style="color:#bfdbfe">Bootstrap-style Admin Panel</div>
                </div>
            </div>
            <h1>Control your city portal from one premium dashboard.</h1>
            <p>Manage homepage modules, local businesses, users, subscriptions, ads and system updates with a modern admin experience.</p>
            <div class="preview-grid">
                <div class="preview-box"><strong>Analytics</strong><div class="mini-bars"><span style="height:36px"></span><span style="height:56px"></span><span style="height:44px"></span><span style="height:66px"></span></div></div>
                <div class="preview-box"><strong>Users</strong><div class="mini-bars"><span style="height:28px"></span><span style="height:45px"></span><span style="height:60px"></span><span style="height:52px"></span></div></div>
                <div class="preview-box"><strong>Directory</strong><div class="mini-bars"><span style="height:50px"></span><span style="height:40px"></span><span style="height:64px"></span><span style="height:70px"></span></div></div>
                <div class="preview-box"><strong>Updates</strong><div class="mini-bars"><span style="height:22px"></span><span style="height:48px"></span><span style="height:58px"></span><span style="height:35px"></span></div></div>
            </div>
        </div>

        <div class="login-card">
            <div class="login-logo">
                <div class="brand-icon">A</div>
                <div>
                    <strong style="font-size:20px">Admin Sign In</strong>
                    <div class="muted">Access the ShahkotPK control panel</div>
                </div>
            </div>

            <?php if(isset($error)): ?><div class="error"><?=e($error)?></div><?php endif; ?>

            <form method="post">
                <input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
                <label>Email</label>
                <input class="input" name="login" value="admin@cityhub.local" required>

                <label>Password</label>
                <input class="input" type="password" name="password" required>

                <div style="height:6px"></div>
                <button class="btn" style="width:100%">Login to Admin Panel</button>
            </form>

            <div style="height:12px"></div>
            <div class="card" style="background:#f8fbff;margin-bottom:0">
                <strong>Default Admin</strong>
                <div class="muted">Email: admin@cityhub.local</div>
                <div class="muted">Password: Arman@123</div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
