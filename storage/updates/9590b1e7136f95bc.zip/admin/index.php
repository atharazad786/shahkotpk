<?php
require __DIR__.'/../app/bootstrap.php';
require_admin();

function stat_scalar(string $sql, array $params=[]): float {
    try{
        $q=db()->prepare($sql);$q->execute($params);
        return (float)($q->fetchColumn() ?: 0);
    }catch(Throwable $e){return 0;}
}
function safe_rows(string $sql,array $params=[]): array {
    try{$q=db()->prepare($sql);$q->execute($params);return $q->fetchAll();}catch(Throwable $e){return [];}
}

$totalUsers=(int)stat_scalar("SELECT COUNT(*) FROM users");
$customers=(int)stat_scalar("SELECT COUNT(*) FROM users WHERE role='customer'");
$shopkeepers=(int)stat_scalar("SELECT COUNT(*) FROM users WHERE role='shopkeeper'");
$admins=(int)stat_scalar("SELECT COUNT(*) FROM users WHERE role='admin'");
$blockedUsers=(int)stat_scalar("SELECT COUNT(*) FROM users WHERE status='blocked'");

$totalBusinesses=(int)stat_scalar("SELECT COUNT(*) FROM businesses");
$verifiedBusinesses=(int)stat_scalar("SELECT COUNT(*) FROM businesses WHERE verification_status='verified'");
$pendingBusinesses=(int)stat_scalar("SELECT COUNT(*) FROM businesses WHERE verification_status='pending'");
$featuredBusinesses=(int)stat_scalar("SELECT COUNT(*) FROM businesses WHERE is_featured=1 AND status=1");
$activeBusinesses=(int)stat_scalar("SELECT COUNT(*) FROM businesses WHERE status=1");

$totalCategories=(int)stat_scalar("SELECT COUNT(*) FROM categories");
$totalCities=(int)stat_scalar("SELECT COUNT(*) FROM cities");
$activeCategories=(int)stat_scalar("SELECT COUNT(*) FROM categories WHERE status=1");

$totalSubscriptions=(int)stat_scalar("SELECT COUNT(*) FROM subscriptions");
$activeSubscriptions=(int)stat_scalar("SELECT COUNT(*) FROM subscriptions WHERE status='active'");
$pendingSubscriptions=(int)stat_scalar("SELECT COUNT(*) FROM subscriptions WHERE status='pending'");
$expiredSubscriptions=(int)stat_scalar("SELECT COUNT(*) FROM subscriptions WHERE status='expired'");
$subscriptionValue=stat_scalar("SELECT COALESCE(SUM(amount),0) FROM subscriptions WHERE status='active'");

$totalAds=(int)stat_scalar("SELECT COUNT(*) FROM advertisements");
$activeAds=(int)stat_scalar("SELECT COUNT(*) FROM advertisements WHERE status='active'");
$scheduledAds=(int)stat_scalar("SELECT COUNT(*) FROM advertisements WHERE status='scheduled'");
$completedAds=(int)stat_scalar("SELECT COUNT(*) FROM advertisements WHERE status='completed'");
$adBudget=stat_scalar("SELECT COALESCE(SUM(budget),0) FROM advertisements WHERE status IN ('active','scheduled','completed')");

$updatesInstalled=(int)stat_scalar("SELECT COUNT(*) FROM system_updates WHERE status='success'");
$lastUpdate=safe_rows("SELECT version,created_at FROM system_updates WHERE status='success' ORDER BY id DESC LIMIT 1");
$lastUpdate=$lastUpdate[0]??null;

$recentUsers=safe_rows("SELECT id,name,email,phone,role,status,created_at FROM users ORDER BY id DESC LIMIT 7");
$recentBusinesses=safe_rows("SELECT b.id,b.name,b.verification_status,b.is_featured,b.status,c.name city_name,cat.name category_name FROM businesses b LEFT JOIN cities c ON c.id=b.city_id LEFT JOIN categories cat ON cat.id=b.category_id ORDER BY b.id DESC LIMIT 7");
$recentSubscriptions=safe_rows("SELECT s.id,s.status,s.amount,s.start_date,s.end_date,b.name business_name,p.name plan_name FROM subscriptions s LEFT JOIN businesses b ON b.id=s.business_id LEFT JOIN subscription_plans p ON p.id=s.plan_id ORDER BY s.id DESC LIMIT 7");
$recentAds=safe_rows("SELECT id,title,placement,status,budget,created_at FROM advertisements ORDER BY id DESC LIMIT 6");

$monthlyUsers=safe_rows("SELECT DATE_FORMAT(created_at,'%Y-%m') ym,COUNT(*) c FROM users WHERE created_at >= DATE_SUB(CURDATE(),INTERVAL 5 MONTH) GROUP BY DATE_FORMAT(created_at,'%Y-%m') ORDER BY ym");
$monthlyBusinesses=safe_rows("SELECT DATE_FORMAT(created_at,'%Y-%m') ym,COUNT(*) c FROM businesses WHERE created_at >= DATE_SUB(CURDATE(),INTERVAL 5 MONTH) GROUP BY DATE_FORMAT(created_at,'%Y-%m') ORDER BY ym");

$months=[];
for($i=5;$i>=0;$i--){
    $ts=strtotime("-{$i} months");
    $key=date('Y-m',$ts);
    $months[$key]=['label'=>date('M', $ts),'users'=>0,'businesses'=>0];
}
foreach($monthlyUsers as $r) if(isset($months[$r['ym']])) $months[$r['ym']]['users']=(int)$r['c'];
foreach($monthlyBusinesses as $r) if(isset($months[$r['ym']])) $months[$r['ym']]['businesses']=(int)$r['c'];

$maxChart=1;
foreach($months as $m)$maxChart=max($maxChart,$m['users'],$m['businesses']);

$verifyTotal=max(1,$verifiedBusinesses+$pendingBusinesses+max(0,$totalBusinesses-$verifiedBusinesses-$pendingBusinesses));
$verifiedPct=round($verifiedBusinesses/$verifyTotal*100,1);
$pendingPct=round($pendingBusinesses/$verifyTotal*100,1);
$otherPct=max(0,100-$verifiedPct-$pendingPct);
$donutStyle="background:conic-gradient(#059669 0 {$verifiedPct}%, #d97706 {$verifiedPct}% ".($verifiedPct+$pendingPct)."%, #94a3b8 ".($verifiedPct+$pendingPct)."% 100%)";

require __DIR__.'/../app/layout.php';
page_start('Full Stats Dashboard',true);
?>

<div class="dashboard-heading">
<div><h2>Platform Overview</h2><p>Live operational statistics from your ShahkotPK database.</p></div>
<div style="display:flex;gap:8px;flex-wrap:wrap">
<a class="btn ghost" href="/" target="_blank">View Website ↗</a>
<a class="btn" href="/admin/homepage.php">Homepage Builder</a>
<a class="btn secondary" href="/admin/updates.php">System Updates</a>
</div>
</div>

<div class="card" style="padding:14px 18px">
<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
<strong style="margin-right:6px">System Status:</strong>
<span class="badge <?=feature_enabled('registration_enabled',true)?'success':'danger'?>">Registration <?=feature_enabled('registration_enabled',true)?'ON':'OFF'?></span>
<span class="badge <?=feature_enabled('directory_enabled',true)?'success':'danger'?>">Directory <?=feature_enabled('directory_enabled',true)?'ON':'OFF'?></span>
<span class="badge <?=feature_enabled('subscriptions_enabled',true)?'success':'danger'?>">Subscriptions <?=feature_enabled('subscriptions_enabled',true)?'ON':'OFF'?></span>
<span class="badge <?=feature_enabled('advertisements_enabled',true)?'success':'danger'?>">Ads <?=feature_enabled('advertisements_enabled',true)?'ON':'OFF'?></span>
<span class="badge <?=feature_enabled('update_system_enabled',true)?'success':'danger'?>">Updater <?=feature_enabled('update_system_enabled',true)?'ON':'OFF'?></span>
<span class="badge <?=feature_enabled('maintenance_mode',false)?'warning':'success'?>">Maintenance <?=feature_enabled('maintenance_mode',false)?'ON':'OFF'?></span>
<a class="btn ghost" href="/admin/settings.php" style="margin-left:auto">Configure Settings</a>
</div>
</div>

<div class="stats-grid">
<div class="stat-card blue"><div class="stat-head"><span class="stat-label">Total Users</span><span class="stat-icon">U</span></div><div class="stat-number"><?=e($totalUsers)?></div><div class="stat-caption"><?=e($shopkeepers)?> shopkeepers · <?=e($customers)?> customers</div></div>
<div class="stat-card green"><div class="stat-head"><span class="stat-label">Businesses</span><span class="stat-icon">B</span></div><div class="stat-number"><?=e($totalBusinesses)?></div><div class="stat-caption"><?=e($verifiedBusinesses)?> verified · <?=e($featuredBusinesses)?> featured</div></div>
<div class="stat-card violet"><div class="stat-head"><span class="stat-label">Active Subscriptions</span><span class="stat-icon">S</span></div><div class="stat-number"><?=e($activeSubscriptions)?></div><div class="stat-caption">Rs <?=e(number_format($subscriptionValue,0))?> active value</div></div>
<div class="stat-card amber"><div class="stat-head"><span class="stat-label">Advertising</span><span class="stat-icon">A</span></div><div class="stat-number"><?=e($totalAds)?></div><div class="stat-caption">Rs <?=e(number_format($adBudget,0))?> campaign budget</div></div>

<div class="stat-card cyan"><div class="stat-head"><span class="stat-label">Categories</span><span class="stat-icon">C</span></div><div class="stat-number"><?=e($totalCategories)?></div><div class="stat-caption"><?=e($activeCategories)?> active categories</div></div>
<div class="stat-card indigo"><div class="stat-head"><span class="stat-label">Cities</span><span class="stat-icon">L</span></div><div class="stat-number"><?=e($totalCities)?></div><div class="stat-caption">Multi-city architecture ready</div></div>
<div class="stat-card red"><div class="stat-head"><span class="stat-label">Pending Businesses</span><span class="stat-icon">!</span></div><div class="stat-number"><?=e($pendingBusinesses)?></div><div class="stat-caption">Require verification review</div></div>
<div class="stat-card slate"><div class="stat-head"><span class="stat-label">Installed Updates</span><span class="stat-icon">↑</span></div><div class="stat-number"><?=e($updatesInstalled)?></div><div class="stat-caption"><?=$lastUpdate?'Latest v'.e($lastUpdate['version']):'No update history yet'?></div></div>
</div>

<div class="dashboard-grid">
<div class="card">
<div class="panel-title"><div><h3>6-Month Growth</h3><span>New users vs new businesses</span></div><span>Database activity</span></div>
<div class="chart-wrap"><div class="bar-chart">
<?php foreach($months as $m):
$uh=max(3,round(($m['users']/$maxChart)*205));
$bh=max(3,round(($m['businesses']/$maxChart)*205)); ?>
<div class="bar-group">
<div class="bars">
<div class="bar users" style="height:<?=$uh?>px" title="Users: <?=e($m['users'])?>"></div>
<div class="bar businesses" style="height:<?=$bh?>px" title="Businesses: <?=e($m['businesses'])?>"></div>
</div>
<div class="bar-value"><?=e($m['users'])?> / <?=e($m['businesses'])?></div>
<div class="bar-label"><?=e($m['label'])?></div>
</div>
<?php endforeach;?>
</div></div>
<div style="display:flex;gap:18px;margin-top:10px"><span class="muted"><b style="color:#2563eb">■</b> Users</span><span class="muted"><b style="color:#059669">■</b> Businesses</span></div>
</div>

<div class="card">
<div class="panel-title"><div><h3>Business Verification</h3><span>Current directory quality</span></div></div>
<div class="donut-wrap"><div class="donut" style="<?=e($donutStyle)?>"></div></div>
<div class="legend">
<div><i style="background:#059669"></i>Verified <?=e($verifiedBusinesses)?></div>
<div><i style="background:#d97706"></i>Pending <?=e($pendingBusinesses)?></div>
<div><i style="background:#94a3b8"></i>Other <?=e(max(0,$totalBusinesses-$verifiedBusinesses-$pendingBusinesses))?></div>
<div><i style="background:#2563eb"></i>Featured <?=e($featuredBusinesses)?></div>
</div>
</div>
</div>

<div class="dashboard-grid equal">
<div class="card">
<div class="panel-title"><div><h3>Subscription Status</h3><span>Billing and plan records</span></div><a href="/admin/plans.php" class="btn ghost">Plans</a></div>
<div class="mini-list">
<div class="mini-row"><div><strong>Active</strong><small>Currently running subscriptions</small></div><div class="mini-value"><?=e($activeSubscriptions)?></div></div>
<div class="mini-row"><div><strong>Pending</strong><small>Awaiting activation/payment</small></div><div class="mini-value"><?=e($pendingSubscriptions)?></div></div>
<div class="mini-row"><div><strong>Expired</strong><small>Renewal opportunities</small></div><div class="mini-value"><?=e($expiredSubscriptions)?></div></div>
<div class="mini-row"><div><strong>Active Value</strong><small>Sum of active subscription amounts</small></div><div class="mini-value">Rs <?=e(number_format($subscriptionValue,0))?></div></div>
</div>
</div>

<div class="card">
<div class="panel-title"><div><h3>Advertisement Status</h3><span>Campaign operational summary</span></div><a href="/admin/ads.php" class="btn ghost">Ads</a></div>
<div class="mini-list">
<div class="mini-row"><div><strong>Active Ads</strong><small>Currently visible campaigns</small></div><div class="mini-value"><?=e($activeAds)?></div></div>
<div class="mini-row"><div><strong>Scheduled</strong><small>Future advertisement campaigns</small></div><div class="mini-value"><?=e($scheduledAds)?></div></div>
<div class="mini-row"><div><strong>Completed</strong><small>Finished campaigns</small></div><div class="mini-value"><?=e($completedAds)?></div></div>
<div class="mini-row"><div><strong>Total Budget</strong><small>Active/scheduled/completed budget</small></div><div class="mini-value">Rs <?=e(number_format($adBudget,0))?></div></div>
</div>
</div>
</div>

<div class="dashboard-grid">
<div class="card">
<div class="panel-title"><div><h3>Recent Businesses</h3><span>Latest directory listings</span></div><a class="btn ghost" href="/admin/businesses.php">Manage</a></div>
<?php if($recentBusinesses):?>
<table><tr><th>Business</th><th>Category</th><th>City</th><th>Status</th><th>Featured</th></tr>
<?php foreach($recentBusinesses as $b):?><tr>
<td><strong><?=e($b['name'])?></strong></td><td><?=e($b['category_name']?:'—')?></td><td><?=e($b['city_name']?:'—')?></td>
<td><span class="badge <?=$b['verification_status']==='verified'?'success':($b['verification_status']==='pending'?'warning':'slate')?>"><?=e($b['verification_status'])?></span></td>
<td><?=$b['is_featured']?'★ Yes':'No'?></td></tr><?php endforeach;?></table>
<?php else:?><div class="empty-state">No business records yet.</div><?php endif;?>
</div>

<div class="card">
<div class="panel-title"><div><h3>User Composition</h3><span>Account type distribution</span></div><a class="btn ghost" href="/admin/users.php">Users</a></div>
<div class="mini-list">
<div class="mini-row"><div><strong>Customers</strong><small>General visitor accounts</small></div><div class="mini-value"><?=e($customers)?></div></div>
<div class="mini-row"><div><strong>Shopkeepers</strong><small>Business owner accounts</small></div><div class="mini-value"><?=e($shopkeepers)?></div></div>
<div class="mini-row"><div><strong>Administrators</strong><small>Admin users</small></div><div class="mini-value"><?=e($admins)?></div></div>
<div class="mini-row"><div><strong>Blocked</strong><small>Disabled accounts</small></div><div class="mini-value"><?=e($blockedUsers)?></div></div>
</div>
</div>
</div>

<div class="dashboard-grid equal">
<div class="card">
<div class="panel-title"><div><h3>Recent Users</h3><span>Newest registered accounts</span></div></div>
<?php if($recentUsers):?><table><tr><th>User</th><th>Role</th><th>Status</th><th>Joined</th></tr>
<?php foreach($recentUsers as $u):?><tr><td><strong><?=e($u['name'])?></strong><br><span class="muted"><?=e($u['email']?:$u['phone'])?></span></td>
<td><span class="badge info"><?=e($u['role'])?></span></td><td><span class="badge <?=$u['status']==='active'?'success':'danger'?>"><?=e($u['status'])?></span></td><td><?=e(date('d M Y',strtotime($u['created_at'])))?></td></tr><?php endforeach;?></table>
<?php else:?><div class="empty-state">No users available.</div><?php endif;?>
</div>

<div class="card">
<div class="panel-title"><div><h3>Recent Subscriptions</h3><span>Latest plan activity</span></div></div>
<?php if($recentSubscriptions):?><table><tr><th>Business</th><th>Plan</th><th>Amount</th><th>Status</th></tr>
<?php foreach($recentSubscriptions as $s):?><tr><td><?=e($s['business_name']?:'—')?></td><td><?=e($s['plan_name']?:'—')?></td><td>Rs <?=e(number_format((float)$s['amount'],0))?></td><td><span class="badge <?=$s['status']==='active'?'success':($s['status']==='pending'?'warning':'slate')?>"><?=e($s['status'])?></span></td></tr><?php endforeach;?></table>
<?php else:?><div class="empty-state">No subscription records available.</div><?php endif;?>
</div>
</div>

<div class="card">
<div class="panel-title"><div><h3>Recent Advertisement Activity</h3><span>Latest ad campaigns and placements</span></div><a class="btn ghost" href="/admin/ads.php">Manage Ads</a></div>
<?php if($recentAds):?><table><tr><th>Campaign</th><th>Placement</th><th>Budget</th><th>Status</th><th>Created</th></tr>
<?php foreach($recentAds as $a):?><tr><td><strong><?=e($a['title'])?></strong></td><td><?=e($a['placement'])?></td><td>Rs <?=e(number_format((float)$a['budget'],0))?></td><td><span class="badge <?=$a['status']==='active'?'success':($a['status']==='scheduled'?'info':'slate')?>"><?=e($a['status'])?></span></td><td><?=e(date('d M Y',strtotime($a['created_at'])))?></td></tr><?php endforeach;?></table>
<?php else:?><div class="empty-state">No advertisement campaigns available.</div><?php endif;?>
</div>

<?php require __DIR__.'/../app/end.php';?>
