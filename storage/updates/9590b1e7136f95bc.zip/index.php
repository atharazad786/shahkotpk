<?php
require __DIR__.'/app/bootstrap.php';
require __DIR__.'/app/homepage.php';

$sections=homepage_sections();
usort($sections,fn($a,$b)=>(int)($a['order']??0)<=>(int)($b['order']??0));

$categories=[];
$featured=[];
try{
    $categories=db()->query("SELECT id,name,slug FROM categories WHERE status=1 ORDER BY name ASC LIMIT 24")->fetchAll();
    $featured=db()->query("SELECT b.*,c.name city_name,cat.name category_name FROM businesses b JOIN cities c ON c.id=b.city_id JOIN categories cat ON cat.id=b.category_id WHERE b.status=1 AND (b.verification_status='verified' OR b.is_featured=1) ORDER BY b.is_featured DESC,b.id DESC LIMIT 9")->fetchAll();
}catch(Throwable $e){}

function module_img(array $s): string {
    $i=trim((string)($s['image']??''));
    return $i ? "background-image:url('".e($i)."')" : '';
}
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="<?=e(setting('seo_description','Discover Shahkot businesses, services and city information.'))?>">
<meta name="keywords" content="<?=e(setting('seo_keywords','Shahkot, business directory'))?>">
<?php if(setting_bool('robots_index',true)):?><meta name="robots" content="index,follow"><?php else:?><meta name="robots" content="noindex,nofollow"><?php endif;?>
<?php if(setting('og_image','')):?><meta property="og:image" content="<?=e(setting('og_image',''))?>"><?php endif;?>
<title><?=e(setting('seo_title',setting('site_name','ShahkotPK').' — '.setting('site_tagline','Your Digital City Guide')))?></title>
<?php if(setting('favicon_url','')):?><link rel="icon" href="<?=e(setting('favicon_url',''))?>"><?php endif;?>
<link rel="stylesheet" href="/assets/shahkotpk-1.1.2.css?v=112">
<style>:root{--green:<?=e(setting('brand_primary_color','#176b46'))?>;--ink:<?=e(setting('brand_secondary_color','#0f3d29'))?>}</style>
</head>
<body><div class="site-wrap">
<?php foreach($sections as $s):
if(empty($s['enabled'])) continue;
$type=$s['type']??'custom';
$items=section_items($s['items']??'');

// Global settings switches can disable whole classes of homepage modules.
if($type==='hero' && !feature_enabled('homepage_search_enabled',true)) continue;
if($type==='directory' && (!feature_enabled('homepage_directory_enabled',true) || !feature_enabled('directory_enabled',true))) continue;
if($type==='featured' && !feature_enabled('homepage_featured_enabled',true)) continue;
if($type==='gallery' && !feature_enabled('homepage_gallery_enabled',true)) continue;
if($type==='info_cards' && !feature_enabled('homepage_city_info_enabled',true)) continue;
?>

<?php if($type==='topbar'): ?>
<div class="city-topbar"><div class="city-shell">
<div><?=e($s['content'] ?: $s['subtitle'])?></div>
<div class="top-links"><?php foreach($items as $it):?><a href="<?=e(safe_link($it['link']))?>"><?=e($it['title'])?></a><?php endforeach;?></div>
</div></div>

<?php elseif($type==='header'): ?>
<header class="city-header"><div class="city-shell city-header-inner">
<a class="brand" href="/"><span class="brand-mark">S</span><span><strong><?=e($s['title'])?></strong><small><?=e($s['subtitle'])?></small></span></a>
<nav class="city-nav"><?php foreach($items as $it):?><a class="<?=str_contains(strtolower($it['title']),'register')?'nav-cta':''?>" href="<?=e(safe_link($it['link']))?>"><?=e($it['title'])?></a><?php endforeach;?></nav>
</div></header>

<?php elseif($type==='hero'): ?>
<section class="hero <?=$s['image']?'has-image':''?>" style="<?=module_img($s)?>">
<div class="hero-inner">
<span class="eyebrow">● <?=e($s['subtitle'])?></span>
<h1><?=e($s['title'])?></h1>
<p><?=e($s['content'])?></p>
<?php if(feature_enabled('search_enabled',true)):?><form class="search-panel" action="/search.php" method="get">
<input name="q" placeholder="Search businesses, services, places..." aria-label="Search Shahkot">
<button type="submit">Search Shahkot</button>
</form><?php endif;?>
<div class="popular-links"><?php foreach($items as $it):?><a href="<?=e(safe_link($it['link']))?>"><?=e($it['title'])?></a><?php endforeach;?></div>
</div></section>

<?php elseif($type==='info_cards'): ?>
<div class="city-shell"><div class="info-grid">
<?php foreach($items as $idx=>$it):?>
<div class="info-card"><strong><?=e($it['title'])?></strong>
<span class="<?=stripos($it['title'],'time')!==false?'js-city-time':''?>"><?=e($it['text'])?></span></div>
<?php endforeach;?>
</div></div>

<?php elseif($type==='cta'): ?>
<section class="section"><div class="city-shell"><div class="cta-block">
<div><div class="section-kicker"><?=e($s['subtitle'])?></div><h2><?=e($s['title'])?></h2><p><?=e($s['content'])?></p></div>
<div><?php foreach($items as $it):?><a class="btn btn-primary" href="<?=e(safe_link($it['link']))?>"><?=e($it['title'])?> →</a><?php endforeach;?></div>
</div></div></section>

<?php elseif($type==='content'): ?>
<section class="section alt"><div class="city-shell"><div class="content-split">
<div class="content-copy"><div class="section-kicker"><?=e($s['subtitle'])?></div><h2><?=e($s['title'])?></h2><p><?=nl2br(e($s['content']))?></p></div>
<div class="content-image" style="<?=module_img($s)?>"></div>
</div></div></section>

<?php elseif($type==='directory'): ?>
<section class="section"><div class="city-shell">
<div class="section-head"><div><div class="section-kicker"><?=e($s['subtitle'])?></div><h2><?=e($s['title'])?></h2><p><?=e($s['content'])?></p></div></div>
<?php if($categories):?><div class="category-grid">
<?php foreach($categories as $cat):?><a class="category-card" href="/search.php?category=<?=urlencode($cat['slug'])?>"><span class="category-icon"><?=e(mb_strtoupper(mb_substr($cat['name'],0,1)))?></span><strong><?=e($cat['name'])?></strong><span>Explore listings →</span></a><?php endforeach;?>
</div><?php else:?><div class="empty-state">Categories can be added from Admin → Categories.</div><?php endif;?>
</div></section>

<?php elseif($type==='featured'): ?>
<section class="section alt"><div class="city-shell">
<div class="section-head"><div><div class="section-kicker"><?=e($s['subtitle'])?></div><h2><?=e($s['title'])?></h2><p><?=e($s['content'])?></p></div><a class="btn btn-green" href="/search.php">View Directory</a></div>
<?php if($featured):?><div class="business-grid">
<?php foreach($featured as $b):?><article class="business-card"><div class="business-cover" <?=$b['image']?'style="background-image:url(\''.e($b['image']).'\')"':''?>></div><div class="business-body"><span class="verified"><?=e($b['verification_status']==='verified'?'✓ Verified':'Featured')?></span><h3><?=e($b['name'])?></h3><div class="business-meta"><?=e($b['category_name'])?> · <?=e($b['city_name'])?></div><p><a href="/business.php?slug=<?=urlencode($b['slug'])?>">View Business →</a></p></div></article><?php endforeach;?>
</div><?php else:?><div class="empty-state">Featured businesses will appear here after you add/verify them from Admin.</div><?php endif;?>
</div></section>

<?php elseif($type==='gallery'): ?>
<section class="section"><div class="city-shell">
<div class="section-head"><div><div class="section-kicker"><?=e($s['subtitle'])?></div><h2><?=e($s['title'])?></h2><p><?=e($s['content'])?></p></div></div>
<div class="gallery-grid"><?php foreach($items as $it):?><div class="gallery-card" <?=$it['image']?'style="background-image:url(\''.e($it['image']).'\')"':''?>><div class="gallery-text"><strong><?=e($it['title'])?></strong><span><?=e($it['text'])?></span></div></div><?php endforeach;?></div>
</div></section>

<?php elseif($type==='links'): ?>
<section class="section alt"><div class="city-shell"><div class="section-head"><div><div class="section-kicker"><?=e($s['subtitle'])?></div><h2><?=e($s['title'])?></h2></div></div>
<div class="link-grid"><?php foreach($items as $it):?><a class="city-link" href="<?=e(safe_link($it['link']))?>"><?=e($it['title'])?></a><?php endforeach;?></div>
</div></section>

<?php elseif($type==='footer'): ?>
<footer class="site-footer"><div class="city-shell"><div class="footer-grid"><div><div class="footer-title"><?=e($s['title'])?></div><div><?=e($s['subtitle'])?></div></div><div class="footer-links"><?php foreach($items as $it):?><a href="<?=e(safe_link($it['link']))?>"><?=e($it['title'])?></a><?php endforeach;?></div></div><div class="footer-copy"><?=e($s['content'])?></div></div></footer>

<?php else: ?>
<section class="section"><div class="city-shell"><div class="custom-card">
<div class="section-kicker"><?=e($s['subtitle'])?></div><h2><?=e($s['title'])?></h2><p><?=nl2br(e($s['content']))?></p>
<?php if($items):?><div class="custom-items"><?php foreach($items as $it):?><div class="custom-item"><strong><?=e($it['title'])?></strong><div><?=e($it['text'])?></div><?php if($it['link']):?><a href="<?=e(safe_link($it['link']))?>">Open →</a><?php endif;?></div><?php endforeach;?></div><?php endif;?>
</div></div></section>
<?php endif; ?>

<?php endforeach;?>
</div>
<script>
(function(){
 const els=document.querySelectorAll('.js-city-time');
 if(!els.length)return;
 function update(){
   const d=new Date();
   const text=new Intl.DateTimeFormat('en-PK',{timeZone:'Asia/Karachi',weekday:'short',day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(d)+' PKT';
   els.forEach(el=>el.textContent=text);
 }
 update();setInterval(update,1000);
})();
</script>
</body></html>
