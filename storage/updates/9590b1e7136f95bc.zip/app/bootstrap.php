<?php
declare(strict_types=1);

$configFile = __DIR__ . '/../config/config.php';

if (!is_file($configFile)) {
    if (is_file(__DIR__ . '/../install.php')) {
        header('Location: /install.php', true, 302);
        exit;
    }
    http_response_code(500);
    exit('CityHub configuration is missing.');
}

$config = require $configFile;

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name($config['session_name'] ?? 'cityhub_session');
    session_start();
}

function db(): PDO {
    static $pdo = null;
    global $config;
    if ($pdo instanceof PDO) return $pdo;

    $c = $config['db'];
    $pdo = new PDO(
        "mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset=utf8mb4",
        $c['user'],
        $c['pass'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
    return $pdo;
}

function e($v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function csrf_token(): string {
    if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['_csrf'];
}

function csrf_check(): void {
    if (!hash_equals($_SESSION['_csrf'] ?? '', $_POST['_csrf'] ?? '')) {
        http_response_code(419);
        exit('Invalid security token. Refresh and try again.');
    }
}

function current_user(): ?array {
    if (empty($_SESSION['user_id'])) return null;
    $q = db()->prepare("SELECT * FROM users WHERE id=? LIMIT 1");
    $q->execute([$_SESSION['user_id']]);
    return $q->fetch() ?: null;
}

function require_admin(): array {
    $u = current_user();
    if (!$u || $u['role'] !== 'admin') {
        header('Location: /admin/login.php', true, 302);
        exit;
    }
    return $u;
}


require_once __DIR__ . '/settings.php';
ensure_default_settings();

date_default_timezone_set((string)setting('timezone','Asia/Karachi'));

if (maintenance_should_block()) {
    output_maintenance_page();
}
