<?php
require __DIR__.'/app/bootstrap.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();$l=trim($_POST['login']??'');$p=$_POST['password']??'';
 $q=db()->prepare("SELECT * FROM users WHERE email=? OR phone=? LIMIT 1");$q->execute([$l,$l]);$u=$q->fetch();
 if($u && $u['status']==='active' && password_verify($p,$u['password_hash'])){
   session_regenerate_id(true);$_SESSION['user_id']=$u['id'];
   header('Location: '.($u['role']==='admin'?'/admin/index.php':'/account.php'));exit;
 }
 $error='Invalid login.';
}
require __DIR__.'/app/layout.php';page_start('Login');?>
<div class="card"><h1>Login</h1><?php if(isset($error)):?><div class="error"><?=e($error)?></div><?php endif;?>
<form method="post"><input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
<label>Email / Phone</label><input class="input" name="login" required>
<label>Password</label><input class="input" type="password" name="password" required>
<button class="btn">Login</button></form></div>
<?php require __DIR__.'/app/end.php';?>
