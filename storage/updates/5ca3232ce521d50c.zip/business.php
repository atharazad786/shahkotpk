<?php
require __DIR__.'/app/bootstrap.php';
$slug=trim($_GET['slug']??'');
$stmt=db()->prepare("SELECT b.*,c.name city_name,cat.name category_name FROM businesses b JOIN cities c ON c.id=b.city_id JOIN categories cat ON cat.id=b.category_id WHERE b.slug=? AND b.status=1 LIMIT 1");
$stmt->execute([$slug]);$b=$stmt->fetch();
if(!$b){http_response_code(404);exit('Business not found.');}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($b['name'])?> - ShahkotPK</title><link rel="stylesheet" href="/assets/style.css"></head><body>
<div class="city-header"><div class="city-shell city-header-inner"><a class="brand" href="/"><span class="brand-mark">S</span><span><strong>ShahkotPK</strong><small>Business Showcase</small></span></a><a class="btn btn-green" href="/search.php">Back to Directory</a></div></div>
<section class="section"><div class="city-shell"><div class="content-split"><div class="content-copy"><div class="section-kicker"><?=e($b['category_name'])?> · <?=e($b['city_name'])?></div><h2><?=e($b['name'])?></h2><p><?=nl2br(e($b['description']))?></p><p><strong>Address:</strong> <?=e($b['address'])?></p><p>
<?php if($b['phone']):?><a class="btn btn-green" href="tel:<?=e($b['phone'])?>">Call</a><?php endif;?>
<?php if($b['whatsapp']):?><a class="btn btn-green" target="_blank" rel="noopener" href="https://wa.me/<?=e(preg_replace('/\D/','',$b['whatsapp']))?>">WhatsApp</a><?php endif;?>
</p></div><div class="content-image" <?=$b['image']?'style="background-image:url(\''.e($b['image']).'\')"':''?>></div></div></div></section>
</body></html>
