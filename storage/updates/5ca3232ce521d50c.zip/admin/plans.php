<?php
require __DIR__.'/../app/bootstrap.php';require_admin();require __DIR__.'/../app/layout.php';page_start('Plans',true);
$rows=db()->query('SELECT id,name,price,billing_period,status FROM subscription_plans ORDER BY id DESC LIMIT 100')->fetchAll();?>
<div class="card"><h1>Plans</h1><table><tr><th>id</th><th>name</th><th>price</th><th>billing_period</th><th>status</th></tr><?php foreach($rows as $r):?><tr><td><?=e($r['id'])?></td><td><?=e($r['name'])?></td><td><?=e($r['price'])?></td><td><?=e($r['billing_period'])?></td><td><?=e($r['status'])?></td></tr><?php endforeach;?></table></div>
<?php require __DIR__.'/../app/end.php';?>