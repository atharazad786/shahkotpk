<?php
require __DIR__.'/../app/bootstrap.php';require_admin();
$msg=$err=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  csrf_check();$action=$_POST['action']??'save';
  if($action==='delete'){db()->prepare("DELETE FROM businesses WHERE id=?")->execute([(int)$_POST['id']]);$msg='Business deleted.';}
  else{
   $id=(int)($_POST['id']??0);$owner=(int)$_POST['owner_id'];$city=(int)$_POST['city_id'];$category=(int)$_POST['category_id'];
   $name=trim($_POST['name']??'');$slug=trim($_POST['slug']??'');$desc=trim($_POST['description']??'');$phone=trim($_POST['phone']??'');$wa=trim($_POST['whatsapp']??'');$address=trim($_POST['address']??'');$image=trim($_POST['image']??'');
   $verification=$_POST['verification_status']??'pending';$featured=isset($_POST['is_featured'])?1:0;$status=isset($_POST['status'])?1:0;
   if(!$name||!$slug||!$owner||!$city||!$category)throw new RuntimeException('Business name, slug, owner, city and category are required.');
   if($id){db()->prepare("UPDATE businesses SET owner_id=?,city_id=?,category_id=?,name=?,slug=?,description=?,phone=?,whatsapp=?,address=?,image=?,verification_status=?,is_featured=?,status=? WHERE id=?")->execute([$owner,$city,$category,$name,$slug,$desc,$phone,$wa,$address,$image,$verification,$featured,$status,$id]);$msg='Business updated.';}
   else{db()->prepare("INSERT INTO businesses(owner_id,city_id,category_id,name,slug,description,phone,whatsapp,address,image,verification_status,is_featured,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)")->execute([$owner,$city,$category,$name,$slug,$desc,$phone,$wa,$address,$image,$verification,$featured,$status]);$msg='Business added.';}
  }
 }catch(Throwable $e){$err=$e->getMessage();}
}
$edit=null;if(isset($_GET['edit'])){$q=db()->prepare("SELECT * FROM businesses WHERE id=?");$q->execute([(int)$_GET['edit']]);$edit=$q->fetch();}
$users=db()->query("SELECT id,name,email,role FROM users WHERE status='active' ORDER BY name")->fetchAll();
$cities=db()->query("SELECT id,name FROM cities WHERE status=1 ORDER BY name")->fetchAll();
$categories=db()->query("SELECT id,name FROM categories WHERE status=1 ORDER BY name")->fetchAll();
$rows=db()->query("SELECT b.id,b.name,b.slug,b.verification_status,b.is_featured,b.status,u.name owner,c.name city_name,cat.name category_name FROM businesses b JOIN users u ON u.id=b.owner_id JOIN cities c ON c.id=b.city_id JOIN categories cat ON cat.id=b.category_id ORDER BY b.id DESC")->fetchAll();
require __DIR__.'/../app/layout.php';page_start('Businesses',true);?>
<div class="card"><h1>Business Management</h1><?php if($msg):?><div class="success"><?=e($msg)?></div><?php endif;?><?php if($err):?><div class="error"><?=e($err)?></div><?php endif;?>
<form method="post"><input type="hidden" name="_csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="id" value="<?=e($edit['id']??0)?>">
<label>Business Name</label><input class="input" name="name" value="<?=e($edit['name']??'')?>" required>
<label>Slug</label><input class="input" name="slug" value="<?=e($edit['slug']??'')?>" required>
<label>Owner</label><select class="input" name="owner_id" required><option value="">Select user</option><?php foreach($users as $u):?><option value="<?=e($u['id'])?>" <?=($edit['owner_id']??0)==$u['id']?'selected':''?>><?=e($u['name'])?> (<?=e($u['role'])?>)</option><?php endforeach;?></select>
<label>City</label><select class="input" name="city_id" required><?php foreach($cities as $c):?><option value="<?=e($c['id'])?>" <?=($edit['city_id']??0)==$c['id']?'selected':''?>><?=e($c['name'])?></option><?php endforeach;?></select>
<label>Category</label><select class="input" name="category_id" required><?php foreach($categories as $c):?><option value="<?=e($c['id'])?>" <?=($edit['category_id']??0)==$c['id']?'selected':''?>><?=e($c['name'])?></option><?php endforeach;?></select>
<label>Description</label><textarea class="input" rows="4" name="description"><?=e($edit['description']??'')?></textarea>
<label>Phone</label><input class="input" name="phone" value="<?=e($edit['phone']??'')?>">
<label>WhatsApp</label><input class="input" name="whatsapp" value="<?=e($edit['whatsapp']??'')?>">
<label>Address</label><input class="input" name="address" value="<?=e($edit['address']??'')?>">
<label>Image URL</label><input class="input" name="image" value="<?=e($edit['image']??'')?>">
<label>Verification</label><select class="input" name="verification_status"><?php foreach(['pending','verified','rejected','suspended'] as $v):?><option <?=$v===($edit['verification_status']??'pending')?'selected':''?>><?=e($v)?></option><?php endforeach;?></select>
<label><input type="checkbox" name="is_featured" <?=($edit['is_featured']??0)?'checked':''?>> Featured</label> &nbsp;
<label><input type="checkbox" name="status" <?=($edit['status']??1)?'checked':''?>> Active</label><br><br>
<button class="btn"><?=$edit?'Update':'Add'?> Business</button></form></div>
<div class="card"><table><tr><th>Business</th><th>Owner</th><th>Category</th><th>Status</th><th>Action</th></tr><?php foreach($rows as $r):?><tr><td><?=e($r['name'])?> <?=$r['is_featured']?'★':''?></td><td><?=e($r['owner'])?></td><td><?=e($r['category_name'])?></td><td><?=e($r['verification_status'])?></td><td><a href="?edit=<?=e($r['id'])?>">Edit</a> · <form method="post" style="display:inline" onsubmit="return confirm('Delete business?')"><input type="hidden" name="_csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=e($r['id'])?>"><button style="border:0;background:none;color:#b91c1c;cursor:pointer">Delete</button></form></td></tr><?php endforeach;?></table></div>
<?php require __DIR__.'/../app/end.php';?>
