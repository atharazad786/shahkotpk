<?php
require __DIR__.'/../app/bootstrap.php';require_admin();require __DIR__.'/../app/layout.php';page_start('Advertisements',true);
$rows=db()->query('SELECT id,title,placement,status,budget FROM advertisements ORDER BY id DESC LIMIT 100')->fetchAll();?>
<div class="card"><h1>Advertisements</h1><table><tr><th>id</th><th>title</th><th>placement</th><th>status</th><th>budget</th></tr><?php foreach($rows as $r):?><tr><td><?=e($r['id'])?></td><td><?=e($r['title'])?></td><td><?=e($r['placement'])?></td><td><?=e($r['status'])?></td><td><?=e($r['budget'])?></td></tr><?php endforeach;?></table></div>
<?php require __DIR__.'/../app/end.php';?>