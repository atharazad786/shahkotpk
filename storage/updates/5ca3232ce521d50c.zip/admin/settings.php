<?php
require __DIR__.'/../app/bootstrap.php';require_admin();
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();
 foreach(['site_name','default_city','support_phone'] as $k){
  $q=db()->prepare("INSERT INTO settings(setting_key,setting_value)VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");
  $q->execute([$k,trim($_POST[$k]??'')]);
 }
}
$s=[];foreach(db()->query("SELECT setting_key,setting_value FROM settings")->fetchAll() as $r)$s[$r['setting_key']]=$r['setting_value'];
require __DIR__.'/../app/layout.php';page_start('Settings',true);?>
<div class="card"><h1>Settings</h1><form method="post"><input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
<label>Site Name</label><input class="input" name="site_name" value="<?=e($s['site_name']??'ShahkotPK')?>">
<label>Default City</label><input class="input" name="default_city" value="<?=e($s['default_city']??'Shahkot')?>">
<label>Support Phone</label><input class="input" name="support_phone" value="<?=e($s['support_phone']??'')?>">
<button class="btn">Save</button></form></div>
<?php require __DIR__.'/../app/end.php';?>
