<?php
require __DIR__.'/../app/bootstrap.php';require_admin();
require __DIR__.'/../app/layout.php';page_start('Admin Dashboard',true);
$stats=[
'Users'=>db()->query("SELECT COUNT(*) c FROM users")->fetch()['c'],
'Businesses'=>db()->query("SELECT COUNT(*) c FROM businesses")->fetch()['c'],
'Subscriptions'=>db()->query("SELECT COUNT(*) c FROM subscriptions")->fetch()['c'],
'Ads'=>db()->query("SELECT COUNT(*) c FROM advertisements")->fetch()['c']
];?>
<div class="grid"><?php foreach($stats as $k=>$v):?><div class="card"><div><?=e($k)?></div><div class="stat"><?=e($v)?></div></div><?php endforeach;?></div>
<?php require __DIR__.'/../app/end.php';?>
