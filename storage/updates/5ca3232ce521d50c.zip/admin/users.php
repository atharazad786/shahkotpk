<?php
require __DIR__.'/../app/bootstrap.php';require_admin();$msg=$err=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{csrf_check();$id=(int)$_POST['id'];$role=$_POST['role'];$status=$_POST['status'];if(!in_array($role,['customer','shopkeeper','admin'],true)||!in_array($status,['active','blocked'],true))throw new RuntimeException('Invalid role/status.');db()->prepare("UPDATE users SET role=?,status=? WHERE id=?")->execute([$role,$status,$id]);$msg='User updated.';}catch(Throwable $e){$err=$e->getMessage();}
}
$rows=db()->query("SELECT id,name,email,phone,role,status,created_at FROM users ORDER BY id DESC")->fetchAll();
require __DIR__.'/../app/layout.php';page_start('Users',true);?>
<div class="card"><h1>User Management</h1><?php if($msg):?><div class="success"><?=e($msg)?></div><?php endif;?><?php if($err):?><div class="error"><?=e($err)?></div><?php endif;?>
<table><tr><th>User</th><th>Contact</th><th>Role & Status</th></tr><?php foreach($rows as $r):?><tr><td><?=e($r['name'])?><br><small>#<?=e($r['id'])?></small></td><td><?=e($r['email']?:$r['phone'])?></td><td><form method="post"><input type="hidden" name="_csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="id" value="<?=e($r['id'])?>"><select name="role"><?php foreach(['customer','shopkeeper','admin'] as $v):?><option <?=$v===$r['role']?'selected':''?>><?=e($v)?></option><?php endforeach;?></select> <select name="status"><?php foreach(['active','blocked'] as $v):?><option <?=$v===$r['status']?'selected':''?>><?=e($v)?></option><?php endforeach;?></select> <button class="btn">Save</button></form></td></tr><?php endforeach;?></table></div>
<?php require __DIR__.'/../app/end.php';?>
