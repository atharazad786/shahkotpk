-- ShahkotPK / CityHub Database Schema
-- Version: 1.0.0
-- Charset: utf8mb4
-- This SQL matches the v3 cPanel Repair Installer.

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(190) UNIQUE NULL,
  phone VARCHAR(30) UNIQUE NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('customer','shopkeeper','admin') NOT NULL DEFAULT 'customer',
  status ENUM('active','blocked') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cities (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  slug VARCHAR(150) UNIQUE NOT NULL,
  status TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS categories (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  slug VARCHAR(150) UNIQUE NOT NULL,
  status TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS businesses (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  owner_id BIGINT UNSIGNED NOT NULL,
  city_id BIGINT UNSIGNED NOT NULL,
  category_id BIGINT UNSIGNED NOT NULL,
  name VARCHAR(180) NOT NULL,
  slug VARCHAR(200) UNIQUE NOT NULL,
  description TEXT NULL,
  phone VARCHAR(30) NULL,
  whatsapp VARCHAR(30) NULL,
  address VARCHAR(255) NULL,
  image VARCHAR(500) NULL,
  verification_status ENUM('pending','verified','rejected','suspended') DEFAULT 'pending',
  is_featured TINYINT(1) DEFAULT 0,
  status TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_business_city (city_id),
  INDEX idx_business_category (category_id),
  INDEX idx_business_status (status, verification_status),
  CONSTRAINT fk_business_owner FOREIGN KEY (owner_id) REFERENCES users(id),
  CONSTRAINT fk_business_city FOREIGN KEY (city_id) REFERENCES cities(id),
  CONSTRAINT fk_business_category FOREIGN KEY (category_id) REFERENCES categories(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS subscription_plans (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(120) UNIQUE NOT NULL,
  price DECIMAL(12,2) DEFAULT 0,
  billing_period ENUM('monthly','yearly','custom') DEFAULT 'yearly',
  features_json JSON NULL,
  status TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS subscriptions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id BIGINT UNSIGNED NOT NULL,
  plan_id BIGINT UNSIGNED NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status ENUM('pending','active','expired','cancelled','suspended') DEFAULT 'pending',
  amount DECIMAL(12,2) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_subscription_business (business_id),
  INDEX idx_subscription_plan (plan_id),
  INDEX idx_subscription_status (status),
  CONSTRAINT fk_subscription_business FOREIGN KEY (business_id) REFERENCES businesses(id),
  CONSTRAINT fk_subscription_plan FOREIGN KEY (plan_id) REFERENCES subscription_plans(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS advertisements (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id BIGINT UNSIGNED NULL,
  title VARCHAR(180) NOT NULL,
  placement VARCHAR(80) NOT NULL,
  image_url VARCHAR(500) NULL,
  target_url VARCHAR(500) NULL,
  start_at DATETIME NULL,
  end_at DATETIME NULL,
  status ENUM('pending','scheduled','active','paused','completed','rejected') DEFAULT 'pending',
  budget DECIMAL(12,2) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ad_business (business_id),
  INDEX idx_ad_status (status),
  CONSTRAINT fk_ad_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS settings (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(120) UNIQUE NOT NULL,
  setting_value TEXT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS system_updates (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  version VARCHAR(50) NOT NULL,
  file_name VARCHAR(255) NOT NULL,
  status ENUM('success','failed') NOT NULL,
  backup_path VARCHAR(500) NULL,
  notes TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Default city
INSERT IGNORE INTO cities (name, slug)
VALUES ('Shahkot', 'shahkot');

-- Default categories
INSERT IGNORE INTO categories (name, slug) VALUES
('Restaurants','restaurants'),
('Mobile Shops','mobile-shops'),
('Electronics','electronics'),
('Clothing','clothing'),
('Services','services');

-- Default subscription plans
INSERT IGNORE INTO subscription_plans (name, slug, price, billing_period) VALUES
('Free','free',0,'yearly'),
('Business','business',3500,'yearly'),
('Premium','premium',7500,'yearly');

-- Default settings
INSERT INTO settings (setting_key, setting_value) VALUES
('site_name','ShahkotPK'),
('default_city','Shahkot'),
('timezone','Asia/Karachi'),
('charset','utf8mb4')
ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value);

-- NOTE:
-- The admin account is created/updated by install.php because its password
-- is stored using PHP password_hash(). This avoids placing an unsafe plain
-- password or incompatible static hash in the SQL file.

SET FOREIGN_KEY_CHECKS=1;
