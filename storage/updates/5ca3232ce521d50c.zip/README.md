# ShahkotPK v1.1.0

New modern city portal landing page inspired by the information architecture of city directory portals.

## Admin-controlled homepage
Admin → Homepage Builder

Every section supports:
- show / hide
- display order
- title
- subtitle
- content
- image URL
- image upload
- editable list items
- delete section
- add custom/content/CTA/gallery/links/info-card modules

Database-driven sections:
- Directory uses Admin Categories
- Featured Businesses uses Admin Businesses
- Users/roles are controlled from Admin Users

No new database table is required. Homepage layout is stored as JSON in the existing `settings` table, so this update is compatible with the current database.

## Updater
Package version: 1.1.0
Future updater versions now compare against the latest successful entry in `system_updates`.
