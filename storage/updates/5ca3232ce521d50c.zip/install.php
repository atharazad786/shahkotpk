<?php
declare(strict_types=1);

$root = __DIR__;
$configFile = $root . '/config/config.php';
$lockFile = $root . '/storage/.installed';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (empty($_SESSION['_csrf'])) {
    $_SESSION['_csrf'] = bin2hex(random_bytes(32));
}

function h($v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function valid_config_install(string $configFile): bool {
    if (!is_file($configFile)) return false;

    try {
        $cfg = require $configFile;
        if (!is_array($cfg) || empty($cfg['db']['name']) || empty($cfg['db']['user'])) {
            return false;
        }

        $c = $cfg['db'];
        $pdo = new PDO(
            "mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset=utf8mb4",
            $c['user'],
            $c['pass'],
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_TIMEOUT => 5,
            ]
        );

        $stmt = $pdo->query("SHOW TABLES LIKE 'users'");
        return (bool)$stmt->fetchColumn();
    } catch (Throwable $e) {
        return false;
    }
}

/*
 * STALE LOCK AUTO-REPAIR:
 * - If lock exists but config is missing/invalid, remove stale lock automatically.
 * - If config + DB are valid, installation is already complete:
 *   delete installer and go to homepage.
 */
if (is_file($lockFile)) {
    if (valid_config_install($configFile)) {
        @unlink(__FILE__);
        header('Location: /', true, 302);
        exit;
    } else {
        @unlink($lockFile);
    }
}

/*
 * Also handle case where config is valid but lock was accidentally deleted.
 * Re-create the lock, delete installer, redirect home.
 */
if (valid_config_install($configFile)) {
    @file_put_contents($lockFile, date('c')."\nRecovered installation lock.\n", LOCK_EX);
    @unlink(__FILE__);
    header('Location: /', true, 302);
    exit;
}

function checks(string $root): array {
    return [
        'PHP 8.1+' => version_compare(PHP_VERSION, '8.1.0', '>='),
        'PDO' => extension_loaded('pdo'),
        'PDO MySQL' => extension_loaded('pdo_mysql'),
        'OpenSSL' => extension_loaded('openssl'),
        'MBString' => extension_loaded('mbstring'),
        'Fileinfo' => extension_loaded('fileinfo'),
        'ZIP' => extension_loaded('zip'),
        'Config folder writable' => is_dir($root.'/config') && is_writable($root.'/config'),
        'Storage folder writable' => is_dir($root.'/storage') && is_writable($root.'/storage'),
    ];
}

function exec_sql(PDO $pdo, string $sql, array $params = []): void {
    $s = $pdo->prepare($sql);
    $s->execute($params);
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($_SESSION['_csrf'] ?? '', $_POST['_csrf'] ?? '')) {
            throw new RuntimeException('Security token expired. Refresh and try again.');
        }

        foreach (checks($root) as $label => $ok) {
            if (!$ok) throw new RuntimeException("Server requirement failed: {$label}");
        }

        $host = trim($_POST['db_host'] ?? 'localhost');
        $port = (int)($_POST['db_port'] ?? 3306);
        $name = trim($_POST['db_name'] ?? '');
        $user = trim($_POST['db_user'] ?? '');
        $pass = (string)($_POST['db_pass'] ?? '');

        if ($name === '' || $user === '') {
            throw new RuntimeException('Database name and username are required.');
        }
        if (!preg_match('/^[A-Za-z0-9_]+$/', $name)) {
            throw new RuntimeException('Use the exact cPanel database name.');
        }

        $pdo = new PDO(
            "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4",
            $user,
            $pass,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]
        );
        $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("SET FOREIGN_KEY_CHECKS=0");

        $schema = [
"CREATE TABLE IF NOT EXISTS users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(190) UNIQUE NULL,
 phone VARCHAR(30) UNIQUE NULL,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('customer','shopkeeper','admin') NOT NULL DEFAULT 'customer',
 status ENUM('active','blocked') NOT NULL DEFAULT 'active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

"CREATE TABLE IF NOT EXISTS cities (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 slug VARCHAR(150) UNIQUE NOT NULL,
 status TINYINT(1) DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

"CREATE TABLE IF NOT EXISTS categories (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 slug VARCHAR(150) UNIQUE NOT NULL,
 status TINYINT(1) DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

"CREATE TABLE IF NOT EXISTS businesses (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 owner_id BIGINT UNSIGNED NOT NULL,
 city_id BIGINT UNSIGNED NOT NULL,
 category_id BIGINT UNSIGNED NOT NULL,
 name VARCHAR(180) NOT NULL,
 slug VARCHAR(200) UNIQUE NOT NULL,
 description TEXT NULL,
 phone VARCHAR(30) NULL,
 whatsapp VARCHAR(30) NULL,
 address VARCHAR(255) NULL,
 image VARCHAR(500) NULL,
 verification_status ENUM('pending','verified','rejected','suspended') DEFAULT 'pending',
 is_featured TINYINT(1) DEFAULT 0,
 status TINYINT(1) DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(owner_id) REFERENCES users(id),
 FOREIGN KEY(city_id) REFERENCES cities(id),
 FOREIGN KEY(category_id) REFERENCES categories(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

"CREATE TABLE IF NOT EXISTS subscription_plans (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 slug VARCHAR(120) UNIQUE NOT NULL,
 price DECIMAL(12,2) DEFAULT 0,
 billing_period ENUM('monthly','yearly','custom') DEFAULT 'yearly',
 features_json JSON NULL,
 status TINYINT(1) DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

"CREATE TABLE IF NOT EXISTS subscriptions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 business_id BIGINT UNSIGNED NOT NULL,
 plan_id BIGINT UNSIGNED NOT NULL,
 start_date DATE NOT NULL,
 end_date DATE NOT NULL,
 status ENUM('pending','active','expired','cancelled','suspended') DEFAULT 'pending',
 amount DECIMAL(12,2) DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(business_id) REFERENCES businesses(id),
 FOREIGN KEY(plan_id) REFERENCES subscription_plans(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

"CREATE TABLE IF NOT EXISTS advertisements (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 business_id BIGINT UNSIGNED NULL,
 title VARCHAR(180) NOT NULL,
 placement VARCHAR(80) NOT NULL,
 image_url VARCHAR(500) NULL,
 target_url VARCHAR(500) NULL,
 start_at DATETIME NULL,
 end_at DATETIME NULL,
 status ENUM('pending','scheduled','active','paused','completed','rejected') DEFAULT 'pending',
 budget DECIMAL(12,2) DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(business_id) REFERENCES businesses(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

"CREATE TABLE IF NOT EXISTS settings (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 setting_key VARCHAR(120) UNIQUE NOT NULL,
 setting_value TEXT NULL,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

"CREATE TABLE IF NOT EXISTS system_updates (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 version VARCHAR(50) NOT NULL,
 file_name VARCHAR(255) NOT NULL,
 status ENUM('success','failed') NOT NULL,
 backup_path VARCHAR(500) NULL,
 notes TEXT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        ];

        foreach ($schema as $sql) $pdo->exec($sql);

        // Seed/update admin to guarantee requested credentials work.
        $adminEmail = 'admin@cityhub.local';
        $adminPassword = 'Arman@123';
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email=? LIMIT 1");
        $stmt->execute([$adminEmail]);
        $existing = $stmt->fetch();

        if ($existing) {
            exec_sql(
                $pdo,
                "UPDATE users SET name=?, password_hash=?, role='admin', status='active' WHERE id=?",
                ['System Administrator', password_hash($adminPassword, PASSWORD_DEFAULT), $existing['id']]
            );
        } else {
            exec_sql(
                $pdo,
                "INSERT INTO users(name,email,password_hash,role,status) VALUES(?,?,?,?,?)",
                ['System Administrator', $adminEmail, password_hash($adminPassword, PASSWORD_DEFAULT), 'admin', 'active']
            );
        }

        exec_sql($pdo, "INSERT IGNORE INTO cities(name,slug) VALUES(?,?)", ['Shahkot','shahkot']);

        foreach ([
            ['Restaurants','restaurants'],
            ['Mobile Shops','mobile-shops'],
            ['Electronics','electronics'],
            ['Clothing','clothing'],
            ['Services','services']
        ] as $cat) {
            exec_sql($pdo, "INSERT IGNORE INTO categories(name,slug) VALUES(?,?)", $cat);
        }

        foreach ([
            ['Free','free',0,'yearly'],
            ['Business','business',3500,'yearly'],
            ['Premium','premium',7500,'yearly']
        ] as $plan) {
            exec_sql($pdo, "INSERT IGNORE INTO subscription_plans(name,slug,price,billing_period) VALUES(?,?,?,?)", $plan);
        }

        foreach ([
            ['site_name','ShahkotPK'],
            ['default_city','Shahkot'],
            ['timezone','Asia/Karachi'],
            ['charset','utf8mb4']
        ] as $setting) {
            exec_sql(
                $pdo,
                "INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)",
                $setting
            );
        }

        $pdo->exec("SET FOREIGN_KEY_CHECKS=1");

        foreach (['uploads','backups','updates','logs'] as $dir) {
            $path = $root.'/storage/'.$dir;
            if (!is_dir($path) && !mkdir($path,0755,true)) {
                throw new RuntimeException("Cannot create storage/{$dir}.");
            }
        }

        $cfg = [
            'app_name' => 'ShahkotPK',
            'version' => '1.0.0',
            'base_url' => '',
            'session_name' => 'cityhub_session',
            'db' => [
                'host' => $host,
                'port' => $port,
                'name' => $name,
                'user' => $user,
                'pass' => $pass,
                'charset' => 'utf8mb4',
            ],
        ];

        $cfgPhp = "<?php\nreturn " . var_export($cfg,true) . ";\n";
        if (file_put_contents($configFile,$cfgPhp,LOCK_EX) === false) {
            throw new RuntimeException('Cannot write config/config.php. Check config folder permissions.');
        }

        // Full validation after writing config.
        if (!valid_config_install($configFile)) {
            @unlink($configFile);
            throw new RuntimeException('Config/DB verification failed. Installer was not locked.');
        }

        if (file_put_contents($lockFile,date('c')."\nInstalled successfully.\n",LOCK_EX) === false) {
            throw new RuntimeException('Cannot create storage/.installed.');
        }

        // Delete installer only after ALL checks succeed.
        @unlink(__FILE__);

        header('Location: /?installed=1', true, 302);
        exit;

    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ShahkotPK Installer</title>
<style>
body{margin:0;background:#f5f7fb;font-family:Arial,sans-serif;color:#172033}.wrap{max-width:780px;margin:30px auto;padding:15px}.card{background:#fff;border:1px solid #ddd;border-radius:15px;padding:26px}.input{width:100%;padding:11px;border:1px solid #cbd5e1;border-radius:8px;margin:6px 0 14px;box-sizing:border-box}.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.btn{border:0;border-radius:8px;padding:12px 18px;background:#2563eb;color:#fff;cursor:pointer}.err{background:#fee2e2;color:#991b1b;padding:12px;border-radius:8px;margin-bottom:14px}.info{background:#eff6ff;color:#1e40af;padding:12px;border-radius:8px}.row{display:flex;justify-content:space-between;padding:7px;border-bottom:1px solid #eee}.yes{color:#15803d}.no{color:#b91c1c}@media(max-width:650px){.grid{grid-template-columns:1fr}}</style>
</head><body><div class="wrap"><div class="card">
<h1>ShahkotPK Installer / Repair</h1>
<div class="info">Purana stale installer lock automatically repair hota hai. Successful install ke baad install.php khud delete ho kar homepage par redirect karega.</div>
<?php if($error):?><div class="err"><?=h($error)?></div><?php endif;?>
<h3>Server Check</h3>
<?php foreach(checks($root) as $label=>$ok):?><div class="row"><span><?=h($label)?></span><b class="<?=$ok?'yes':'no'?>"><?=$ok?'OK':'FAIL'?></b></div><?php endforeach;?>
<form method="post">
<input type="hidden" name="_csrf" value="<?=h($_SESSION['_csrf'])?>">
<h3>Database</h3>
<div class="grid">
<div><label>Host</label><input class="input" name="db_host" value="localhost" required></div>
<div><label>Port</label><input class="input" name="db_port" value="3306" required></div>
</div>
<label>Database Name</label><input class="input" name="db_name" required>
<label>Database User</label><input class="input" name="db_user" required>
<label>Database Password</label><input class="input" type="password" name="db_pass">
<p>Charset: <b>utf8mb4</b></p>
<h3>Admin</h3>
<p>Email: <b>admin@cityhub.local</b><br>Password: <b>Arman@123</b></p>
<button class="btn">Install / Repair ShahkotPK</button>
</form>
</div></div></body></html>
