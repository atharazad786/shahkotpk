<?php
require __DIR__.'/app/bootstrap.php';
$u=current_user();if(!$u){header('Location: /login.php');exit;}
require __DIR__.'/app/layout.php';page_start('Account');?>
<div class="card"><h1>Welcome, <?=e($u['name'])?></h1><p>Role: <?=e($u['role'])?></p><a class="btn" href="/logout.php">Logout</a></div>
<?php require __DIR__.'/app/end.php';?>
