<?php
require __DIR__.'/app/bootstrap.php';

if(!feature_enabled('registration_enabled',true)){
    http_response_code(403);
    exit('Registration is currently disabled by the administrator.');
}

$allowCustomer=feature_enabled('customer_signup_enabled',true);
$allowShopkeeper=feature_enabled('shopkeeper_signup_enabled',true) && feature_enabled('business_registration_enabled',true);

if(!$allowCustomer && !$allowShopkeeper){
    http_response_code(403);
    exit('New account registration is currently unavailable.');
}

$error=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        csrf_check();

        $n=trim($_POST['name']??'');
        $em=trim($_POST['email']??'');
        $ph=trim($_POST['phone']??'');
        $pw=$_POST['password']??'';
        $role=$_POST['role']??($allowCustomer?'customer':'shopkeeper');

        if($role==='customer' && !$allowCustomer) throw new RuntimeException('Customer registration is disabled.');
        if($role==='shopkeeper' && !$allowShopkeeper) throw new RuntimeException('Shopkeeper registration is disabled.');
        if(!in_array($role,['customer','shopkeeper'],true)) throw new RuntimeException('Invalid account type.');

        if(!$n || strlen($pw)<8) throw new RuntimeException('Name and password are required.');
        if(feature_enabled('email_required',false) && !$em) throw new RuntimeException('Email is required.');
        if(feature_enabled('phone_required',false) && !$ph) throw new RuntimeException('Phone is required.');
        if(!$em && !$ph) throw new RuntimeException('Enter at least an email or phone number.');

        $q=db()->prepare("INSERT INTO users(name,email,phone,password_hash,role,status) VALUES(?,?,?,?,?,'active')");
        $q->execute([$n,$em?:null,$ph?:null,password_hash($pw,PASSWORD_DEFAULT),$role]);

        header('Location: /login.php');
        exit;
    }catch(Throwable $e){
        $error=$e->getMessage();
    }
}
?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Register - <?=e(setting('site_name','ShahkotPK'))?></title>
<link rel="stylesheet" href="/assets/shahkotpk-1.5.0.css?v=150">
</head>
<body>
<section class="section"><div class="city-shell" style="max-width:650px"><div class="card">
<a href="/">← <?=e(setting('site_name','ShahkotPK'))?></a>
<h1>Create Account</h1>
<?php if($error):?><div class="error"><?=e($error)?></div><?php endif;?>
<form method="post">
<input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
<label>Name</label><input class="input" name="name" required>
<label>Email<?=feature_enabled('email_required',false)?' *':''?></label><input class="input" type="email" name="email" <?=feature_enabled('email_required',false)?'required':''?>>
<label>Phone<?=feature_enabled('phone_required',false)?' *':''?></label><input class="input" name="phone" <?=feature_enabled('phone_required',false)?'required':''?>>

<?php if($allowCustomer && $allowShopkeeper):?>
<label>Account Type</label><select class="input" name="role"><option value="customer">Customer</option><option value="shopkeeper">Business / Shopkeeper</option></select>
<?php elseif($allowShopkeeper):?>
<input type="hidden" name="role" value="shopkeeper">
<?php else:?>
<input type="hidden" name="role" value="customer">
<?php endif;?>

<label>Password</label><input class="input" type="password" name="password" minlength="8" required>
<button class="btn btn-green">Create Account</button>
</form>
</div></div></section>
</body></html>
