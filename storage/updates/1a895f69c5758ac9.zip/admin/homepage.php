<?php
require __DIR__.'/../app/bootstrap.php';
require_admin();
require __DIR__.'/../app/homepage.php';

$success=$error=null;
$sections=homepage_sections();

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        csrf_check();
        $action=$_POST['action']??'save';

        if($action==='reset'){
            save_homepage_sections(default_homepage_sections());
            $sections=default_homepage_sections();
            $success='Homepage restored to default modules.';
        } elseif($action==='add'){
            $type=trim($_POST['new_type']??'custom');
            $title=trim($_POST['new_title']??'New Section');
            $allowed=['custom','content','cta','gallery','links','info_cards'];
            if(!in_array($type,$allowed,true))$type='custom';
            $sections[]=[
                'id'=>'module_'.bin2hex(random_bytes(4)),
                'type'=>$type,'enabled'=>1,'order'=>count($sections)*10+20,
                'title'=>$title?:'New Section','subtitle'=>'','content'=>'','image'=>'','items'=>''
            ];
            save_homepage_sections($sections);
            $success='New homepage module added.';
        } elseif($action==='delete'){
            $id=$_POST['module_id']??'';
            $sections=array_values(array_filter($sections,fn($x)=>($x['id']??'')!==$id));
            save_homepage_sections($sections);
            $success='Module removed.';
        } else {
            $posted=$_POST['sections']??[];
            $updated=[];
            foreach($sections as $old){
                $id=$old['id'];
                $p=$posted[$id]??[];
                $s=$old;
                $s['enabled']=isset($p['enabled'])?1:0;
                $s['order']=(int)($p['order']??$old['order']);
                $s['title']=trim($p['title']??'');
                $s['subtitle']=trim($p['subtitle']??'');
                $s['content']=trim($p['content']??'');
                $s['items']=trim($p['items']??'');
                $s['image']=trim($p['image']??($old['image']??''));

                $fileKey='image_'.preg_replace('/[^a-zA-Z0-9_]/','_',$id);
                if(isset($_FILES[$fileKey])){
                    $uploaded=upload_homepage_image($_FILES[$fileKey]);
                    if($uploaded)$s['image']=$uploaded;
                }
                $updated[]=$s;
            }
            save_homepage_sections($updated);
            $sections=$updated;
            $success='Homepage modules saved successfully.';
        }
    }catch(Throwable $e){$error=$e->getMessage();}
}

usort($sections,fn($a,$b)=>(int)$a['order']<=>(int)$b['order']);
require __DIR__.'/../app/layout.php';
page_start('Homepage Builder',true);
?>

<div class="card"><div class="builder-actions"><div><h1 style="margin:0">Homepage Builder</h1><p class="muted">Landing page ke tamam modules yahan se control karein.</p></div><div style="margin-left:auto"><a class="btn" href="/" target="_blank">Preview Website ↗</a></div></div>
<?php if($success):?><div class="success"><?=e($success)?></div><?php endif;?>
<?php if($error):?><div class="error"><?=e($error)?></div><?php endif;?>
</div>

<form method="post" enctype="multipart/form-data">
<input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
<input type="hidden" name="action" value="save">

<?php foreach($sections as $s):$id=$s['id'];$fileKey='image_'.preg_replace('/[^a-zA-Z0-9_]/','_',$id);?>
<div class="card module-card">
<div class="module-meta"><span class="module-type"><?=e($s['type'])?></span><strong><?=e($s['title'])?></strong><label style="margin-left:auto"><input type="checkbox" name="sections[<?=e($id)?>][enabled]" <?=$s['enabled']?'checked':''?>> Show module</label></div>
<div class="builder-grid">
<div><label>Order</label><input class="input" type="number" name="sections[<?=e($id)?>][order]" value="<?=e($s['order'])?>"></div>
<div><label>Title</label><input class="input" name="sections[<?=e($id)?>][title]" value="<?=e($s['title'])?>"></div>
<div><label>Subtitle</label><input class="input" name="sections[<?=e($id)?>][subtitle]" value="<?=e($s['subtitle'])?>"></div>
</div>
<label>Content / Description</label><textarea class="input" rows="3" name="sections[<?=e($id)?>][content]"><?=e($s['content'])?></textarea>

<label>Module Image URL</label><input class="input" name="sections[<?=e($id)?>][image]" value="<?=e($s['image'])?>" placeholder="/uploads/homepage/example.webp or https://...">
<label>Or upload image</label><input class="input" type="file" name="<?=e($fileKey)?>" accept=".jpg,.jpeg,.png,.webp,.gif">

<label>Items</label><textarea class="input" rows="5" name="sections[<?=e($id)?>][items]"><?=e($s['items'])?></textarea>
<div class="help">One item per line: <b>Title | Text | Link | Image URL</b>. Directory/Featured modules automatically use database data.</div>

<button class="btn danger" type="submit" name="action" value="delete" formaction="/admin/homepage.php" onclick="this.form.module_id.value='<?=e($id)?>';return confirm('Remove this homepage module?')">Delete Module</button>
</div>
<?php endforeach;?>
<div class="builder-footer"><button class="btn" type="submit">Save All Homepage Changes</button> <a class="btn" style="background:#475569" href="/" target="_blank">Preview Website ↗</a></div>
</form>

<div class="card"><h2>Add New Homepage Module</h2>
<form method="post"><input type="hidden" name="_csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="add">
<div class="builder-grid"><div><label>Type</label><select class="input" name="new_type"><option value="custom">Custom Cards</option><option value="content">Content</option><option value="cta">CTA</option><option value="gallery">Gallery</option><option value="links">Links</option><option value="info_cards">Info Cards</option></select></div>
<div style="grid-column:span 2"><label>Module Title</label><input class="input" name="new_title" value="New Section"></div></div>
<button class="btn">Add Module</button></form>
</div>

<div class="card"><h2>Restore Default Layout</h2><p>Current custom homepage structure ko original ShahkotPK layout par reset karega.</p>
<form method="post" onsubmit="return confirm('Reset homepage layout?')"><input type="hidden" name="_csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="reset"><button class="btn danger">Reset Homepage</button></form></div>
<?php require __DIR__.'/../app/end.php';?>
