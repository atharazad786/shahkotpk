<?php
function page_start(string $title,bool $admin=false):void{
    global $config;
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($title)?> - <?=e($config['app_name']??'ShahkotPK')?></title>

<?php if($admin): ?>
<link rel="stylesheet" href="/assets/admin-1.1.3.css?v=113">
<style>
/* Critical admin fallback: keeps dashboard usable even if external CSS is cached/blocked */
html,body{margin:0;background:#f3f6fa;color:#142033;font-family:Arial,sans-serif}
.sidebar{position:fixed;left:0;top:0;bottom:0;width:250px;background:#0f172a;color:#fff;padding:24px 16px;overflow:auto;z-index:50}
.sidebar a{display:block;color:#dbeafe;text-decoration:none;padding:10px 12px;border-radius:9px}
.main{margin-left:250px;min-height:100vh}
.container{max-width:1500px;margin:auto;padding:28px}
.card{background:#fff;border:1px solid #dbe3ec;border-radius:16px;padding:22px;margin-bottom:20px}
.input,select,textarea,input[type=text],input[type=number],input[type=email],input[type=password]{box-sizing:border-box;width:100%;padding:10px;border:1px solid #cbd5e1;border-radius:9px}
.btn{display:inline-block;background:#2563eb;color:#fff!important;border:0;border-radius:9px;padding:10px 15px;text-decoration:none;font-weight:700;cursor:pointer}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px}
table{width:100%;border-collapse:collapse}th,td{padding:10px;border-bottom:1px solid #e5e7eb;text-align:left}
.builder-grid{display:grid;grid-template-columns:110px minmax(240px,1fr) minmax(240px,1fr);gap:14px}
.module-meta{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.module-meta label{margin-left:auto}
@media(max-width:1000px){.sidebar{position:static;width:auto}.main{margin-left:0}.builder-grid{grid-template-columns:1fr}}
</style>
<?php else: ?>
<link rel="stylesheet" href="/assets/shahkotpk-1.1.2.css?v=112">
<?php endif; ?>
</head>
<body class="<?=$admin?'admin-body':'public-body'?>">
<?php if($admin):?>
<aside class="sidebar">
<h2>ShahkotPK</h2>
<a href="/admin/index.php">Dashboard</a>
<a href="/admin/homepage.php">Homepage Builder</a>
<a href="/admin/users.php">Users</a>
<a href="/admin/businesses.php">Businesses</a>
<a href="/admin/categories.php">Categories</a>
<a href="/admin/cities.php">Cities</a>
<a href="/admin/plans.php">Plans</a>
<a href="/admin/ads.php">Advertisements</a>
<a href="/admin/settings.php">Settings</a>
<a href="/admin/updates.php">System Updates</a>
<a href="/logout.php">Logout</a>
</aside>
<main class="main">
<?php endif;?>
<div class="container">
<?php
}
