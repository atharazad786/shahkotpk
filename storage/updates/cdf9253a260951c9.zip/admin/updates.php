<?php
require __DIR__.'/../app/bootstrap.php';
require_admin();
require __DIR__.'/../app/updater.php';

$ok=$err=null;

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        csrf_check();

        if(empty($_FILES['update_zip']['tmp_name'])){
            throw new RuntimeException('Choose an update ZIP file.');
        }

        $f=$_FILES['update_zip'];

        if(($f['error']??UPLOAD_ERR_OK)!==UPLOAD_ERR_OK){
            throw new RuntimeException('ZIP upload failed. PHP upload error code: '.($f['error']??'unknown'));
        }

        if(strtolower(pathinfo($f['name'],PATHINFO_EXTENSION))!=='zip'){
            throw new RuntimeException('Only ZIP update packages are allowed.');
        }

        $dest=__DIR__.'/../storage/updates/'.bin2hex(random_bytes(8)).'.zip';

        if(!move_uploaded_file($f['tmp_name'],$dest)){
            throw new RuntimeException('Could not save the uploaded ZIP. Check storage/updates permissions.');
        }

        $v=install_update($dest);
        $ok='Update '.$v.' installed successfully.';

    }catch(Throwable $e){
        $err=$e->getMessage();
    }
}

require __DIR__.'/../app/layout.php';
page_start('System Updates',true);
?>
<div class="card">
<h1>System Updates</h1>

<?php if($ok):?><div class="success"><?=e($ok)?></div><?php endif;?>
<?php if($err):?><div class="error"><?=e($err)?></div><?php endif;?>

<p><b>Upload only an updater-compatible ZIP.</b> The updater protects your database, <code>config/config.php</code>, storage and uploaded media.</p>

<form method="post" enctype="multipart/form-data">
<input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
<input class="input" type="file" name="update_zip" accept=".zip" required>
<button class="btn">Upload & Install</button>
</form>

<p class="admin-note">
Valid package example: <b>ShahkotPK_Update_1.1.1.zip</b><br>
Do not upload an old <b>Full Installer</b> ZIP in this section.
</p>
</div>
<?php require __DIR__.'/../app/end.php';?>
