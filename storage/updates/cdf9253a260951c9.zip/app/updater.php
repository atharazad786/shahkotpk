<?php
function safe_update_path(string $p): bool {
    $p=str_replace('\\','/',$p);
    return $p!=='' && !str_starts_with($p,'/') && !str_contains($p,'../') && !preg_match('/^[A-Za-z]:\//',$p);
}

function installed_app_version(): string {
    global $config;
    $version=$config['version']??'1.0.0';
    try{
        $latest=db()->query("SELECT version FROM system_updates WHERE status='success' ORDER BY id DESC LIMIT 1")->fetchColumn();
        if($latest && version_compare($latest,$version,'>')) $version=$latest;
    }catch(Throwable $e){}
    return $version;
}

function find_update_manifest(ZipArchive $z): array {
    // Preferred: update.json at ZIP root.
    $idx=$z->locateName('update.json', ZipArchive::FL_NOCASE);
    if($idx!==false){
        return [$idx, ''];
    }

    // Fallback: find update.json inside a single wrapper folder.
    for($i=0;$i<$z->numFiles;$i++){
        $name=str_replace('\\','/',$z->getNameIndex($i));
        if(strtolower(basename($name))==='update.json'){
            $prefix=substr($name,0,-strlen(basename($name)));
            return [$i,$prefix];
        }
    }

    throw new RuntimeException('update.json is missing. Please upload an updater-compatible ZIP, not an old full installer ZIP.');
}

function install_update(string $zip): string {
    if(!class_exists('ZipArchive')) throw new RuntimeException('PHP ZIP extension is required.');

    $current=installed_app_version();
    $root=realpath(__DIR__.'/..');

    $z=new ZipArchive();
    if($z->open($zip)!==true) throw new RuntimeException('Invalid ZIP file.');

    [$idx,$wrapper]=find_update_manifest($z);

    $m=json_decode($z->getFromIndex($idx),true);
    if(!is_array($m)||empty($m['version'])) throw new RuntimeException('Invalid update.json manifest.');
    if(version_compare($m['version'],$current,'<=')){
        throw new RuntimeException("Update version {$m['version']} must be higher than installed version {$current}.");
    }

    $tmp=sys_get_temp_dir().'/shahkotpk_'.bin2hex(random_bytes(5));
    if(!mkdir($tmp,0700,true)) throw new RuntimeException('Could not create update temporary folder.');

    try{
        for($i=0;$i<$z->numFiles;$i++){
            $name=str_replace('\\','/',$z->getNameIndex($i));

            if($i===$idx) continue;

            // If package has a wrapper directory, strip it.
            if($wrapper!==''){
                if(!str_starts_with($name,$wrapper)) continue;
                $name=substr($name,strlen($wrapper));
            }

            if($name==='' || $name==='update.json') continue;
            if(!safe_update_path($name)) throw new RuntimeException('Unsafe path detected in update ZIP: '.$name);

            // Never allow an update package to overwrite these persistent locations.
            if(
                $name==='config/config.php' ||
                str_starts_with($name,'storage/') ||
                $name==='install.php'
            ){
                continue;
            }

            $dest=$tmp.'/'.$name;

            if(str_ends_with($name,'/')){
                if(!is_dir($dest)) mkdir($dest,0755,true);
                continue;
            }

            if(!is_dir(dirname($dest))) mkdir(dirname($dest),0755,true);

            $stream=$z->getStream($z->getNameIndex($i));
            if(!$stream) throw new RuntimeException('Unable to read '.$name.' from update ZIP.');
            $fp=fopen($dest,'wb');
            stream_copy_to_stream($stream,$fp);
            fclose($fp);
            fclose($stream);
        }
        $z->close();

        // Backup app files before copying update.
        $backup=$root.'/storage/backups/'.date('Ymd_His').'_v'.$current.'.zip';
        $bz=new ZipArchive();
        if($bz->open($backup,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true){
            throw new RuntimeException('Could not create pre-update backup.');
        }

        $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));
        foreach($it as $f){
            $rel=str_replace('\\','/',substr($f->getPathname(),strlen($root)+1));
            if(
                is_file($f) &&
                !str_starts_with($rel,'storage/') &&
                !str_starts_with($rel,'config/') &&
                !str_starts_with($rel,'uploads/')
            ){
                $bz->addFile($f->getPathname(),$rel);
            }
        }
        $bz->close();

        // Install new files.
        $it=new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($tmp,FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        foreach($it as $f){
            $rel=str_replace('\\','/',substr($f->getPathname(),strlen($tmp)+1));
            $dest=$root.'/'.$rel;

            if($f->isDir()){
                if(!is_dir($dest)) mkdir($dest,0755,true);
            }else{
                if(!is_dir(dirname($dest))) mkdir(dirname($dest),0755,true);
                if(!copy($f->getPathname(),$dest)){
                    throw new RuntimeException('Failed to install file: '.$rel);
                }
            }
        }

        db()->prepare("INSERT INTO system_updates(version,file_name,status,backup_path,notes) VALUES(?,?,?,?,?)")
            ->execute([
                $m['version'],
                basename($zip),
                'success',
                $backup,
                $m['notes']??'Update installed successfully'
            ]);

        return $m['version'];

    }finally{
        if(is_dir($tmp)){
            $it=new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($tmp,FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::CHILD_FIRST
            );
            foreach($it as $f){
                $f->isDir()?@rmdir($f):@unlink($f);
            }
            @rmdir($tmp);
        }
    }
}
