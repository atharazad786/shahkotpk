<?php
require __DIR__.'/app/bootstrap.php';
require __DIR__.'/app/homepage.php';
require __DIR__.'/app/banners.php';
require __DIR__.'/app/ads_public.php';

$sections=homepage_sections();
usort($sections,fn($a,$b)=>(int)($a['order']??0)<=>(int)($b['order']??0));

$categories=[];
$featured=[];
$totalBusinesses=0;
$totalCategories=0;
$totalCities=0;

try{
    $categories=db()->query("SELECT id,name,slug FROM categories WHERE status=1 ORDER BY name ASC LIMIT 24")->fetchAll();
    $featured=db()->query("SELECT b.*,c.name city_name,cat.name category_name FROM businesses b JOIN cities c ON c.id=b.city_id JOIN categories cat ON cat.id=b.category_id WHERE b.status=1 AND (b.verification_status='verified' OR b.is_featured=1) ORDER BY b.is_featured DESC,b.id DESC LIMIT 9")->fetchAll();
    $totalBusinesses=(int)db()->query("SELECT COUNT(*) FROM businesses WHERE status=1")->fetchColumn();
    $totalCategories=(int)db()->query("SELECT COUNT(*) FROM categories WHERE status=1")->fetchColumn();
    $totalCities=(int)db()->query("SELECT COUNT(*) FROM cities WHERE status=1")->fetchColumn();
}catch(Throwable $e){}

$slides=array_values(array_filter(banner_slides(),fn($slide)=>!empty($slide['enabled'])));
usort($slides,fn($a,$b)=>(int)($a['order']??0)<=>(int)($b['order']??0));
$sliderInterval=max(2500,min(12000,setting_int('homepage_slider_interval_ms',5500)));

function module_img(array $s): string {
    $i=trim((string)($s['image']??''));
    return $i ? "background-image:url('".e($i)."')" : '';
}
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="<?=e(setting('seo_description','Discover Shahkot businesses, services and city information.'))?>">
<meta name="keywords" content="<?=e(setting('seo_keywords','Shahkot, business directory'))?>">
<?php if(setting_bool('robots_index',true)):?><meta name="robots" content="index,follow"><?php else:?><meta name="robots" content="noindex,nofollow"><?php endif;?>
<?php if(setting('og_image','')):?><meta property="og:image" content="<?=e(setting('og_image',''))?>"><?php endif;?>
<title><?=e(setting('seo_title',setting('site_name','ShahkotPK').' — '.setting('site_tagline','Your Digital City Guide')))?></title>
<?php if(setting('favicon_url','')):?><link rel="icon" href="<?=e(setting('favicon_url',''))?>"><?php endif;?>
<link rel="stylesheet" href="/assets/shahkotpk-1.6.0.css?v=160">
<style>:root{--green:<?=e(setting('brand_primary_color','#176b46'))?>;--green-deep:<?=e(setting('brand_secondary_color','#0f3d29'))?>}</style>
</head>
<body data-animations="<?=feature_enabled('homepage_animations_enabled',true)?'1':'0'?>">
<div class="site-wrap">

<?php foreach($sections as $s):
if(empty($s['enabled'])) continue;
$type=$s['type']??'custom';
$items=section_items($s['items']??'');

if($type==='hero' && !feature_enabled('homepage_search_enabled',true)) continue;
if($type==='directory' && (!feature_enabled('homepage_directory_enabled',true) || !feature_enabled('directory_enabled',true))) continue;
if($type==='featured' && !feature_enabled('homepage_featured_enabled',true)) continue;
if($type==='gallery' && !feature_enabled('homepage_gallery_enabled',true)) continue;
if($type==='info_cards' && !feature_enabled('homepage_city_info_enabled',true)) continue;
?>

<?php if($type==='topbar'): ?>
<div class="city-topbar"><div class="city-shell">
<div><?=e($s['content'] ?: $s['subtitle'])?></div>
<div class="top-links"><?php foreach($items as $it):?><a href="<?=e(safe_link($it['link']))?>"><?=e($it['title'])?></a><?php endforeach;?></div>
</div></div>
<?php render_ticker('public');?>

<?php elseif($type==='header'): ?>
<header class="city-header"><div class="city-shell city-header-inner">
<a class="brand" href="/">
<?php if(setting('logo_url','')):?><img class="brand-logo" src="<?=e(setting('logo_url',''))?>" alt="<?=e($s['title'])?>"><?php else:?><span class="brand-mark">S</span><?php endif;?>
<span><strong><?=e($s['title'])?></strong><small><?=e($s['subtitle'])?></small></span></a>

<nav class="city-nav">
<?php foreach($items as $it):?><a class="<?=str_contains(strtolower($it['title']),'register')?'nav-cta':''?>" href="<?=e(safe_link($it['link']))?>"><?=e($it['title'])?></a><?php endforeach;?>
<?php if(feature_enabled('show_pricing_in_header',true)&&feature_enabled('subscriptions_enabled',true)):?><a href="/pricing.php">Plans</a><?php endif;?>
<?php $headerUser=current_user(); if(feature_enabled('show_login_in_header',true)):?>
<?php if($headerUser):?><a class="header-login-btn" href="<?=$headerUser['role']==='admin'?'/admin/index.php':($headerUser['role']==='shopkeeper'?'/shopkeeper.php':'/account.php')?>">Dashboard</a><?php else:?><a class="header-login-btn" href="/login.php">Login</a><?php endif;?>
<?php endif;?>
</nav>

<?php if(feature_enabled('mobile_menu_enabled',true)):?>
<button class="mobile-menu-toggle" type="button" aria-label="Open menu" aria-expanded="false" data-mobile-menu-toggle><span></span></button>
<?php endif;?>
</div></header>

<?php if(feature_enabled('mobile_menu_enabled',true)):?>
<div class="mobile-drawer" data-mobile-drawer>
<div class="mobile-drawer-backdrop" data-mobile-close></div>
<div class="mobile-drawer-panel">
<div class="mobile-drawer-head">
<a class="brand" href="/"><span class="brand-mark">S</span><span><strong><?=e(setting('site_name','ShahkotPK'))?></strong><small><?=e(setting('site_tagline','City Guide'))?></small></span></a>
<button class="mobile-drawer-close" type="button" data-mobile-close>×</button>
</div>
<nav class="mobile-drawer-nav">
<?php foreach($items as $it):?><a class="<?=str_contains(strtolower($it['title']),'register')?'drawer-cta':''?>" href="<?=e(safe_link($it['link']))?>"><?=e($it['title'])?></a><?php endforeach;?>
<?php if(feature_enabled('show_pricing_in_header',true)&&feature_enabled('subscriptions_enabled',true)):?><a href="/pricing.php">Plans</a><?php endif;?>
<?php $drawerUser=current_user(); if($drawerUser):?><a class="drawer-cta" href="<?=$drawerUser['role']==='admin'?'/admin/index.php':($drawerUser['role']==='shopkeeper'?'/shopkeeper.php':'/account.php')?>">Dashboard</a><?php else:?><a class="drawer-cta" href="/login.php">Login</a><?php endif;?>
</nav>
</div>
</div>
<?php endif;?>

<?php if(feature_enabled('homepage_slider_enabled',true) && $slides):?>
<section class="portal-slider" data-portal-slider data-interval="<?=e($sliderInterval)?>">
<div class="portal-slides">
<?php foreach($slides as $idx=>$slide):?>
<article class="portal-slide <?=$idx===0?'is-active':''?> <?=$slide['image']?'has-image':''?>" <?=$slide['image']?'style="background-image:url(\''.e($slide['image']).'\')"':''?>>
<div class="portal-slide-inner"><div class="portal-slide-copy">
<?php if($slide['subtitle']):?><span class="portal-slide-kicker"><?=e($slide['subtitle'])?></span><?php endif;?>
<h2><?=e($slide['title'])?></h2>
<p><?=e($slide['text'])?></p>
<?php if($slide['button_text']):?><a class="slide-btn" href="<?=e(safe_link($slide['button_url']))?>"><?=e($slide['button_text'])?> →</a><?php endif;?>
</div></div>
</article>
<?php endforeach;?>
</div>
<?php if(count($slides)>1):?>
<button class="portal-slider-control prev" type="button" aria-label="Previous slide" data-slider-prev>‹</button>
<button class="portal-slider-control next" type="button" aria-label="Next slide" data-slider-next>›</button>
<div class="portal-slider-dots">
<?php foreach($slides as $idx=>$slide):?><button class="portal-slider-dot <?=$idx===0?'is-active':''?>" type="button" aria-label="Go to slide <?=e($idx+1)?>"></button><?php endforeach;?>
</div>
<?php endif;?>
</section>
<?php endif;?>

<?php elseif($type==='hero'): ?>
<?php if(feature_enabled('advertisements_enabled',true) && ($sponsoredTop=active_ad_for_placement('homepage_top'))):?>
<section class="sponsored-strip"><div class="sponsored-card"><div class="sponsored-inner"><div class="sponsored-image" <?=$sponsoredTop['image_url']?'style="background-image:url(\''.e($sponsoredTop['image_url']).'\')"':''?>></div><div><span class="sponsored-tag">SPONSORED</span><h3><?=e($sponsoredTop['title'])?></h3><p><?=e($sponsoredTop['business_name']?:'Featured promotion on ShahkotPK')?></p></div><a class="btn btn-green" href="/ad-click.php?id=<?=e($sponsoredTop['id'])?>">View Offer</a></div></div></section>
<?php endif;?>
<section class="hero compact-hero <?=$s['image']?'has-image':''?>" style="<?=module_img($s)?>">
<div class="hero-inner">
<div class="hero-layout">
<div class="hero-copy">
<span class="eyebrow">● <?=e($s['subtitle'])?></span>
<h1><?=e($s['title'])?></h1>
<p><?=e($s['content'])?></p>
<?php if(feature_enabled('search_enabled',true)):?><form class="search-panel" action="/search.php" method="get">
<input name="q" placeholder="Search businesses, services, places..." aria-label="Search Shahkot">
<button type="submit">Search Shahkot</button>
</form><?php endif;?>
<div class="popular-links"><?php foreach($items as $it):?><a href="<?=e(safe_link($it['link']))?>"><?=e($it['title'])?></a><?php endforeach;?></div>
<div class="hero-trust"><span>✓ Trusted local directory</span><span>✓ Discover verified businesses</span><span>✓ Grow your business visibility</span></div>
</div>
<div class="hero-side-card">
<h3><?=e(setting('site_name','ShahkotPK'))?></h3>
<p><?=e(setting('site_tagline','Your Digital City Guide'))?> — a professional city portal for local discovery and business visibility.</p>
<div class="hero-stat-grid">
<div class="hero-stat"><strong><?=e(number_format($totalBusinesses))?></strong><span>Active Businesses</span></div>
<div class="hero-stat"><strong><?=e(number_format($totalCategories))?></strong><span>Directory Categories</span></div>
<div class="hero-stat"><strong><?=e(number_format($totalCities))?></strong><span>City Coverage</span></div>
<div class="hero-stat"><strong><?=e(number_format(count($featured)))?></strong><span>Featured Listings</span></div>
</div>
<div class="hero-side-actions">
<?php if(feature_enabled('business_registration_enabled',true) && feature_enabled('shopkeeper_signup_enabled',true)):?><a class="solid" href="/signup.php">Register Business</a><?php endif;?>
<a class="soft" href="/search.php">Explore Directory</a>
</div>
</div>
</div>
</div></section>

<?php elseif($type==='info_cards'): ?>
<div class="city-shell"><div class="info-grid">
<?php foreach($items as $idx=>$it):?>
<div class="info-card"><strong><?=e($it['title'])?></strong>
<span class="<?=stripos($it['title'],'time')!==false?'js-city-time':''?>"><?=e($it['text'])?></span></div>
<?php endforeach;?>
</div></div>

<?php elseif($type==='quick_services'): ?>
<section class="section"><div class="city-shell">
<div class="section-head"><div><div class="section-kicker"><?=e($s['subtitle'])?></div><h2><?=e($s['title'])?></h2><p><?=e($s['content'])?></p></div></div>
<div class="quick-services-grid">
<?php foreach($items as $it):?>
<a class="quick-service-card" href="<?=e(safe_link($it['link']))?>">
<span class="quick-service-icon"><?=e(mb_strtoupper(mb_substr($it['title'],0,1)))?></span>
<strong><?=e($it['title'])?></strong><span><?=e($it['text'])?></span>
</a>
<?php endforeach;?>
</div>
</div></section>

<?php elseif($type==='cta'): ?>
<section class="section"><div class="city-shell"><div class="cta-block">
<div><div class="section-kicker"><?=e($s['subtitle'])?></div><h2><?=e($s['title'])?></h2><p><?=e($s['content'])?></p></div>
<div><?php foreach($items as $it):?><a class="btn btn-primary" href="<?=e(safe_link($it['link']))?>"><?=e($it['title'])?> →</a><?php endforeach;?></div>
</div></div></section>

<?php elseif($type==='content'): ?>
<section class="section alt"><div class="city-shell"><div class="content-split">
<div class="content-copy"><div class="section-kicker"><?=e($s['subtitle'])?></div><h2><?=e($s['title'])?></h2><p><?=nl2br(e($s['content']))?></p></div>
<div class="content-image" style="<?=module_img($s)?>"></div>
</div></div></section>

<?php elseif($type==='directory'): ?>
<section class="section"><div class="city-shell">
<div class="section-head"><div><div class="section-kicker"><?=e($s['subtitle'])?></div><h2><?=e($s['title'])?></h2><p><?=e($s['content'])?></p></div></div>
<?php if($categories):?><div class="category-grid">
<?php foreach($categories as $cat):?><a class="category-card" href="/search.php?category=<?=urlencode($cat['slug'])?>"><span class="category-icon"><?=e(mb_strtoupper(mb_substr($cat['name'],0,1)))?></span><strong><?=e($cat['name'])?></strong><span>Explore listings →</span></a><?php endforeach;?>
</div><?php else:?><div class="empty-state">Categories can be added from Admin → Categories.</div><?php endif;?>
</div></section>

<?php elseif($type==='featured'): ?>
<section class="section alt"><div class="city-shell">
<div class="section-head"><div><div class="section-kicker"><?=e($s['subtitle'])?></div><h2><?=e($s['title'])?></h2><p><?=e($s['content'])?></p></div><a class="btn btn-green" href="/search.php">View Directory</a></div>
<?php if($featured):?><div class="business-grid">
<?php foreach($featured as $b):?><article class="business-card"><div class="business-cover" <?=$b['image']?'style="background-image:url(\''.e($b['image']).'\')"':''?>></div><div class="business-body">
<?php if(feature_enabled('verified_badge_enabled',true)):?><span class="verified"><?=e($b['verification_status']==='verified'?'✓ Verified':'Featured')?></span><?php endif;?>
<h3><?=e($b['name'])?></h3><div class="business-meta"><?=e($b['category_name'])?> · <?=e($b['city_name'])?></div><p><a href="/business.php?slug=<?=urlencode($b['slug'])?>">View Business →</a></p></div></article><?php endforeach;?>
</div><?php else:?><div class="empty-state">Featured businesses will appear here after you add/verify them from Admin.</div><?php endif;?>
</div></section>

<?php elseif($type==='spotlights'): ?>
<section class="section"><div class="city-shell">
<div class="section-head"><div><div class="section-kicker"><?=e($s['subtitle'])?></div><h2><?=e($s['title'])?></h2><p><?=e($s['content'])?></p></div></div>
<div class="spotlight-grid">
<?php foreach($items as $it):?>
<a class="spotlight-card" href="<?=e(safe_link($it['link']))?>" <?=$it['image']?'style="background-image:url(\''.e($it['image']).'\')"':''?>>
<div class="spotlight-content"><strong><?=e($it['title'])?></strong><span><?=e($it['text'])?></span><em>Explore →</em></div>
</a>
<?php endforeach;?>
</div>
</div></section>

<?php elseif($type==='gallery'): ?>
<section class="section"><div class="city-shell">
<div class="section-head"><div><div class="section-kicker"><?=e($s['subtitle'])?></div><h2><?=e($s['title'])?></h2><p><?=e($s['content'])?></p></div></div>
<div class="gallery-grid"><?php foreach($items as $it):?><div class="gallery-card" <?=$it['image']?'style="background-image:url(\''.e($it['image']).'\')"':''?>><div class="gallery-text"><strong><?=e($it['title'])?></strong><span><?=e($it['text'])?></span></div></div><?php endforeach;?></div>
</div></section>

<?php elseif($type==='links'): ?>
<section class="section alt"><div class="city-shell"><div class="section-head"><div><div class="section-kicker"><?=e($s['subtitle'])?></div><h2><?=e($s['title'])?></h2></div></div>
<div class="link-grid"><?php foreach($items as $it):?><a class="city-link" href="<?=e(safe_link($it['link']))?>"><?=e($it['title'])?></a><?php endforeach;?></div>
</div></section>

<?php elseif($type==='footer'): ?>
<footer class="site-footer"><div class="city-shell"><div class="footer-grid"><div><div class="footer-title"><?=e(setting('site_name',$s['title']))?></div><div><?=e($s['subtitle'])?></div></div><div class="footer-links"><?php foreach($items as $it):?><a href="<?=e(safe_link($it['link']))?>"><?=e($it['title'])?></a><?php endforeach;?></div></div><div class="footer-copy"><?=e($s['content'])?></div></div></footer>

<?php else: ?>
<section class="section"><div class="city-shell"><div class="custom-card">
<div class="section-kicker"><?=e($s['subtitle'])?></div><h2><?=e($s['title'])?></h2><p><?=nl2br(e($s['content']))?></p>
<?php if($items):?><div class="custom-items"><?php foreach($items as $it):?><div class="custom-item"><strong><?=e($it['title'])?></strong><div><?=e($it['text'])?></div><?php if($it['link']):?><a href="<?=e(safe_link($it['link']))?>">Open →</a><?php endif;?></div><?php endforeach;?></div><?php endif;?>
</div></div></section>
<?php endif;?>

<?php endforeach;?>
</div>

<?php if(feature_enabled('mobile_sticky_cta_enabled',true)):?>
<div class="mobile-sticky-cta">
<a class="sticky-search" href="/search.php">⌕ Search Shahkot</a>
<?php if(feature_enabled('business_registration_enabled',true) && feature_enabled('shopkeeper_signup_enabled',true)):?>
<a class="sticky-business" href="/signup.php">＋ List Business</a>
<?php else:?>
<a class="sticky-business" href="/login.php">Login</a>
<?php endif;?>
</div>
<?php endif;?>

<script>
(function(){
 const els=document.querySelectorAll('.js-city-time');
 if(!els.length)return;
 function update(){
   const d=new Date();
   const text=new Intl.DateTimeFormat('en-PK',{timeZone:'Asia/Karachi',weekday:'short',day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(d)+' PKT';
   els.forEach(el=>el.textContent=text);
 }
 update();setInterval(update,1000);
})();
</script>
<script src="/assets/shahkotpk-1.6.0.js?v=160" defer></script>
</body></html>
