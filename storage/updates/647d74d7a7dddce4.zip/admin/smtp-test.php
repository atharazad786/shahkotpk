<?php
require __DIR__.'/../app/bootstrap.php';
require_permission('settings.manage');
require __DIR__.'/../app/mailer.php';

$success=$error=null;
$email=setting('smtp_from_email',setting('support_email',''));

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        csrf_check();
        $email=trim((string)($_POST['email']??''));
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Enter a valid test email address.');

        $site=e(setting('site_name','ShahkotPK'));
        smtp_send_mail(
            $email,
            'ShahkotPK SMTP Test',
            '<div style="font-family:Arial,sans-serif;max-width:620px;margin:auto;padding:26px"><h2>SMTP is working</h2><p>This is a successful test email from '.$site.'.</p><p>Your forgot-password emails can now be delivered through the configured SMTP server.</p></div>'
        );
        $success='Test email sent successfully to '.$email.'.';
    }catch(Throwable $e){
        $error=$e->getMessage();
    }
}

require __DIR__.'/../app/layout.php';
page_start('SMTP Test',true);
?>
<div class="card" style="max-width:760px">
<h1>Send SMTP Test Email</h1>
<p class="muted">Save your SMTP configuration in Admin → Settings first, then send a real test email here.</p>
<?php if($success):?><div class="success"><?=e($success)?></div><?php endif;?>
<?php if($error):?><div class="error"><?=e($error)?></div><?php endif;?>
<form method="post">
<input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
<label>Test Email Address</label>
<input class="input" type="email" name="email" value="<?=e($email)?>" required>
<br><br>
<button class="btn">Send Test Email</button>
<a class="btn ghost" href="/admin/settings.php">Back to Settings</a>
</form>
</div>
<?php require __DIR__.'/../app/end.php';?>
