<?php
require __DIR__.'/app/bootstrap.php';
if(!feature_enabled('directory_enabled',true)){http_response_code(403);exit('Business directory is currently disabled.');}
$slug=trim($_GET['slug']??'');
$stmt=db()->prepare("SELECT b.*,c.name city_name,cat.name category_name FROM businesses b JOIN cities c ON c.id=b.city_id JOIN categories cat ON cat.id=b.category_id WHERE b.slug=? AND b.status=1 LIMIT 1");
$stmt->execute([$slug]);$b=$stmt->fetch();
if(!$b){http_response_code(404);exit('Business not found.');}

$viewer=current_user();
$isFavorite=false;
if($viewer && $viewer['role']==='customer'){
    try{
        $fq=db()->prepare("SELECT id FROM favorite_businesses WHERE user_id=? AND business_id=? LIMIT 1");
        $fq->execute([$viewer['id'],$b['id']]);
        $isFavorite=(bool)$fq->fetchColumn();
    }catch(Throwable $e){}
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($b['name'])?> - <?=e(setting('site_name','ShahkotPK'))?></title><link rel="stylesheet" href="/assets/shahkotpk-1.5.0.css?v=150"></head><body>
<div class="city-header"><div class="city-shell city-header-inner"><a class="brand" href="/"><span class="brand-mark">S</span><span><strong><?=e(setting('site_name','ShahkotPK'))?></strong><small>Business Showcase</small></span></a><a class="btn btn-green" href="/search.php">Back to Directory</a></div></div>
<section class="page-hero"><div class="city-shell"><div class="section-head"><div><div class="section-kicker"><?=e($b['category_name'])?> · <?=e($b['city_name'])?></div><h2><?=e($b['name'])?></h2><p>Explore detailed information about this business.</p></div></div></div></section>
<section class="section" style="padding-top:20px"><div class="city-shell"><div class="content-split"><div class="content-copy"><div class="section-kicker"><?=e($b['category_name'])?> · <?=e($b['city_name'])?></div><h2><?=e($b['name'])?></h2><p><?=nl2br(e($b['description']))?></p><p><strong>Address:</strong> <?=e($b['address'])?></p><p>
<?php if($b['phone']):?><a class="btn btn-green" href="tel:<?=e($b['phone'])?>">Call</a><?php endif;?>
<?php if($b['whatsapp']):?><a class="btn btn-green" target="_blank" rel="noopener" href="https://wa.me/<?=e(preg_replace('/\D/','',$b['whatsapp']))?>">WhatsApp</a><?php endif;?>
<?php if($viewer && $viewer['role']==='customer'):?>
<form method="post" action="/favorite.php" style="display:inline">
<input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
<input type="hidden" name="business_id" value="<?=e($b['id'])?>">
<input type="hidden" name="return" value="<?=e('/business.php?slug='.urlencode($b['slug']))?>">
<button class="btn <?=$isFavorite?'btn-primary':'btn-green'?>" type="submit"><?=$isFavorite?'★ Saved':'☆ Save Business'?></button>
</form>
<?php endif;?>
</p></div><div class="content-image" <?=$b['image']?'style="background-image:url(\''.e($b['image']).'\')"':''?>></div></div></div></section>
</body></html>
