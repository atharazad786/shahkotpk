<?php
require __DIR__.'/app/bootstrap.php';
require __DIR__.'/app/mailer.php';

if(!feature_enabled('forgot_password_enabled',true)){
    http_response_code(403);
    exit('Password recovery is currently disabled.');
}

$success=null;
$error=null;
$loginInput='';

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        csrf_check();
        $loginInput=trim((string)($_POST['login']??''));
        if($loginInput==='') throw new RuntimeException('Please enter your registered email or phone number.');
        if(!smtp_settings_ready()) throw new RuntimeException('Password recovery email is not configured yet. Please contact the website administrator.');

        $q=db()->prepare("SELECT id,name,email,phone,status FROM users WHERE email=? OR phone=? LIMIT 1");
        $q->execute([$loginInput,$loginInput]);
        $user=$q->fetch();

        // Generic success message prevents account enumeration.
        $success='If an active account with an email address matches the information provided, a password reset email has been sent.';

        if($user && $user['status']==='active' && filter_var((string)$user['email'],FILTER_VALIDATE_EMAIL)){
            $rawToken=bin2hex(random_bytes(32));
            $tokenHash=hash('sha256',$rawToken);
            $minutes=max(10,min(1440,setting_int('password_reset_expiry_minutes',60)));
            $expiresAt=date('Y-m-d H:i:s',strtotime('+'.$minutes.' minutes'));

            db()->prepare("DELETE FROM password_reset_tokens WHERE user_id=? AND (used_at IS NOT NULL OR expires_at<NOW())")->execute([$user['id']]);
            $q=db()->prepare("INSERT INTO password_reset_tokens(user_id,token,expires_at) VALUES(?,?,?)");
            $q->execute([$user['id'],$tokenHash,$expiresAt]);
            $tokenId=(int)db()->lastInsertId();

            $scheme=(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off')?'https':'http';
            $host=$_SERVER['HTTP_HOST']??'localhost';
            $resetUrl=$scheme.'://'.$host.'/reset-password.php?token='.urlencode($rawToken);
            $siteName=setting('site_name','ShahkotPK');

            $html='<div style="background:#f4f8f5;padding:28px;font-family:Arial,sans-serif;color:#173228">'
                .'<div style="max-width:620px;margin:auto;background:white;border:1px solid #dfe9e2;border-radius:18px;padding:28px">'
                .'<h2 style="margin-top:0;color:#176b46">Reset your '.$siteName.' password</h2>'
                .'<p>Hello '.e($user['name']).',</p>'
                .'<p>We received a request to reset your password. Use the button below within '.$minutes.' minutes.</p>'
                .'<p style="margin:26px 0"><a href="'.e($resetUrl).'" style="display:inline-block;background:#176b46;color:white;text-decoration:none;padding:13px 18px;border-radius:10px;font-weight:bold">Reset Password</a></p>'
                .'<p>If you did not request this change, you can ignore this email.</p>'
                .'<p style="font-size:12px;color:#718078">For security, this link is one-time use and expires automatically.</p>'
                .'</div></div>';

            try{
                smtp_send_mail((string)$user['email'],'Reset your '.$siteName.' password',$html);
            }catch(Throwable $mailError){
                db()->prepare("DELETE FROM password_reset_tokens WHERE id=?")->execute([$tokenId]);
                throw $mailError;
            }
        }

    }catch(Throwable $e){
        $error=$e->getMessage();
    }
}

$siteName=setting('site_name','ShahkotPK');
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Forgot Password - <?=e($siteName)?></title>
<link rel="stylesheet" href="/assets/shahkotpk-1.6.0.css?v=160">
<link rel="stylesheet" href="/assets/shahkotpk-auth-1.5.1.css?v=151">
<link rel="stylesheet" href="/assets/shahkotpk-userdash-1.7.0.css?v=170">
</head>
<body class="auth-page">
<div class="auth-shell">
<div class="auth-topbar">
<a class="auth-back" href="/login.php">← Back to Login</a>
<div class="auth-mini-links"><a href="/">Homepage</a><a href="/signup.php">Create Account</a></div>
</div>

<div class="auth-layout">
<div class="auth-showcase">
<span class="auth-badge">● Secure email recovery</span>
<h1>Reset your password by email.</h1>
<p>Enter your registered email address or phone number. If your account has a valid email address, ShahkotPK will send a secure one-time reset link through the configured SMTP server.</p>

<div class="auth-points">
<div class="auth-point"><div>✓</div><div><strong>Real SMTP delivery</strong><span>Password reset links are sent to the email on your account.</span></div></div>
<div class="auth-point"><div>✓</div><div><strong>One-time reset token</strong><span>The secure link is hashed in the database and expires automatically.</span></div></div>
<div class="auth-point"><div>✓</div><div><strong>Privacy protected</strong><span>The page does not reveal whether a particular account exists.</span></div></div>
</div>
</div>

<div class="auth-card">
<h2>Forgot Password</h2>
<p>Enter the email or phone number linked with your account.</p>

<?php if($error):?><div class="error auth-alert"><?=e($error)?></div><?php endif;?>
<?php if($success):?><div class="success auth-alert"><?=e($success)?></div><?php endif;?>

<form class="auth-form" method="post">
<input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
<div class="auth-field">
<label for="login">Email or Phone</label>
<input class="auth-input" id="login" name="login" value="<?=e($loginInput)?>" placeholder="Enter your registered email or phone" required>
</div>
<button class="auth-submit" type="submit">Email Password Reset Link</button>
</form>

<div class="auth-footer">Remember your password? <a href="/login.php">Back to Login</a></div>
</div>
</div>
</div>
</body>
</html>
