<?php
require __DIR__.'/app/bootstrap.php';

$token=trim((string)($_GET['token'] ?? $_POST['token'] ?? ''));
$error=null;
$success=null;
$validToken=false;

if($token!==''){
    try{
        $tokenHash=hash('sha256',$token);
        $q=db()->prepare("SELECT prt.id,prt.user_id,prt.expires_at,prt.used_at,u.status FROM password_reset_tokens prt JOIN users u ON u.id=prt.user_id WHERE prt.token=? LIMIT 1");
        $q->execute([$tokenHash]);
        $resetRow=$q->fetch();

        if($resetRow && !$resetRow['used_at'] && strtotime($resetRow['expires_at']) > time() && $resetRow['status']==='active'){
            $validToken=true;
        }
    }catch(Throwable $e){
        $error='Unable to validate token right now.';
    }
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        csrf_check();

        if(!$validToken) throw new RuntimeException('This reset link is invalid or expired.');

        $password=(string)($_POST['password']??'');
        $confirm=(string)($_POST['confirm_password']??'');

        if(strlen($password) < 8) throw new RuntimeException('Password must be at least 8 characters.');
        if($password !== $confirm) throw new RuntimeException('Password confirmation does not match.');

        db()->beginTransaction();

        $q=db()->prepare("UPDATE users SET password_hash=? WHERE id=?");
        $q->execute([password_hash($password,PASSWORD_DEFAULT),$resetRow['user_id']]);

        $q=db()->prepare("UPDATE password_reset_tokens SET used_at=NOW() WHERE id=?");
        $q->execute([$resetRow['id']]);

        db()->commit();

        header('Location: /login.php?reset=1');
        exit;
    }catch(Throwable $e){
        if(db()->inTransaction()) db()->rollBack();
        $error=$e->getMessage();
    }
}

$siteName=setting('site_name','ShahkotPK');
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Reset Password - <?=e($siteName)?></title>
<link rel="stylesheet" href="/assets/shahkotpk-1.6.0.css?v=160">
<link rel="stylesheet" href="/assets/shahkotpk-auth-1.5.1.css?v=151">
<link rel="stylesheet" href="/assets/shahkotpk-userdash-1.7.0.css?v=170">
<?php if(setting('favicon_url','')):?><link rel="icon" href="<?=e(setting('favicon_url',''))?>"><?php endif;?>
</head>
<body class="auth-page">
<div class="auth-shell">
    <div class="auth-topbar">
        <a class="auth-back" href="/login.php">← Back to Login</a>
        <div class="auth-mini-links"><a href="/">Homepage</a></div>
    </div>

    <div class="auth-layout">
        <div class="auth-showcase">
            <span class="auth-badge">● Secure reset</span>
            <h1>Create a new password.</h1>
            <p>Choose a strong password to secure your account and continue using the platform safely.</p>
            <div class="auth-points">
                <div class="auth-point"><div>✓</div><div><strong>Use a strong password</strong><span>At least 8 characters is recommended.</span></div></div>
                <div class="auth-point"><div>✓</div><div><strong>One-time token</strong><span>This reset link works only while it is valid and unused.</span></div></div>
                <div class="auth-point"><div>✓</div><div><strong>Instant update</strong><span>Your password changes immediately after a successful reset.</span></div></div>
            </div>
        </div>

        <div class="auth-card">
            <h2>Reset Password</h2>

            <?php if($error):?><div class="error auth-alert"><?=e($error)?></div><?php endif;?>

            <?php if($validToken):?>
            <form class="auth-form" method="post">
                <input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
                <input type="hidden" name="token" value="<?=e($token)?>">
                <div class="auth-field">
                    <label for="password">New Password</label>
                    <input class="auth-input" id="password" type="password" name="password" placeholder="Minimum 8 characters" required>
                </div>
                <div class="auth-field">
                    <label for="confirm_password">Confirm Password</label>
                    <input class="auth-input" id="confirm_password" type="password" name="confirm_password" placeholder="Re-enter your new password" required>
                </div>
                <button class="auth-submit" type="submit">Update Password</button>
            </form>
            <?php else:?>
            <div class="dash-empty">This reset link is invalid, expired or already used. Please generate a new reset link from the forgot password page.</div>
            <div class="dash-btn-line">
                <a class="dash-btn primary" href="/forgot-password.php">Generate New Link</a>
            </div>
            <?php endif;?>
        </div>
    </div>
</div>
</body>
</html>
