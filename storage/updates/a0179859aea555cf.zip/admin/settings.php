<?php
require __DIR__.'/../app/bootstrap.php';
require_admin();

$success=$error=null;
$defaults=shahkot_default_settings();
ensure_default_settings();

$groups=[
    'General'=>[
        'site_name'=>['text','Site Name'],
        'site_tagline'=>['text','Site Tagline'],
        'default_city'=>['text','Default City'],
        'timezone'=>['select','Timezone',['Asia/Karachi'=>'Asia/Karachi','UTC'=>'UTC']],
        'language'=>['select','Language',['en'=>'English','ur'=>'Urdu']],
        'currency'=>['select','Currency',['PKR'=>'PKR','USD'=>'USD']],
    ],
    'Contact'=>[
        'support_phone'=>['text','Support Phone'],
        'support_email'=>['email','Support Email'],
        'support_whatsapp'=>['text','Support WhatsApp'],
        'business_address'=>['textarea','Business / Office Address'],
    ],
    'Branding'=>[
        'logo_url'=>['text','Logo URL'],
        'favicon_url'=>['text','Favicon URL'],
        'brand_primary_color'=>['color','Primary Color'],
        'brand_secondary_color'=>['color','Secondary Color'],
    ],
    'SEO'=>[
        'seo_title'=>['text','SEO Title'],
        'seo_description'=>['textarea','SEO Description'],
        'seo_keywords'=>['textarea','SEO Keywords'],
        'og_image'=>['text','Social Share / OG Image URL'],
        'robots_index'=>['toggle','Allow Search Engine Indexing'],
    ],
    'Accounts & Login'=>[
        'login_enabled'=>['toggle','Public Login Enabled'],
        'registration_enabled'=>['toggle','Registration Enabled'],
        'customer_signup_enabled'=>['toggle','Customer Signup Enabled'],
        'shopkeeper_signup_enabled'=>['toggle','Shopkeeper Signup Enabled'],
        'email_required'=>['toggle','Require Email at Signup'],
        'phone_required'=>['toggle','Require Phone at Signup'],
    ],
    'Business Directory'=>[
        'business_registration_enabled'=>['toggle','Business Registration Enabled'],
        'directory_enabled'=>['toggle','Public Directory Enabled'],
        'search_enabled'=>['toggle','Public Search Enabled'],
        'featured_businesses_enabled'=>['toggle','Featured Businesses Enabled'],
        'verified_badge_enabled'=>['toggle','Verified Badge Enabled'],
    ],
    'Subscriptions & Ads'=>[
        'subscriptions_enabled'=>['toggle','Subscription System Enabled'],
        'free_plan_enabled'=>['toggle','Free Plan Enabled'],
        'paid_plans_enabled'=>['toggle','Paid Plans Enabled'],
        'advertisements_enabled'=>['toggle','Advertisement System Enabled'],
        'sponsored_listings_enabled'=>['toggle','Sponsored Listings Enabled'],
    ],
    'Homepage Global Switches'=>[
        'homepage_slider_enabled'=>['toggle','Homepage Slider / Banner Enabled'],
        'homepage_slider_interval_ms'=>['number','Slider Autoplay Interval (milliseconds)'],
        'homepage_search_enabled'=>['toggle','Homepage Search Enabled'],
        'homepage_animations_enabled'=>['toggle','Homepage Animations Enabled'],
        'mobile_menu_enabled'=>['toggle','Mobile Menu Enabled'],
        'mobile_sticky_cta_enabled'=>['toggle','Mobile Sticky CTA Enabled'],
        'homepage_directory_enabled'=>['toggle','Homepage Directory Enabled'],
        'homepage_featured_enabled'=>['toggle','Homepage Featured Businesses Enabled'],
        'homepage_gallery_enabled'=>['toggle','Homepage Gallery Enabled'],
        'homepage_city_info_enabled'=>['toggle','Homepage City Info Enabled'],
    ],
    'Uploads'=>[
        'image_uploads_enabled'=>['toggle','Image Uploads Enabled'],
        'max_image_upload_mb'=>['number','Maximum Image Upload Size (MB)'],
        'allowed_image_types'=>['text','Allowed Image Types'],
    ],
    'Email & SMTP'=>[
        'forgot_password_enabled'=>['toggle','Forgot Password Enabled'],
        'password_reset_expiry_minutes'=>['number','Password Reset Expiry (minutes)'],
        'smtp_enabled'=>['toggle','SMTP Email Sending Enabled'],
        'smtp_host'=>['text','SMTP Host'],
        'smtp_port'=>['number','SMTP Port'],
        'smtp_encryption'=>['select','SMTP Encryption',['tls'=>'STARTTLS / TLS','ssl'=>'SSL','none'=>'None']],
        'smtp_username'=>['text','SMTP Username'],
        'smtp_password'=>['password','SMTP Password'],
        'smtp_from_email'=>['email','From Email'],
        'smtp_from_name'=>['text','From Name'],
        'smtp_timeout'=>['number','SMTP Timeout (seconds)'],
    ],
    'System & Security'=>[
        'update_system_enabled'=>['toggle','System Updater Enabled'],
        'maintenance_mode'=>['toggle','Maintenance Mode'],
        'debug_mode'=>['toggle','Debug Mode'],
        'csrf_protection_enabled'=>['toggle','CSRF Protection Enabled'],
        'session_regenerate_on_login'=>['toggle','Regenerate Session on Login'],
    ],
];

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        csrf_check();
        $action=$_POST['action']??'save';

        if($action==='defaults'){
            save_settings($defaults);
            $success='All settings restored to recommended defaults.';
        }else{
            $values=[];
            foreach($groups as $fields){
                foreach($fields as $key=>$meta){
                    $type=$meta[0];
                    if($type==='toggle'){
                        $values[$key]=isset($_POST[$key])?'1':'0';
                    }else{
                        $values[$key]=trim((string)($_POST[$key]??''));
                    }
                }
            }

            if(($values['smtp_password']??'')===''){
                $values['smtp_password']=(string)setting('smtp_password','');
            }

            $max=(int)($values['max_image_upload_mb']??5);
            if($max<1 || $max>50) throw new RuntimeException('Image upload limit must be between 1 and 50 MB.');

            foreach(['brand_primary_color','brand_secondary_color'] as $colorKey){
                if(!preg_match('/^#[0-9A-Fa-f]{6}$/',$values[$colorKey]??'')){
                    throw new RuntimeException('Brand colors must use a valid HEX value such as #176b46.');
                }
            }

            // Prevent accidental permanent lockout of update section when maintenance is enabled.
            if(($values['maintenance_mode']??'0')==='1'){
                $values['login_enabled']='1';
            }

            save_settings($values);
            $success='Settings saved and activated successfully.';
        }
    }catch(Throwable $e){
        $error=$e->getMessage();
    }
}

$s=site_settings(true);

require __DIR__.'/../app/layout.php';
page_start('Settings',true);
?>
<style>
.settings-tabs{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px}
.settings-tabs a{padding:9px 12px;border-radius:10px;background:#eef2f7;text-decoration:none;font-size:12px;font-weight:800;color:#475569}
.settings-section{scroll-margin-top:100px}
.settings-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
.toggle-row{display:flex;justify-content:space-between;align-items:center;gap:20px;padding:12px 14px;border:1px solid #e5eaf1;border-radius:12px;background:#f9fbfd}
.toggle-row label{margin:0}
.switch{position:relative;width:46px;height:25px;display:inline-block}
.switch input{opacity:0;width:0;height:0}
.slider{position:absolute;inset:0;background:#cbd5e1;border-radius:999px;cursor:pointer;transition:.2s}
.slider:before{content:"";position:absolute;width:19px;height:19px;left:3px;top:3px;background:white;border-radius:50%;transition:.2s;box-shadow:0 1px 5px #0002}
.switch input:checked+.slider{background:#2563eb}.switch input:checked+.slider:before{transform:translateX(21px)}
.settings-note{padding:12px;border-radius:12px;background:#eff6ff;color:#1e40af;font-size:12px}
@media(max-width:800px){.settings-grid{grid-template-columns:1fr}}
</style>

<div class="card">
<div class="dashboard-heading">
<div><h2>Platform Settings</h2><p>Control the complete ShahkotPK website from one place.</p></div>
<div><a class="btn ghost" href="/" target="_blank">Preview Website ↗</a></div>
</div>
<?php if($success):?><div class="success"><?=e($success)?></div><?php endif;?>
<?php if($error):?><div class="error"><?=e($error)?></div><?php endif;?>
<div class="settings-note">Recommended public features are active by default. Maintenance Mode and Debug Mode remain OFF for normal production use. After saving SMTP credentials, use <a href="/admin/smtp-test.php"><b>Send SMTP Test Email</b></a> to verify email delivery.</div>
</div>

<div class="settings-tabs">
<?php foreach(array_keys($groups) as $group):$anchor=strtolower(preg_replace('/[^a-z0-9]+/i','-',$group));?>
<a href="#<?=e($anchor)?>"><?=e($group)?></a>
<?php endforeach;?>
</div>

<form method="post">
<input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
<input type="hidden" name="action" value="save">

<?php foreach($groups as $group=>$fields):
$anchor=strtolower(preg_replace('/[^a-z0-9]+/i','-',$group));?>
<div class="card settings-section" id="<?=e($anchor)?>">
<h2><?=e($group)?></h2>
<div class="settings-grid">
<?php foreach($fields as $key=>$meta):
$type=$meta[0];$label=$meta[1];$value=(string)($s[$key]??$defaults[$key]??'');?>
<?php if($type==='toggle'):?>
<div class="toggle-row">
<div><label><?=e($label)?></label><div class="muted"><?=e($key)?></div></div>
<label class="switch"><input type="checkbox" name="<?=e($key)?>" value="1" <?=$value==='1'?'checked':''?>><span class="slider"></span></label>
</div>
<?php elseif($type==='textarea'):?>
<div><label><?=e($label)?></label><textarea class="input" rows="3" name="<?=e($key)?>"><?=e($value)?></textarea></div>
<?php elseif($type==='select'):?>
<div><label><?=e($label)?></label><select class="input" name="<?=e($key)?>"><?php foreach($meta[2] as $v=>$txt):?><option value="<?=e($v)?>" <?=$value===(string)$v?'selected':''?>><?=e($txt)?></option><?php endforeach;?></select></div>
<?php elseif($type==='color'):?>
<div><label><?=e($label)?></label><input class="input" type="color" name="<?=e($key)?>" value="<?=e($value?:'#176b46')?>" style="height:48px"></div>
<?php elseif($type==='number'):?>
<div><label><?=e($label)?></label><input class="input" type="number" min="1" name="<?=e($key)?>" value="<?=e($value)?>"></div>
<?php elseif($type==='password'):?>
<div><label><?=e($label)?></label><input class="input" type="password" name="<?=e($key)?>" value="" placeholder="<?=$value!==''?'Saved — leave blank to keep existing':'Enter SMTP password'?>"></div>
<?php else:?>
<div><label><?=e($label)?></label><input class="input" type="<?=e($type)?>" name="<?=e($key)?>" value="<?=e($value)?>"></div>
<?php endif;?>
<?php endforeach;?>
</div>
</div>
<?php endforeach;?>

<div class="builder-footer">
<button class="btn" type="submit">Save & Activate Settings</button>
<a class="btn ghost" href="/admin/settings.php">Reload</a>
</div>
</form>

<div class="card">
<h2>Restore Recommended Defaults</h2>
<p class="muted">This restores all configuration switches and text fields to the recommended production defaults. Existing users/business data is not touched.</p>
<form method="post" onsubmit="return confirm('Restore all settings to recommended defaults?')">
<input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
<input type="hidden" name="action" value="defaults">
<button class="btn danger">Restore Defaults</button>
</form>
</div>

<?php require __DIR__.'/../app/end.php';?>
