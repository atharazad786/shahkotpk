<?php
declare(strict_types=1);

function shahkot_default_settings(): array {
    return [
        // General
        'site_name' => 'ShahkotPK',
        'site_tagline' => 'Your Digital City Guide',
        'default_city' => 'Shahkot',
        'timezone' => 'Asia/Karachi',
        'language' => 'en',
        'currency' => 'PKR',

        // Contact
        'support_phone' => '',
        'support_email' => '',
        'support_whatsapp' => '',
        'business_address' => '',

        // Branding
        'logo_url' => '',
        'favicon_url' => '',
        'brand_primary_color' => '#176b46',
        'brand_secondary_color' => '#0f3d29',

        // SEO
        'seo_title' => 'ShahkotPK — Shahkot Business Directory & City Guide',
        'seo_description' => 'Discover Shahkot businesses, services, places, offers and useful city information.',
        'seo_keywords' => 'Shahkot, Shahkot businesses, Shahkot directory, Shahkot city guide',
        'og_image' => '',
        'robots_index' => '1',

        // Authentication / accounts
        'login_enabled' => '1',
        'registration_enabled' => '1',
        'customer_signup_enabled' => '1',
        'shopkeeper_signup_enabled' => '1',
        'email_required' => '0',
        'phone_required' => '0',

        // Business & directory
        'business_registration_enabled' => '1',
        'directory_enabled' => '1',
        'search_enabled' => '1',
        'featured_businesses_enabled' => '1',
        'verified_badge_enabled' => '1',

        // Commercial modules
        'subscriptions_enabled' => '1',
        'free_plan_enabled' => '1',
        'paid_plans_enabled' => '1',
        'advertisements_enabled' => '1',
        'sponsored_listings_enabled' => '1',

        // Homepage global switches
        'homepage_slider_enabled' => '1',
        'homepage_slider_interval_ms' => '5500',
        'homepage_search_enabled' => '1',
        'homepage_animations_enabled' => '1',
        'mobile_menu_enabled' => '1',
        'mobile_sticky_cta_enabled' => '1',
        'homepage_directory_enabled' => '1',
        'homepage_featured_enabled' => '1',
        'homepage_gallery_enabled' => '1',
        'homepage_city_info_enabled' => '1',

        // Uploads
        'image_uploads_enabled' => '1',
        'max_image_upload_mb' => '5',
        'allowed_image_types' => 'jpg,jpeg,png,webp,gif',

        // System / security
        'update_system_enabled' => '1',
        'maintenance_mode' => '0',
        'debug_mode' => '0',
        'csrf_protection_enabled' => '1',
        'session_regenerate_on_login' => '1',

        // Email / SMTP
        'forgot_password_enabled' => '1',
        'password_reset_expiry_minutes' => '60',
        'smtp_enabled' => '0',
        'smtp_host' => '',
        'smtp_port' => '587',
        'smtp_encryption' => 'tls',
        'smtp_username' => '',
        'smtp_password' => '',
        'smtp_from_email' => '',
        'smtp_from_name' => 'ShahkotPK',
        'smtp_timeout' => '15',
    ];
}

function site_settings(bool $refresh=false): array {
    static $cache=null;
    if($cache!==null && !$refresh) return $cache;

    $cache=shahkot_default_settings();

    try{
        $rows=db()->query("SELECT setting_key,setting_value FROM settings")->fetchAll();
        foreach($rows as $row){
            $cache[(string)$row['setting_key']] = (string)($row['setting_value'] ?? '');
        }
    }catch(Throwable $e){}

    return $cache;
}

function setting(string $key, $default=null) {
    $settings=site_settings();
    return array_key_exists($key,$settings) ? $settings[$key] : $default;
}

function setting_bool(string $key, bool $default=false): bool {
    $fallback=$default?'1':'0';
    return in_array((string)setting($key,$fallback),['1','true','yes','on'],true);
}

function setting_int(string $key, int $default=0): int {
    return (int)setting($key,(string)$default);
}

function save_setting(string $key, string $value): void {
    $q=db()->prepare("INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");
    $q->execute([$key,$value]);
}

function save_settings(array $values): void {
    db()->beginTransaction();
    try{
        $q=db()->prepare("INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");
        foreach($values as $key=>$value){
            $q->execute([(string)$key,(string)$value]);
        }
        db()->commit();
    }catch(Throwable $e){
        if(db()->inTransaction()) db()->rollBack();
        throw $e;
    }
    site_settings(true);
}

function ensure_default_settings(): void {
    $defaults=shahkot_default_settings();
    try{
        $q=db()->prepare("INSERT IGNORE INTO settings(setting_key,setting_value) VALUES(?,?)");
        foreach($defaults as $key=>$value) $q->execute([$key,$value]);
        site_settings(true);
    }catch(Throwable $e){}
}

function feature_enabled(string $key, bool $default=true): bool {
    return setting_bool($key,$default);
}

function maintenance_should_block(): bool {
    if(!setting_bool('maintenance_mode',false)) return false;
    $path=$_SERVER['PHP_SELF']??'';
    if(str_contains($path,'/admin/')) return false;
    if(str_ends_with($path,'/logout.php')) return false;
    return true;
}

function output_maintenance_page(): never {
    http_response_code(503);
    header('Retry-After: 3600');
    $name=htmlspecialchars((string)setting('site_name','ShahkotPK'),ENT_QUOTES,'UTF-8');
    echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Maintenance - '.$name.'</title><style>body{margin:0;font-family:Arial;background:#f3f6fb;color:#172033;display:grid;place-items:center;min-height:100vh}.box{max-width:580px;background:white;border:1px solid #e2e8f0;border-radius:20px;padding:34px;box-shadow:0 18px 45px #0001;text-align:center}h1{margin-top:0}</style></head><body><div class="box"><h1>'.$name.'</h1><p>Website is temporarily under maintenance. Please check again shortly.</p></div></body></html>';
    exit;
}
