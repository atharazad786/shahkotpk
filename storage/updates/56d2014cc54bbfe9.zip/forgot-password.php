<?php
require __DIR__.'/app/bootstrap.php';

$success=null;
$error=null;
$resetLink='';
$loginInput='';

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        csrf_check();
        $loginInput=trim((string)($_POST['login']??''));
        if($loginInput==='') throw new RuntimeException('Please enter your email or phone number.');

        $q=db()->prepare("SELECT id,name,email,phone,status FROM users WHERE email=? OR phone=? LIMIT 1");
        $q->execute([$loginInput,$loginInput]);
        $user=$q->fetch();

        if($user && $user['status']==='active'){
            $token=bin2hex(random_bytes(24));
            $expiresAt=date('Y-m-d H:i:s', strtotime('+1 hour'));

            $q=db()->prepare("INSERT INTO password_reset_tokens(user_id, token, expires_at) VALUES(?,?,?)");
            $q->execute([$user['id'],$token,$expiresAt]);

            $scheme=(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') ? 'https' : 'http';
            $host=$_SERVER['HTTP_HOST'] ?? 'localhost';
            $resetLink=$scheme.'://'.$host.'/reset-password.php?token='.$token;

            $success='Password reset link generated successfully. Since SMTP/email is not configured in this build, copy the secure reset link below and open it to set a new password.';
        }else{
            $success='If an active account exists for that email/phone, a password reset link has been generated.';
        }
    }catch(Throwable $e){
        $error=$e->getMessage();
    }
}

$siteName=setting('site_name','ShahkotPK');
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Forgot Password - <?=e($siteName)?></title>
<link rel="stylesheet" href="/assets/shahkotpk-1.6.0.css?v=160">
<link rel="stylesheet" href="/assets/shahkotpk-auth-1.5.1.css?v=151">
<link rel="stylesheet" href="/assets/shahkotpk-userdash-1.7.0.css?v=170">
<?php if(setting('favicon_url','')):?><link rel="icon" href="<?=e(setting('favicon_url',''))?>"><?php endif;?>
</head>
<body class="auth-page">
<div class="auth-shell">
    <div class="auth-topbar">
        <a class="auth-back" href="/login.php">← Back to Login</a>
        <div class="auth-mini-links">
            <a href="/">Homepage</a>
            <a href="/signup.php">Create Account</a>
        </div>
    </div>

    <div class="auth-layout">
        <div class="auth-showcase">
            <span class="auth-badge">● Password assistance</span>
            <h1>Reset your password securely.</h1>
            <p>Enter your registered email address or phone number. A secure reset link will be generated so you can create a new password.</p>

            <div class="auth-points">
                <div class="auth-point">
                    <div>✓</div>
                    <div><strong>Secure token-based reset</strong><span>Each reset request creates a unique link with an expiry time.</span></div>
                </div>
                <div class="auth-point">
                    <div>✓</div>
                    <div><strong>No admin dependency</strong><span>You can reset your password yourself using the generated secure reset link.</span></div>
                </div>
                <div class="auth-point">
                    <div>✓</div>
                    <div><strong>Fast recovery</strong><span>Open the generated link and choose a new password instantly.</span></div>
                </div>
            </div>
        </div>

        <div class="auth-card">
            <h2>Forgot Password</h2>
            <p>Enter the email or phone number you used during registration.</p>

            <?php if($error):?><div class="error auth-alert"><?=e($error)?></div><?php endif;?>
            <?php if($success):?><div class="success auth-alert"><?=e($success)?></div><?php endif;?>

            <form class="auth-form" method="post">
                <input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
                <div class="auth-field">
                    <label for="login">Email or Phone</label>
                    <input class="auth-input" id="login" name="login" value="<?=e($loginInput)?>" placeholder="Enter your email or phone number" required>
                </div>
                <button class="auth-submit" type="submit">Generate Reset Link</button>
            </form>

            <?php if($resetLink):?>
            <div class="auth-success-box">
                <strong>Reset Link</strong>
                <div>Copy and open this link to reset your password:</div>
                <code><?=e($resetLink)?></code>
            </div>
            <?php endif;?>

            <div class="auth-footer">
                Remember your password? <a href="/login.php">Back to login</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>
