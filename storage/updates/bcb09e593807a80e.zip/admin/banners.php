<?php
require __DIR__.'/../app/bootstrap.php';
require_admin();
require __DIR__.'/../app/homepage.php';
require __DIR__.'/../app/banners.php';

$success=$error=null;
$slides=banner_slides();

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        csrf_check();
        $action=$_POST['action']??'save';

        if($action==='delete'){
            $id=(string)($_POST['id']??'');
            $slides=array_values(array_filter($slides,fn($slide)=>(string)($slide['id']??'')!==$id));
            save_banner_slides($slides);
            $success='Banner slide deleted.';
        }else{
            $id=trim((string)($_POST['id']??''));
            if($id==='') $id='banner_'.bin2hex(random_bytes(4));

            $slide=[
                'id'=>$id,
                'enabled'=>isset($_POST['enabled'])?1:0,
                'order'=>(int)($_POST['order']??10),
                'title'=>trim((string)($_POST['title']??'')),
                'subtitle'=>trim((string)($_POST['subtitle']??'')),
                'text'=>trim((string)($_POST['text']??'')),
                'button_text'=>trim((string)($_POST['button_text']??'')),
                'button_url'=>trim((string)($_POST['button_url']??'')),
                'image'=>trim((string)($_POST['image']??'')),
            ];

            if($slide['title']==='') throw new RuntimeException('Banner title is required.');

            if(isset($_FILES['banner_image'])){
                $uploaded=upload_homepage_image($_FILES['banner_image']);
                if($uploaded) $slide['image']=$uploaded;
            }

            $found=false;
            foreach($slides as $i=>$existing){
                if((string)($existing['id']??'')===$id){
                    $slides[$i]=$slide;
                    $found=true;
                    break;
                }
            }
            if(!$found) $slides[]=$slide;

            save_banner_slides($slides);
            $success=$found?'Banner slide updated.':'New banner slide added.';
        }

        $slides=banner_slides();
    }catch(Throwable $e){
        $error=$e->getMessage();
    }
}

$edit=null;
if(isset($_GET['edit'])){
    foreach($slides as $slide){
        if((string)($slide['id']??'')===(string)$_GET['edit']){
            $edit=$slide;
            break;
        }
    }
}

require __DIR__.'/../app/layout.php';
page_start('Banner Manager',true);
?>
<style>
.banner-admin-grid{display:grid;grid-template-columns:360px 1fr;gap:18px;align-items:start}
.banner-list{display:grid;gap:12px}
.banner-admin-card{display:grid;grid-template-columns:150px 1fr auto;gap:14px;align-items:center;border:1px solid #e2e8f0;border-radius:15px;padding:12px;background:#fff}
.banner-thumb{height:92px;border-radius:12px;background:linear-gradient(135deg,#14532d,#2ca36a);background-size:cover;background-position:center;display:grid;place-items:center;color:#fff;font-weight:900;overflow:hidden}
.banner-admin-card h3{margin:0 0 5px;font-size:16px}
.banner-admin-actions{display:flex;gap:7px;flex-wrap:wrap}
@media(max-width:1000px){.banner-admin-grid{grid-template-columns:1fr}.banner-admin-card{grid-template-columns:110px 1fr}.banner-admin-actions{grid-column:1/-1}}
</style>

<div class="card">
<div class="dashboard-heading">
<div><h2>Homepage Banner Manager</h2><p>Create, edit, reorder and upload images for the homepage slider.</p></div>
<div><a class="btn ghost" href="/" target="_blank">Preview Homepage ↗</a></div>
</div>
<?php if($success):?><div class="success"><?=e($success)?></div><?php endif;?>
<?php if($error):?><div class="error"><?=e($error)?></div><?php endif;?>
</div>

<div class="banner-admin-grid">
<div class="card">
<h2><?=$edit?'Edit Banner':'Add Banner'?></h2>
<form method="post" enctype="multipart/form-data">
<input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
<input type="hidden" name="id" value="<?=e($edit['id']??'')?>">

<label>Display Order</label>
<input class="input" type="number" name="order" value="<?=e($edit['order']??10)?>">

<label>Title</label>
<input class="input" name="title" value="<?=e($edit['title']??'')?>" placeholder="Discover Shahkot" required>

<label>Subtitle</label>
<input class="input" name="subtitle" value="<?=e($edit['subtitle']??'')?>" placeholder="Your city guide">

<label>Description</label>
<textarea class="input" rows="4" name="text"><?=e($edit['text']??'')?></textarea>

<label>Button Text</label>
<input class="input" name="button_text" value="<?=e($edit['button_text']??'Explore Directory')?>">

<label>Button URL</label>
<input class="input" name="button_url" value="<?=e($edit['button_url']??'/search.php')?>">

<label>Image URL</label>
<input class="input" name="image" value="<?=e($edit['image']??'')?>" placeholder="/uploads/homepage/banner.webp">

<label>Or Upload Banner Image</label>
<input class="input" type="file" name="banner_image" accept=".jpg,.jpeg,.png,.webp,.gif">

<label style="display:flex;align-items:center;gap:8px;margin:10px 0 16px">
<input type="checkbox" name="enabled" value="1" <?=($edit['enabled']??1)?'checked':''?>> Active Banner
</label>

<button class="btn"><?=$edit?'Update Banner':'Add Banner'?></button>
<?php if($edit):?><a class="btn ghost" href="/admin/banners.php">Cancel</a><?php endif;?>
</form>
</div>

<div class="card">
<h2>Slider Banners</h2>
<div class="banner-list">
<?php foreach($slides as $slide):?>
<div class="banner-admin-card">
<div class="banner-thumb" <?=$slide['image']?'style="background-image:url(\''.e($slide['image']).'\')"':''?>><?=e(mb_strtoupper(mb_substr($slide['title'],0,1)))?></div>
<div>
<h3><?=e($slide['title'])?></h3>
<div class="muted"><?=e($slide['subtitle'])?></div>
<div class="muted">Order: <?=e($slide['order'])?> · <?=$slide['enabled']?'Active':'Hidden'?></div>
</div>
<div class="banner-admin-actions">
<a class="btn ghost" href="?edit=<?=urlencode($slide['id'])?>">Edit</a>
<form method="post" onsubmit="return confirm('Delete this banner slide?')">
<input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
<input type="hidden" name="action" value="delete">
<input type="hidden" name="id" value="<?=e($slide['id'])?>">
<button class="btn danger">Delete</button>
</form>
</div>
</div>
<?php endforeach;?>
</div>
</div>
</div>

<?php require __DIR__.'/../app/end.php';?>
