# ShahkotPK v12.7.8 — Unified Business Publish & Map Indexing Repair

Base: **v12.7.7**

This hotfix repairs a gap where a business could save successfully in Professional Business Manager yet remain absent from public listing/map surfaces because `city_id`, tenant/public flags, or supported latitude/longitude fields were incomplete.

## What changes
- Manual Business Manager saves and Google imports now use the same final public-indexing pass.
- Default/blank City resolves to the existing **Shahkot** city record rather than saving NULL.
- Active manual listings get compatible public/published/approved flags where those columns exist.
- Latitude/longitude are mirrored into all supported business geo fields and `business_details`.
- Existing map URL coordinates are parsed when possible.
- If coordinates are missing, the Business Manager can use the configured Server Places API key to attempt a **high-confidence Shahkot-only match**. It will not accept a weak/ambiguous match.
- Existing Business Manager gets **Repair Public + Map (20)**.
- Each listing shows Public / Map health.
- Imported Google listings are passed through the same finalizer after Google geo/photo repair.
- Shopkeeper owner edits also re-index the same listing.

## Manual add method
1. Admin → Professional Business Manager → Add Business.
2. Choose category and shopkeeper/owner.
3. Enter real contact/address information.
4. For best map accuracy, enter Latitude + Longitude or a Google Maps URL.
5. Set Status = Active and Save Business.
6. If geo was omitted, use **Resolve / Repair Public + Map** on the edit screen. A configured Server Places key can resolve only a high-confidence Shahkot match.

## Google Extractor method
1. Admin → Business Importer.
2. Choose an existing category and scan Shahkot.
3. Select up to 20 candidates → Verify Selected.
4. Review verified candidates → Add / Link Selected.
5. Import creates/links the same Business Directory record, shopkeeper account (if enabled), geo, photos and source tag.
6. Use Managed Imports or Business Directory to edit the same record.

## Existing missing listing repair
Open `/admin/businesses.php` and click **Repair Public + Map (20)**. The newest 20 non-deleted businesses are normalized; confident map matches are resolved when Google Places is configured.

No duplicate public business URL or admin module is added.
