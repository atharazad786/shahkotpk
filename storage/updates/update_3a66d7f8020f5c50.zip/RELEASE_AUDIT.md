# Release Audit — v12.7.8

- Professional Business Manager manual-save pipeline patched
- Shahkot city_id NULL/default repair added
- public/publish/approval compatibility flags normalized for active listings
- all supported geo columns + business_details synchronized
- safe Google Places high-confidence geo resolver added
- batch repair limited to 20
- Business Directory Public / Map health badges added
- Google import finalizer unified
- shopkeeper edits re-index existing record
- no duplicate sidebar or public business route
- additive migration only
