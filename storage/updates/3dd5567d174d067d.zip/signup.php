<?php
require __DIR__.'/app/bootstrap.php';
$error=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  csrf_check();
  $n=trim($_POST['name']??'');$em=trim($_POST['email']??'');$ph=trim($_POST['phone']??'');$pw=$_POST['password']??'';$role=$_POST['role']??'customer';
  if(!in_array($role,['customer','shopkeeper'],true))$role='customer';
  if(!$n||(!$em&&!$ph)||strlen($pw)<8)throw new RuntimeException('Complete all required fields.');
  $q=db()->prepare("INSERT INTO users(name,email,phone,password_hash,role,status) VALUES(?,?,?,?,?,'active')");
  $q->execute([$n,$em?:null,$ph?:null,password_hash($pw,PASSWORD_DEFAULT),$role]);
  header('Location: /login.php');exit;
 }catch(Throwable $e){$error='Could not create account. Email/phone may already exist.';}
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Register - ShahkotPK</title><link rel="stylesheet" href="/assets/shahkotpk-1.1.2.css?v=112"></head><body>
<section class="section"><div class="city-shell" style="max-width:650px"><div class="card"><a href="/">← ShahkotPK</a><h1>Create Account</h1><?php if($error):?><div class="error"><?=e($error)?></div><?php endif;?>
<form method="post"><input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
<label>Name</label><input class="input" name="name" required>
<label>Email</label><input class="input" type="email" name="email">
<label>Phone</label><input class="input" name="phone">
<label>Account Type</label><select class="input" name="role"><option value="customer">Customer</option><option value="shopkeeper">Business / Shopkeeper</option></select>
<label>Password</label><input class="input" type="password" name="password" minlength="8" required>
<button class="btn btn-green">Create Account</button></form></div></div></section></body></html>
