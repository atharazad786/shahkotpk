<?php
require __DIR__.'/app/bootstrap.php';
require __DIR__.'/app/homepage.php';

$q=trim($_GET['q']??'');
$category=trim($_GET['category']??'');
$params=[];
$where=["b.status=1","b.verification_status<>'suspended'"];
if($q!==''){
    $where[]="(b.name LIKE ? OR b.description LIKE ? OR b.address LIKE ? OR cat.name LIKE ?)";
    $like='%'.$q.'%';$params=array_merge($params,[$like,$like,$like,$like]);
}
if($category!==''){
    $where[]="cat.slug=?";
    $params[]=$category;
}
$sql="SELECT b.*,c.name city_name,cat.name category_name FROM businesses b JOIN cities c ON c.id=b.city_id JOIN categories cat ON cat.id=b.category_id WHERE ".implode(' AND ',$where)." ORDER BY b.is_featured DESC,b.id DESC LIMIT 100";
$stmt=db()->prepare($sql);$stmt->execute($params);$rows=$stmt->fetchAll();
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Search - ShahkotPK</title><link rel="stylesheet" href="/assets/shahkotpk-1.1.2.css?v=112"></head><body>
<div class="city-header"><div class="city-shell city-header-inner"><a class="brand" href="/"><span class="brand-mark">S</span><span><strong>ShahkotPK</strong><small>City Directory</small></span></a><a class="btn btn-green" href="/signup.php">Register Business</a></div></div>
<section class="section"><div class="city-shell"><div class="section-head"><div><div class="section-kicker">Directory Search</div><h2><?=e($q?:($category?:'All Businesses'))?></h2><p><?=count($rows)?> result(s) found.</p></div></div>
<form class="search-panel" style="box-shadow:none;border:1px solid #e4e9e5;margin-bottom:28px" method="get"><input name="q" value="<?=e($q)?>" placeholder="Search Shahkot businesses"><button>Search</button></form>
<div class="business-grid"><?php foreach($rows as $b):?><article class="business-card"><div class="business-cover" <?=$b['image']?'style="background-image:url(\''.e($b['image']).'\')"':''?>></div><div class="business-body"><span class="verified"><?=e($b['verification_status']==='verified'?'✓ Verified':'Listing')?></span><h3><?=e($b['name'])?></h3><div class="business-meta"><?=e($b['category_name'])?> · <?=e($b['city_name'])?></div><p><?=e(mb_strimwidth((string)$b['description'],0,120,'…'))?></p><a href="/business.php?slug=<?=urlencode($b['slug'])?>">View Profile →</a></div></article><?php endforeach;?></div>
<?php if(!$rows):?><div class="empty-state">No businesses found. Try another search.</div><?php endif;?>
</div></section></body></html>
