<?php
require __DIR__.'/../app/bootstrap.php';
require_admin();

$totalUsers=(int)db()->query("SELECT COUNT(*) c FROM users")->fetch()['c'];
$totalBusinesses=(int)db()->query("SELECT COUNT(*) c FROM businesses")->fetch()['c'];
$totalSubscriptions=(int)db()->query("SELECT COUNT(*) c FROM subscriptions")->fetch()['c'];
$totalAds=(int)db()->query("SELECT COUNT(*) c FROM advertisements")->fetch()['c'];
$verifiedBusinesses=(int)db()->query("SELECT COUNT(*) c FROM businesses WHERE verification_status='verified'")->fetch()['c'];
$featuredBusinesses=(int)db()->query("SELECT COUNT(*) c FROM businesses WHERE is_featured=1")->fetch()['c'];
$recentUsers=db()->query("SELECT id,name,email,role,status,created_at FROM users ORDER BY id DESC LIMIT 6")->fetchAll();
$recentBusinesses=db()->query("SELECT b.id,b.name,b.verification_status,b.is_featured,c.name AS city_name,cat.name AS category_name FROM businesses b LEFT JOIN cities c ON c.id=b.city_id LEFT JOIN categories cat ON cat.id=b.category_id ORDER BY b.id DESC LIMIT 6")->fetchAll();

require __DIR__.'/../app/layout.php';
page_start('Dashboard',true);
?>
<div class="hero-panel">
    <div class="card hero-card">
        <h2>Transform your city portal admin into a powerful control center.</h2>
        <p>Manage businesses, categories, homepage modules, advertisements, plans, users and updates from one modern dashboard.</p>
        <div class="quick-actions">
            <a class="btn ghost" href="/admin/homepage.php">🧩 Homepage Builder</a>
            <a class="btn ghost" href="/admin/businesses.php">🏪 Manage Businesses</a>
            <a class="btn ghost" href="/admin/updates.php">⬆️ Install Update</a>
        </div>
    </div>
    <div class="card">
        <h3 style="margin-bottom:14px">System Overview</h3>
        <div class="kpi-mini">
            <div class="kpi-box"><span class="metric-label">Verified Businesses</span><strong><?=e($verifiedBusinesses)?></strong><span class="muted">Approved directory listings</span></div>
            <div class="kpi-box"><span class="metric-label">Featured Businesses</span><strong><?=e($featuredBusinesses)?></strong><span class="muted">Highlighted on homepage</span></div>
            <div class="kpi-box"><span class="metric-label">Subscriptions</span><strong><?=e($totalSubscriptions)?></strong><span class="muted">Active plan records</span></div>
            <div class="kpi-box"><span class="metric-label">Advertisements</span><strong><?=e($totalAds)?></strong><span class="muted">Campaign entries</span></div>
        </div>
    </div>
</div>

<div class="grid">
    <div class="metric-card primary">
        <div class="metric-label">Total Users</div>
        <div class="metric-value"><?=e($totalUsers)?></div>
        <div class="metric-foot">Customers, shopkeepers and admins</div>
    </div>
    <div class="metric-card success">
        <div class="metric-label">Businesses</div>
        <div class="metric-value"><?=e($totalBusinesses)?></div>
        <div class="metric-foot">Registered city business listings</div>
    </div>
    <div class="metric-card warning">
        <div class="metric-label">Subscriptions</div>
        <div class="metric-value"><?=e($totalSubscriptions)?></div>
        <div class="metric-foot">Plan and billing records</div>
    </div>
    <div class="metric-card info">
        <div class="metric-label">Advertisements</div>
        <div class="metric-value"><?=e($totalAds)?></div>
        <div class="metric-foot">Promotions and ad placements</div>
    </div>
</div>

<div class="two-col">
    <div class="card">
        <div style="display:flex;justify-content:space-between;gap:14px;align-items:center;flex-wrap:wrap">
            <div>
                <h3 style="margin-bottom:6px">Recent Users</h3>
                <div class="muted">Latest accounts added to the platform</div>
            </div>
            <a class="btn secondary" href="/admin/users.php">Open Users</a>
        </div>
        <table>
            <tr><th>User</th><th>Role</th><th>Status</th><th>Joined</th></tr>
            <?php foreach($recentUsers as $u): ?>
            <tr>
                <td><strong><?=e($u['name'])?></strong><br><span class="muted"><?=e($u['email'] ?: 'No email')?></span></td>
                <td><span class="badge info"><?=e($u['role'])?></span></td>
                <td><span class="badge <?=$u['status']==='active'?'success':'warning'?>"><?=e($u['status'])?></span></td>
                <td><?=e(date('d M Y', strtotime($u['created_at'])))?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>

    <div class="card">
        <h3 style="margin-bottom:12px">Activity Snapshot</h3>
        <div class="spark" style="margin-bottom:14px"></div>
        <div class="muted">Visual preview card to give the dashboard a polished admin-template feel.</div>
        <div style="height:16px"></div>
        <div class="donut"></div>
    </div>
</div>

<div class="card">
    <div style="display:flex;justify-content:space-between;gap:14px;align-items:center;flex-wrap:wrap">
        <div>
            <h3 style="margin-bottom:6px">Recent Businesses</h3>
            <div class="muted">Latest business listings in your directory</div>
        </div>
        <a class="btn secondary" href="/admin/businesses.php">Open Businesses</a>
    </div>
    <?php if($recentBusinesses): ?>
    <table>
        <tr><th>Business</th><th>Category</th><th>City</th><th>Status</th><th>Featured</th></tr>
        <?php foreach($recentBusinesses as $b): ?>
        <tr>
            <td><strong><?=e($b['name'])?></strong></td>
            <td><?=e($b['category_name'] ?: '—')?></td>
            <td><?=e($b['city_name'] ?: '—')?></td>
            <td><span class="badge <?=$b['verification_status']==='verified'?'success':'warning'?>"><?=e($b['verification_status'])?></span></td>
            <td><?= $b['is_featured'] ? '★ Yes' : 'No' ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <?php else: ?>
        <div class="empty-state">No business records available yet.</div>
    <?php endif; ?>
</div>
<?php require __DIR__.'/../app/end.php'; ?>
